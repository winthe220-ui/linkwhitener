#!/usr/bin/env python3
"""
Script to setup admin users
"""
import sys
import argparse
import getpass
from datetime import datetime
import hashlib
import secrets

sys.path.append('.')

from app.core.firestore_client import firestore_client
from app.utils.security import hash_password


def create_admin(email: str, password: str, name: str, role: str = "admin", permissions: list = None):
    """Create admin user"""
    
    # Validate email
    if not "@" in email:
        print("Error: Invalid email address")
        return False
    
    # Check if admin already exists
    existing = firestore_client.get_document("admins", email.lower())
    if existing:
        print(f"Error: Admin with email {email} already exists")
        return False
    
    # Hash password
    password_hash = hash_password(password)
    
    # Generate API key
    api_key = secrets.token_urlsafe(32)
    api_key_hash = hashlib.sha256(api_key.encode()).hexdigest()
    
    # Admin data
    admin_data = {
        "email": email.lower(),
        "password_hash": password_hash,
        "name": name,
        "role": role,
        "permissions": permissions or ["view_dashboard", "view_users", "manage_withdrawals"],
        "api_key_hash": api_key_hash,
        "is_active": True,
        "created_at": datetime.utcnow().isoformat(),
        "updated_at": datetime.utcnow().isoformat(),
        "last_login": None,
        "ip_whitelist": [],  # Empty means all IPs allowed
        "two_factor_enabled": False,
        "metadata": {
            "created_by": "setup_script",
            "creation_time": datetime.utcnow().isoformat()
        }
    }
    
    # Save to Firestore
    firestore_client.create_document(
        collection="admins",
        document_id=email.lower(),
        data=admin_data
    )
    
    print("\n" + "="*50)
    print("ADMIN CREATED SUCCESSFULLY")
    print("="*50)
    print(f"Email: {email}")
    print(f"Name: {name}")
    print(f"Role: {role}")
    print(f"Permissions: {', '.join(permissions or [])}")
    print(f"API Key: {api_key}")
    print("\nIMPORTANT: Save the API key securely. It won't be shown again.")
    print("="*50)
    
    return True


def list_admins():
    """List all admins"""
    admins = firestore_client.get_all_documents("admins")
    
    if not admins:
        print("No admins found")
        return
    
    print("\n" + "="*80)
    print("LIST OF ADMINS")
    print("="*80)
    print(f"{'Email':<30} {'Name':<20} {'Role':<15} {'Status':<10} {'Last Login':<20}")
    print("-"*80)
    
    for admin in admins:
        email = admin.get("email", "N/A")
        name = admin.get("name", "N/A")
        role = admin.get("role", "N/A")
        is_active = "Active" if admin.get("is_active") else "Inactive"
        last_login = admin.get("last_login", "Never")
        
        print(f"{email:<30} {name:<20} {role:<15} {is_active:<10} {last_login:<20}")
    
    print("="*80)


def deactivate_admin(email: str):
    """Deactivate admin"""
    admin = firestore_client.get_document("admins", email.lower())
    
    if not admin:
        print(f"Error: Admin with email {email} not found")
        return False
    
    firestore_client.update_document(
        collection="admins",
        document_id=email.lower(),
        data={
            "is_active": False,
            "updated_at": datetime.utcnow().isoformat(),
            "deactivated_at": datetime.utcnow().isoformat()
        }
    )
    
    print(f"Admin {email} deactivated successfully")
    return True


def main():
    parser = argparse.ArgumentParser(description="Admin Management Script")
    subparsers = parser.add_subparsers(dest="command", help="Command to execute")
    
    # Create admin command
    create_parser = subparsers.add_parser("create", help="Create new admin")
    create_parser.add_argument("--email", required=True, help="Admin email")
    create_parser.add_argument("--name", required=True, help="Admin name")
    create_parser.add_argument("--role", default="admin", choices=["admin", "super_admin", "support"], help="Admin role")
    create_parser.add_argument("--permissions", nargs="+", help="Admin permissions")
    
    # List admins command
    subparsers.add_parser("list", help="List all admins")
    
    # Deactivate admin command
    deactivate_parser = subparsers.add_parser("deactivate", help="Deactivate admin")
    deactivate_parser.add_argument("--email", required=True, help="Admin email to deactivate")
    
    args = parser.parse_args()
    
    if args.command == "create":
        print(f"Creating admin: {args.email}")
        password = getpass.getpass("Enter password: ")
        password_confirm = getpass.getpass("Confirm password: ")
        
        if password != password_confirm:
            print("Error: Passwords don't match")
            sys.exit(1)
        
        if len(password) < 8:
            print("Error: Password must be at least 8 characters")
            sys.exit(1)
        
        create_admin(
            email=args.email,
            password=password,
            name=args.name,
            role=args.role,
            permissions=args.permissions
        )
    
    elif args.command == "list":
        list_admins()
    
    elif args.command == "deactivate":
        confirm = input(f"Are you sure you want to deactivate admin {args.email}? (yes/no): ")
        if confirm.lower() == "yes":
            deactivate_admin(args.email)
        else:
            print("Operation cancelled")
    
    else:
        parser.print_help()


if __name__ == "__main__":
    main()