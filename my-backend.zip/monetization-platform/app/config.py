from typing import List, Optional, Dict, Any
from pydantic_settings import BaseSettings, SettingsConfigDict
from functools import lru_cache
import json
import os


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=True,
        extra="ignore"
    )
    
    # App
    app_name: str = "Monetization Platform"
    environment: str = "development"
    debug: bool = False
    log_level: str = "INFO"
    secret_key: str
    api_v1_prefix: str = "/api/v1"
    
    # Firebase
    firebase_project_id: str
    firebase_private_key_id: Optional[str] = None
    firebase_private_key: Optional[str] = None
    firebase_client_email: Optional[str] = None
    firebase_client_id: Optional[str] = None
    firebase_client_x509_cert_url: Optional[str] = None
    
    # Database
    firestore_project_id: str
    firestore_database: str = "(default)"
    redis_url: str = "redis://localhost:6379/0"
    redis_password: Optional[str] = None
    redis_ssl: bool = False
    
    # Admin
    admin_jwt_secret: str
    admin_token_expire_hours: int = 8
    admin_ip_whitelist: List[str] = []
    super_admin_emails: List[str] = []
    
    # Security
    user_jwt_secret: str
    user_token_expire_days: int = 7
    refresh_token_expire_days: int = 30
    encryption_key: str
    cors_origins: List[str] = []
    rate_limit_per_minute: int = 60
    max_login_attempts: int = 5
    login_block_minutes: int = 15
    
    # Platform
    min_withdrawal_amount: float = 500.00
    max_withdrawal_amount: float = 50000.00
    payout_rate_per_view: float = 0.0015
    withdrawal_cooldown_hours: int = 24
    max_links_per_user: int = 100
    daily_link_limit: int = 10
    referral_bonus: float = 50.00
    kyc_required_amount: float = 10000.00
    
    # Fraud
    fraud_min_page_time: int = 10
    fraud_max_clicks_per_ip: int = 100
    fraud_suspicious_patterns: bool = True
    fraud_auto_block: bool = True
    bot_detection_enabled: bool = True
    
    # Notifications
    sendgrid_api_key: Optional[str] = None
    twilio_account_sid: Optional[str] = None
    twilio_auth_token: Optional[str] = None
    twilio_phone_number: Optional[str] = None
    email_from: str = "noreply@example.com"
    sms_enabled: bool = False
    email_enabled: bool = False
    
    # Payment
    razorpay_key_id: Optional[str] = None
    razorpay_key_secret: Optional[str] = None
    stripe_api_key: Optional[str] = None
    stripe_webhook_secret: Optional[str] = None
    
    # Monitoring
    sentry_dsn: Optional[str] = None
    logging_service: str = "console"
    metrics_enabled: bool = True
    
    # Performance
    cache_ttl: int = 3600
    connection_pool_size: int = 20
    max_workers: int = 4
    
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        # Parse comma-separated lists
        if isinstance(self.cors_origins, str):
            self.cors_origins = [origin.strip() for origin in self.cors_origins.split(",") if origin.strip()]
        if isinstance(self.admin_ip_whitelist, str):
            self.admin_ip_whitelist = [ip.strip() for ip in self.admin_ip_whitelist.split(",") if ip.strip()]
        if isinstance(self.super_admin_emails, str):
            self.super_admin_emails = [email.strip() for email in self.super_admin_emails.split(",") if email.strip()]
    
    @property
    def firebase_credentials(self) -> Dict[str, Any]:
        """Get Firebase credentials as dict"""
        if self.firebase_private_key:
            return {
                "type": "service_account",
                "project_id": self.firebase_project_id,
                "private_key_id": self.firebase_private_key_id,
                "private_key": self.firebase_private_key.replace('\\n', '\n'),
                "client_email": self.firebase_client_email,
                "client_id": self.firebase_client_id,
                "auth_uri": "https://accounts.google.com/o/oauth2/auth",
                "token_uri": "https://oauth2.googleapis.com/token",
                "auth_provider_x509_cert_url": "https://www.googleapis.com/oauth2/v1/certs",
                "client_x509_cert_url": self.firebase_client_x509_cert_url
            }
        return {}


@lru_cache()
def get_settings() -> Settings:
    return Settings()