"""
Application constants and configuration
"""
from enum import Enum
from datetime import timedelta


class Constants:
    """Application constants"""
    
    # API Settings
    API_VERSION = "1.0.0"
    API_PREFIX = "/api/v1"
    DEFAULT_PAGE_SIZE = 20
    MAX_PAGE_SIZE = 100
    
    # JWT Settings
    ACCESS_TOKEN_EXPIRE_DAYS = 7
    REFRESH_TOKEN_EXPIRE_DAYS = 30
    ADMIN_TOKEN_EXPIRE_HOURS = 8
    
    # Rate Limiting
    RATE_LIMIT_PER_MINUTE = 60
    MAX_LOGIN_ATTEMPTS = 5
    LOGIN_BLOCK_MINUTES = 15
    
    # Platform Settings
    MIN_WITHDRAWAL_AMOUNT = 500.00
    MAX_WITHDRAWAL_AMOUNT = 50000.00
    PAYOUT_RATE_PER_VIEW = 0.0015  # ₹0.0015 per valid page 3 view
    WITHDRAWAL_COOLDOWN_HOURS = 24
    MAX_LINKS_PER_USER = 100
    DAILY_LINK_LIMIT = 10
    REFERRAL_BONUS = 50.00
    KYC_REQUIRED_AMOUNT = 10000.00
    
    # Fraud Detection
    FRAUD_MIN_PAGE_TIME = 10  # seconds
    FRAUD_MAX_CLICKS_PER_IP = 100
    FRAUD_SCORE_THRESHOLD = 70.0
    BOT_DETECTION_ENABLED = True
    
    # Cache TTLs (seconds)
    USER_PROFILE_TTL = 300  # 5 minutes
    LINK_ANALYTICS_TTL = 60  # 1 minute
    PLATFORM_STATS_TTL = 30  # 30 seconds
    RATE_LIMIT_TTL = 60  # 1 minute
    
    # Notification Settings
    EMAIL_VERIFICATION_TTL = 86400  # 24 hours
    PASSWORD_RESET_TTL = 3600  # 1 hour
    WITHDRAWAL_NOTIFICATION_DELAY = 300  # 5 minutes
    
    # File Upload Limits (bytes)
    MAX_AVATAR_SIZE = 5 * 1024 * 1024  # 5MB
    MAX_KYC_DOC_SIZE = 10 * 1024 * 1024  # 10MB
    ALLOWED_IMAGE_TYPES = ["image/jpeg", "image/png", "image/webp"]
    
    # Security
    PASSWORD_MIN_LENGTH = 8
    PASSWORD_MAX_LENGTH = 128
    API_KEY_LENGTH = 32
    SESSION_TOKEN_LENGTH = 64
    
    # Analytics
    ANALYTICS_RETENTION_DAYS = 90
    USER_RETENTION_DAYS = 30
    LINK_RETENTION_DAYS = 365  # 1 year
    
    # Performance
    MAX_WORKERS = 4
    REQUEST_TIMEOUT = 30  # seconds
    DATABASE_TIMEOUT = 10  # seconds


class ErrorMessages:
    """Error message constants"""
    
    # Authentication errors
    INVALID_CREDENTIALS = "Invalid credentials"
    INVALID_TOKEN = "Invalid or expired token"
    TOKEN_EXPIRED = "Token has expired"
    TOKEN_REVOKED = "Token has been revoked"
    INSUFFICIENT_PERMISSIONS = "Insufficient permissions"
    ACCOUNT_SUSPENDED = "Account is suspended"
    ACCOUNT_BANNED = "Account is banned"
    IP_NOT_ALLOWED = "IP address not allowed"
    RATE_LIMIT_EXCEEDED = "Rate limit exceeded"
    
    # User errors
    USER_NOT_FOUND = "User not found"
    USER_ALREADY_EXISTS = "User already exists"
    INVALID_PHONE = "Invalid phone number"
    INVALID_EMAIL = "Invalid email address"
    EMAIL_ALREADY_EXISTS = "Email already registered"
    PHONE_ALREADY_EXISTS = "Phone number already registered"
    USERNAME_TAKEN = "Username is already taken"
    PASSWORD_TOO_WEAK = "Password is too weak"
    
    # Link errors
    LINK_NOT_FOUND = "Link not found"
    LINK_DISABLED = "Link is disabled"
    LINK_EXPIRED = "Link has expired"
    INVALID_URL = "Invalid URL"
    URL_BLACKLISTED = "URL is blacklisted"
    MAX_LINKS_REACHED = "Maximum links limit reached"
    DAILY_LIMIT_REACHED = "Daily link creation limit reached"
    
    # Earnings errors
    INSUFFICIENT_BALANCE = "Insufficient balance"
    MIN_WITHDRAWAL_NOT_MET = "Minimum withdrawal amount not met"
    WITHDRAWAL_COOLDOWN = "Withdrawal cooldown period active"
    KYC_REQUIRED = "KYC verification required for withdrawal"
    WITHDRAWAL_LIMIT_EXCEEDED = "Withdrawal limit exceeded"
    
    # Validation errors
    REQUIRED_FIELD = "This field is required"
    INVALID_FORMAT = "Invalid format"
    VALUE_TOO_LONG = "Value is too long"
    VALUE_TOO_SHORT = "Value is too short"
    INVALID_CHOICE = "Invalid choice"
    
    # System errors
    INTERNAL_ERROR = "Internal server error"
    SERVICE_UNAVAILABLE = "Service temporarily unavailable"
    MAINTENANCE_MODE = "System is under maintenance"
    DATABASE_ERROR = "Database error"
    CACHE_ERROR = "Cache error"
    
    # Payment errors
    PAYMENT_FAILED = "Payment processing failed"
    INVALID_PAYMENT_METHOD = "Invalid payment method"
    PAYMENT_GATEWAY_ERROR = "Payment gateway error"


class SuccessMessages:
    """Success message constants"""
    
    # Authentication
    LOGIN_SUCCESS = "Login successful"
    LOGOUT_SUCCESS = "Logout successful"
    REGISTRATION_SUCCESS = "Registration successful"
    TOKEN_REFRESHED = "Token refreshed successfully"
    PASSWORD_CHANGED = "Password changed successfully"
    
    # User operations
    PROFILE_UPDATED = "Profile updated successfully"
    AVATAR_UPDATED = "Avatar updated successfully"
    KYC_SUBMITTED = "KYC documents submitted successfully"
    KYC_VERIFIED = "KYC verified successfully"
    
    # Link operations
    LINK_CREATED = "Link created successfully"
    LINK_UPDATED = "Link updated successfully"
    LINK_DISABLED = "Link disabled successfully"
    LINK_DELETED = "Link deleted successfully"
    
    # Earnings operations
    EARNINGS_CALCULATED = "Earnings calculated successfully"
    WITHDRAWAL_REQUESTED = "Withdrawal requested successfully"
    WITHDRAWAL_APPROVED = "Withdrawal approved successfully"
    WITHDRAWAL_REJECTED = "Withdrawal rejected successfully"
    WITHDRAWAL_CANCELLED = "Withdrawal cancelled successfully"
    
    # Admin operations
    USER_SUSPENDED = "User suspended successfully"
    USER_BANNED = "User banned successfully"
    USER_REINSTATED = "User reinstated successfully"
    SETTINGS_UPDATED = "Settings updated successfully"
    
    # System operations
    CLEANUP_COMPLETED = "Cleanup completed successfully"
    BACKUP_COMPLETED = "Backup completed successfully"
    CACHE_CLEARED = "Cache cleared successfully"


class ValidationPatterns:
    """Regex patterns for validation"""
    
    PHONE_REGEX = r'^\+[1-9]\d{1,14}$'  # E.164 format
    EMAIL_REGEX = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    USERNAME_REGEX = r'^[a-zA-Z0-9_]{3,30}$'
    PASSWORD_REGEX = r'^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$'
    URL_REGEX = r'^https?://(?:[-\w.]|(?:%[\da-fA-F]{2}))+[/\w .?=%&_~+#-]*$'
    SHORT_CODE_REGEX = r'^[a-zA-Z0-9_-]{4,12}$'
    UPI_ID_REGEX = r'^[a-zA-Z0-9._-]+@[a-zA-Z]{2,}$'
    IFSC_CODE_REGEX = r'^[A-Z]{4}0[A-Z0-9]{6}$'
    PAN_REGEX = r'^[A-Z]{5}[0-9]{4}[A-Z]{1}$'
    AADHAAR_REGEX = r'^\d{12}$'


class CacheKeys:
    """Redis cache key patterns"""
    
    # User related
    USER_PROFILE = "user:{uid}:profile"
    USER_EARNINGS = "user:{uid}:earnings"
    USER_LINKS_COUNT = "user:{uid}:links_count"
    USER_STATUS = "user:{uid}:status"
    
    # Link related
    LINK_DETAILS = "link:{link_id}:details"
    LINK_ANALYTICS = "link:{link_id}:analytics"
    LINK_CLICKS_TODAY = "link:{link_id}:clicks_today"
    
    # Platform related
    PLATFORM_STATS = "platform:stats"
    ACTIVE_USERS_COUNT = "platform:active_users"
    PENDING_WITHDRAWALS = "platform:pending_withdrawals"
    
    # Rate limiting
    RATE_LIMIT = "rate_limit:{identifier}"
    LOGIN_ATTEMPTS = "login_attempts:{identifier}"
    LOGIN_BLOCKED = "login_blocked:{identifier}"
    
    # Session management
    USER_SESSION = "session:{session_id}"
    ADMIN_SESSION = "admin_session:{session_id}"
    TOKEN_REVOKED = "token_revoked:{token_hash}"
    
    # OTP and verification
    OTP_VERIFICATION = "otp:{phone}:verification"
    EMAIL_VERIFICATION = "email:{email}:verification"
    PASSWORD_RESET = "password_reset:{token}"
    
    # Fraud detection
    IP_CLICK_COUNT = "ip:{ip}:clicks"
    DEVICE_FINGERPRINT = "device:{fingerprint}:activity"
    FRAUD_SESSION = "fraud:session:{session_id}"


class CollectionNames:
    """Firestore collection names"""
    
    # Core collections
    USERS = "users"
    ADMINS = "admins"
    LINKS = "links"
    EARNINGS = "earnings"
    TRANSACTIONS = "transactions"
    WITHDRAWALS = "withdrawals"
    
    # Analytics collections
    LINK_ANALYTICS = "link_analytics"
    USER_ANALYTICS = "user_analytics"
    PLATFORM_ANALYTICS = "platform_analytics"
    DAILY_STATS = "daily_stats"
    
    # System collections
    AUDIT_LOGS = "audit_logs"
    FRAUD_LOGS = "fraud_logs"
    ERROR_LOGS = "error_logs"
    SYSTEM_LOGS = "system_logs"
    
    # Configuration collections
    PLATFORM_SETTINGS = "platform_settings"
    WEBSITE_POOL = "website_pool"
    BLACKLIST = "blacklist"
    WHITELIST = "whitelist"
    
    # Support collections
    SUPPORT_TICKETS = "support_tickets"
    NOTIFICATIONS = "notifications"
    MESSAGES = "messages"
    
    # KYC collections
    KYC_SUBMISSIONS = "kyc_submissions"
    KYC_DOCUMENTS = "kyc_documents"


class AdminPermissions:
    """Admin permission constants"""
    
    # Dashboard permissions
    VIEW_DASHBOARD = "view_dashboard"
    VIEW_ANALYTICS = "view_analytics"
    VIEW_STATISTICS = "view_statistics"
    
    # User management permissions
    VIEW_USERS = "view_users"
    CREATE_USERS = "create_users"
    EDIT_USERS = "edit_users"
    SUSPEND_USERS = "suspend_users"
    BAN_USERS = "ban_users"
    REINSTATE_USERS = "reinstate_users"
    ADJUST_EARNINGS = "adjust_earnings"
    
    # Link management permissions
    VIEW_LINKS = "view_links"
    EDIT_LINKS = "edit_links"
    DELETE_LINKS = "delete_links"
    VERIFY_LINKS = "verify_links"
    
    # Earnings permissions
    VIEW_EARNINGS = "view_earnings"
    VIEW_TRANSACTIONS = "view_transactions"
    EXPORT_EARNINGS = "export_earnings"
    
    # Withdrawal permissions
    MANAGE_WITHDRAWALS = "manage_withdrawals"
    APPROVE_WITHDRAWALS = "approve_withdrawals"
    REJECT_WITHDRAWALS = "reject_withdrawals"
    EXPORT_WITHDRAWALS = "export_withdrawals"
    
    # Settings permissions
    VIEW_SETTINGS = "view_settings"
    UPDATE_SETTINGS = "update_settings"
    MANAGE_WEBSITES = "manage_websites"
    
    # Admin management permissions
    VIEW_ADMINS = "view_admins"
    CREATE_ADMINS = "create_admins"
    EDIT_ADMINS = "edit_admins"
    DEACTIVATE_ADMINS = "deactivate_admins"
    
    # Audit permissions
    VIEW_AUDIT_LOGS = "view_audit_logs"
    VIEW_SYSTEM_LOGS = "view_system_logs"
    
    # Fraud detection permissions
    VIEW_FRAUD = "view_fraud"
    MANAGE_FRAUD = "manage_fraud"
    BLOCK_USERS = "block_users"
    
    # System permissions
    SYSTEM_CLEANUP = "system_cleanup"
    SYSTEM_BACKUP = "system_backup"
    SYSTEM_RESTORE = "system_restore"
    
    # All permissions (super admin only)
    ALL_PERMISSIONS = "*"
    
    # Permission groups
    ADMIN_GROUP = [
        VIEW_DASHBOARD, VIEW_USERS, VIEW_LINKS, VIEW_EARNINGS,
        MANAGE_WITHDRAWALS, VIEW_SETTINGS, VIEW_AUDIT_LOGS
    ]
    
    SUPPORT_GROUP = [
        VIEW_USERS, VIEW_LINKS, VIEW_EARNINGS, VIEW_WITHDRAWALS
    ]
    
    MODERATOR_GROUP = [
        VIEW_USERS, SUSPEND_USERS, VIEW_LINKS, EDIT_LINKS,
        VIEW_FRAUD, BLOCK_USERS
    ]


class UserTierBenefits:
    """User tier benefits and limits"""
    
    TIERS = {
        "basic": {
            "max_links": 100,
            "daily_link_limit": 10,
            "custom_domain": False,
            "advanced_analytics": False,
            "priority_support": False,
            "payout_rate": 0.0015,
            "withdrawal_fee": 2.0,  # percentage
            "min_withdrawal": 500.00,
            "withdrawal_cooldown": 24,  # hours
        },
        "pro": {
            "max_links": 500,
            "daily_link_limit": 50,
            "custom_domain": True,
            "advanced_analytics": True,
            "priority_support": True,
            "payout_rate": 0.0020,
            "withdrawal_fee": 1.5,
            "min_withdrawal": 250.00,
            "withdrawal_cooldown": 12,
        },
        "premium": {
            "max_links": 2000,
            "daily_link_limit": 200,
            "custom_domain": True,
            "advanced_analytics": True,
            "priority_support": True,
            "dedicated_account_manager": True,
            "payout_rate": 0.0025,
            "withdrawal_fee": 1.0,
            "min_withdrawal": 100.00,
            "withdrawal_cooldown": 6,
        },
        "enterprise": {
            "max_links": 10000,
            "daily_link_limit": 1000,
            "custom_domain": True,
            "advanced_analytics": True,
            "priority_support": True,
            "dedicated_account_manager": True,
            "custom_payout_rate": True,
            "api_access": True,
            "bulk_operations": True,
            "withdrawal_fee": 0.5,
            "min_withdrawal": 50.00,
            "withdrawal_cooldown": 1,
        }
    }


class NotificationTemplates:
    """Notification template names"""
    
    # Email templates
    WELCOME_EMAIL = "welcome_email"
    EMAIL_VERIFICATION = "email_verification"
    PASSWORD_RESET = "password_reset"
    ACCOUNT_SUSPENDED = "account_suspended"
    ACCOUNT_BANNED = "account_banned"
    ACCOUNT_REINSTATED = "account_reinstated"
    KYC_SUBMITTED = "kyc_submitted"
    KYC_APPROVED = "kyc_approved"
    KYC_REJECTED = "kyc_rejected"
    
    # Link notifications
    LINK_CREATED = "link_created"
    LINK_DISABLED = "link_disabled"
    LINK_DELETED = "link_deleted"
    
    # Earnings notifications
    EARNINGS_CREDITED = "earnings_credited"
    WITHDRAWAL_REQUESTED = "withdrawal_requested"
    WITHDRAWAL_APPROVED = "withdrawal_approved"
    WITHDRAWAL_REJECTED = "withdrawal_rejected"
    WITHDRAWAL_COMPLETED = "withdrawal_completed"
    
    # Referral notifications
    REFERRAL_SIGNUP = "referral_signup"
    REFERRAL_BONUS = "referral_bonus"
    
    # Security notifications
    NEW_LOGIN = "new_login"
    PASSWORD_CHANGED = "password_changed"
    SUSPICIOUS_ACTIVITY = "suspicious_activity"
    
    # System notifications
    MAINTENANCE_NOTICE = "maintenance_notice"
    SYSTEM_UPDATE = "system_update"
    IMPORTANT_ANNOUNCEMENT = "important_announcement"


class PaymentMethods:
    """Available payment methods"""
    
    METHODS = {
        "upi": {
            "name": "UPI",
            "min_amount": 1.00,
            "max_amount": 100000.00,
            "processing_fee": 0.0,
            "processing_time": "Instant",
            "supported_apps": ["Google Pay", "PhonePe", "Paytm", "BHIM"],
            "validation_regex": ValidationPatterns.UPI_ID_REGEX
        },
        "bank_transfer": {
            "name": "Bank Transfer",
            "min_amount": 100.00,
            "max_amount": 500000.00,
            "processing_fee": 5.0,  # ₹5 or 1%
            "processing_time": "1-2 business days",
            "validation_fields": ["account_holder", "account_number", "ifsc_code", "bank_name"]
        },
        "paytm": {
            "name": "Paytm Wallet",
            "min_amount": 10.00,
            "max_amount": 10000.00,
            "processing_fee": 0.0,
            "processing_time": "Instant"
        },
        "phonepe": {
            "name": "PhonePe",
            "min_amount": 1.00,
            "max_amount": 100000.00,
            "processing_fee": 0.0,
            "processing_time": "Instant"
        },
        "google_pay": {
            "name": "Google Pay",
            "min_amount": 1.00,
            "max_amount": 100000.00,
            "processing_fee": 0.0,
            "processing_time": "Instant"
        },
        "paypal": {
            "name": "PayPal",
            "min_amount": 10.00,
            "max_amount": 10000.00,
            "processing_fee": 2.9,  # percentage
            "processing_time": "Instant",
            "currency": "USD"
        }
    }


class FraudReasons:
    """Fraud detection reasons"""
    
    REASONS = {
        "HIGH_CLICK_RATE": "Unusually high click rate detected",
        "LOW_PAGE_TIME": "Suspiciously low page view times",
        "BOT_PATTERN": "Bot-like behavior detected",
        "MULTIPLE_ACCOUNTS": "Multiple accounts from same device",
        "VPN_PROXY": "Using VPN/Proxy service",
        "BLACKLISTED_IP": "IP address is blacklisted",
        "SUSPICIOUS_REFERRER": "Suspicious referrer detected",
        "FAKE_CLICKS": "Pattern of fake clicks detected",
        "CLICK_FARM": "Click farm activity detected",
        "AUTOMATED_SCRIPT": "Automated script detected",
        "GEO_INCONSISTENCY": "Geographic inconsistency in clicks",
        "DEVICE_SPOOFING": "Device fingerprint spoofing",
        "TIME_ANOMALY": "Unusual click timing pattern",
        "REPEATED_PATTERN": "Repeated click pattern detected",
        "MALICIOUS_SOURCE": "Traffic from malicious source"
    }