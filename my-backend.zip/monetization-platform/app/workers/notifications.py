import asyncio
import logging
from datetime import datetime
from typing import Dict, Any

logger = logging.getLogger(__name__)


class NotificationWorker:
    """
    Background worker for sending notifications
    """

    def __init__(self, interval_seconds: int = 30):
        self.interval = interval_seconds
        self.running = False
        self.last_dispatch: datetime | None = None

    async def start(self):
        self.running = True
        logger.info("NotificationWorker started")

        while self.running:
            try:
                await self.run()
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.exception("NotificationWorker error: %s", e)

            await asyncio.sleep(self.interval)

        logger.info("NotificationWorker stopped")

    async def stop(self):
        self.running = False

    async def run(self):
        logger.debug("NotificationWorker dispatching notifications")
        # Placeholder: send queued emails / push / SMS
        self.last_dispatch = datetime.utcnow()

    async def get_status(self) -> Dict[str, Any]:
        return {
            "last_dispatch": self.last_dispatch.isoformat() if self.last_dispatch else None,
            "interval_seconds": self.interval,
        }
