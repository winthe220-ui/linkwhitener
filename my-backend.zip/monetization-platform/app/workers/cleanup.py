import asyncio
import logging
from datetime import datetime, timedelta
from typing import Dict, Any

logger = logging.getLogger(__name__)


class CleanupWorker:
    """
    Background worker for cleanup tasks
    """

    def __init__(self, interval_seconds: int = 3600):
        self.interval = interval_seconds
        self.running = False
        self.last_cleanup: datetime | None = None

    async def start(self):
        self.running = True
        logger.info("CleanupWorker started")

        while self.running:
            try:
                await self.run()
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.exception("CleanupWorker error: %s", e)

            await asyncio.sleep(self.interval)

        logger.info("CleanupWorker stopped")

    async def stop(self):
        self.running = False

    async def run(self):
        logger.debug("CleanupWorker running cleanup job")
        # Placeholder: clean expired sessions, tokens, temp data
        self.last_cleanup = datetime.utcnow()

    async def get_status(self) -> Dict[str, Any]:
        return {
            "last_cleanup": self.last_cleanup.isoformat() if self.last_cleanup else None,
            "interval_seconds": self.interval,
        }
