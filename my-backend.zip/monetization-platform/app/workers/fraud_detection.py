import asyncio
import logging
from datetime import datetime
from typing import Dict, Any

logger = logging.getLogger(__name__)


class FraudDetectionWorker:
    """
    Background worker for fraud detection
    """

    def __init__(self, interval_seconds: int = 120):
        self.interval = interval_seconds
        self.running = False
        self.last_scan: datetime | None = None

    async def start(self):
        self.running = True
        logger.info("FraudDetectionWorker started")

        while self.running:
            try:
                await self.run()
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.exception("FraudDetectionWorker error: %s", e)

            await asyncio.sleep(self.interval)

        logger.info("FraudDetectionWorker stopped")

    async def stop(self):
        self.running = False

    async def run(self):
        logger.debug("FraudDetectionWorker scanning for fraud")
        # Placeholder: run fraud rules / heuristics
        self.last_scan = datetime.utcnow()

    async def get_status(self) -> Dict[str, Any]:
        return {
            "last_scan": self.last_scan.isoformat() if self.last_scan else None,
            "interval_seconds": self.interval,
        }
