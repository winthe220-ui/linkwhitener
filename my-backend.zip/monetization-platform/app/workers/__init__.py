"""
Background workers for async processing
"""

import asyncio
import logging
from datetime import datetime, timedelta
from typing import List, Dict, Any, Optional

logger = logging.getLogger(__name__)

class WorkerManager:
    """Manager for background workers"""
    
    def __init__(self):
        self.workers = {}
        self.tasks = []
        self.is_running = False
    
    async def start_workers(self):
        """Start all background workers"""
        if self.is_running:
            logger.warning("Workers are already running")
            return
        
        self.is_running = True
        logger.info("Starting background workers...")
        
        # Import and start workers
        from app.workers.fraud_detection import FraudDetectionWorker
        from app.workers.cleanup import CleanupWorker
        from app.workers.notifications import NotificationWorker
        from app.workers.analytics import AnalyticsWorker
        
        # Initialize workers
        self.workers["fraud_detection"] = FraudDetectionWorker()
        self.workers["cleanup"] = CleanupWorker()
        self.workers["notifications"] = NotificationWorker()
        self.workers["analytics"] = AnalyticsWorker()
        
        # Start workers
        for name, worker in self.workers.items():
            task = asyncio.create_task(worker.start())
            self.tasks.append(task)
            logger.info(f"Started {name} worker")
        
        logger.info("All background workers started")
    
    async def stop_workers(self):
        """Stop all background workers"""
        if not self.is_running:
            logger.warning("Workers are not running")
            return
        
        logger.info("Stopping background workers...")
        
        # Stop all workers
        for name, worker in self.workers.items():
            await worker.stop()
            logger.info(f"Stopped {name} worker")
        
        # Cancel all tasks
        for task in self.tasks:
            task.cancel()
        
        # Wait for tasks to complete
        await asyncio.gather(*self.tasks, return_exceptions=True)
        
        self.workers.clear()
        self.tasks.clear()
        self.is_running = False
        
        logger.info("All background workers stopped")
    
    async def get_worker_status(self) -> Dict[str, Any]:
        """Get status of all workers"""
        status = {}
        
        for name, worker in self.workers.items():
            try:
                worker_status = await worker.get_status()
                status[name] = {
                    "status": "running",
                    "details": worker_status
                }
            except Exception as e:
                status[name] = {
                    "status": "error",
                    "error": str(e)
                }
        
        return {
            "is_running": self.is_running,
            "workers": status,
            "timestamp": datetime.utcnow().isoformat()
        }
    
    async def execute_worker_task(self, worker_name: str, task_name: str, **kwargs) -> Any:
        """Execute a specific worker task"""
        if worker_name not in self.workers:
            raise ValueError(f"Worker {worker_name} not found")
        
        worker = self.workers[worker_name]
        
        if hasattr(worker, task_name):
            method = getattr(worker, task_name)
            if callable(method):
                return await method(**kwargs)
        
        raise ValueError(f"Task {task_name} not found in worker {worker_name}")


# Global worker manager instance
worker_manager = WorkerManager()


async def start_background_workers():
    """Start all background workers"""
    await worker_manager.start_workers()


async def stop_background_workers():
    """Stop all background workers"""
    await worker_manager.stop_workers()


async def get_worker_status():
    """Get worker status"""
    return await worker_manager.get_worker_status()


__all__ = [
    "WorkerManager",
    "worker_manager",
    "start_background_workers",
    "stop_background_workers",
    "get_worker_status",
]