import asyncio
import logging
from datetime import datetime
from typing import Dict, Any

logger = logging.getLogger(__name__)


class AnalyticsWorker:
    """
    Background worker for analytics aggregation
    """

    def __init__(self, interval_seconds: int = 60):
        self.interval = interval_seconds
        self.running = False
        self.last_run: datetime | None = None

    async def start(self):
        self.running = True
        logger.info("AnalyticsWorker started")

        while self.running:
            try:
                await self.run()
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.exception("AnalyticsWorker error: %s", e)

            await asyncio.sleep(self.interval)

        logger.info("AnalyticsWorker stopped")

    async def stop(self):
        self.running = False

    async def run(self):
        logger.debug("AnalyticsWorker running aggregation job")
        # Placeholder: aggregate analytics data
        self.last_run = datetime.utcnow()

    async def get_status(self) -> Dict[str, Any]:
        return {
            "last_run": self.last_run.isoformat() if self.last_run else None,
            "interval_seconds": self.interval,
        }
