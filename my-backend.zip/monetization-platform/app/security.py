"""
Security utilities for encryption, hashing, and validation
"""
import os
import hashlib
import hmac
import secrets
import string
from datetime import datetime, timedelta
from typing import Optional, Dict, Any, Tuple
import base64
from cryptography.fernet import Fernet
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from passlib.context import CryptContext
import jwt
from fastapi import HTTPException, status

from app.config import settings


# Password hashing context
pwd_context = CryptContext(
    schemes=["bcrypt"],
    deprecated="auto",
    bcrypt__rounds=12
)


class SecurityUtils:
    """Security utility functions"""
    
    @staticmethod
    def hash_password(password: str) -> str:
        """Hash a password using bcrypt"""
        return pwd_context.hash(password)
    
    @staticmethod
    def verify_password(plain_password: str, hashed_password: str) -> bool:
        """Verify a password against its hash"""
        return pwd_context.verify(plain_password, hashed_password)
    
    @staticmethod
    def generate_api_key(length: int = 32) -> Tuple[str, str]:
        """Generate API key and its hash"""
        alphabet = string.ascii_letters + string.digits
        api_key = ''.join(secrets.choice(alphabet) for _ in range(length))
        api_key_hash = hashlib.sha256(api_key.encode()).hexdigest()
        return api_key, api_key_hash
    
    @staticmethod
    def verify_api_key(api_key: str, api_key_hash: str) -> bool:
        """Verify API key against its hash"""
        return hashlib.sha256(api_key.encode()).hexdigest() == api_key_hash
    
    @staticmethod
    def generate_otp(length: int = 6) -> str:
        """Generate OTP code"""
        digits = string.digits
        return ''.join(secrets.choice(digits) for _ in range(length))
    
    @staticmethod
    def generate_session_token() -> str:
        """Generate random session token"""
        return secrets.token_urlsafe(32)
    
    @staticmethod
    def generate_device_fingerprint(
        ip_address: str,
        user_agent: str,
        platform: str,
        accept_language: str
    ) -> str:
        """Generate device fingerprint for fraud detection"""
        fingerprint_string = f"{ip_address}:{user_agent}:{platform}:{accept_language}"
        return hashlib.sha256(fingerprint_string.encode()).hexdigest()
    
    @staticmethod
    def calculate_fraud_score(
        clicks_per_minute: int,
        page_view_times: list,
        ip_reputation: Optional[float] = None
    ) -> float:
        """Calculate fraud score (0-100)"""
        score = 0.0
        
        # Click rate scoring
        if clicks_per_minute > 100:
            score += 40
        elif clicks_per_minute > 50:
            score += 20
        elif clicks_per_minute > 20:
            score += 10
        
        # Page view timing scoring
        if page_view_times:
            avg_time = sum(page_view_times) / len(page_view_times)
            if avg_time < 3:  # Less than 3 seconds average
                score += 30
            elif avg_time < 5:
                score += 15
        
        # IP reputation scoring
        if ip_reputation and ip_reputation < 0.3:  # Bad reputation
            score += 30
        
        return min(score, 100.0)


class EncryptionUtils:
    """Encryption and decryption utilities"""
    
    def __init__(self):
        self.key = base64.urlsafe_b64encode(
            hashlib.sha256(settings.encryption_key.encode()).digest()
        )
        self.cipher = Fernet(self.key)
    
    def encrypt(self, data: str) -> str:
        """Encrypt sensitive data"""
        encrypted = self.cipher.encrypt(data.encode())
        return base64.urlsafe_b64encode(encrypted).decode()
    
    def decrypt(self, encrypted_data: str) -> str:
        """Decrypt sensitive data"""
        try:
            encrypted_bytes = base64.urlsafe_b64decode(encrypted_data.encode())
            decrypted = self.cipher.decrypt(encrypted_bytes)
            return decrypted.decode()
        except Exception:
            raise ValueError("Failed to decrypt data")
    
    def encrypt_dict(self, data: Dict[str, Any], fields: list) -> Dict[str, Any]:
        """Encrypt specific fields in a dictionary"""
        result = data.copy()
        for field in fields:
            if field in result and result[field]:
                result[field] = self.encrypt(str(result[field]))
        return result
    
    def decrypt_dict(self, data: Dict[str, Any], fields: list) -> Dict[str, Any]:
        """Decrypt specific fields in a dictionary"""
        result = data.copy()
        for field in fields:
            if field in result and result[field]:
                result[field] = self.decrypt(result[field])
        return result


class TokenUtils:
    """Token generation and validation utilities"""
    
    @staticmethod
    def create_access_token(
        data: Dict[str, Any],
        expires_delta: Optional[timedelta] = None,
        token_type: str = "access"
    ) -> str:
        """Create JWT access token"""
        to_encode = data.copy()
        
        if expires_delta:
            expire = datetime.utcnow() + expires_delta
        else:
            expire = datetime.utcnow() + timedelta(days=settings.user_token_expire_days)
        
        to_encode.update({
            "exp": expire,
            "iat": datetime.utcnow(),
            "type": token_type,
            "iss": settings.app_name
        })
        
        secret = settings.user_jwt_secret if token_type == "access" else settings.admin_jwt_secret
        
        encoded_jwt = jwt.encode(
            to_encode,
            secret,
            algorithm="HS256"
        )
        
        return encoded_jwt
    
    @staticmethod
    def verify_token(token: str, token_type: str = "access") -> Dict[str, Any]:
        """Verify JWT token"""
        try:
            secret = settings.user_jwt_secret if token_type == "access" else settings.admin_jwt_secret
            
            payload = jwt.decode(
                token,
                secret,
                algorithms=["HS256"],
                options={"require": ["exp", "iat", "type"]}
            )
            
            # Validate token type
            if payload.get("type") != token_type:
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail="Invalid token type"
                )
            
            return payload
            
        except jwt.ExpiredSignatureError:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Token has expired"
            )
        except jwt.InvalidTokenError as e:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail=f"Invalid token: {str(e)}"
            )
    
    @staticmethod
    def create_refresh_token(user_id: str) -> str:
        """Create refresh token"""
        return TokenUtils.create_access_token(
            {"sub": user_id, "type": "refresh"},
            expires_delta=timedelta(days=settings.refresh_token_expire_days)
        )
    
    @staticmethod
    def create_password_reset_token(email: str) -> str:
        """Create password reset token"""
        return TokenUtils.create_access_token(
            {"sub": email, "type": "password_reset"},
            expires_delta=timedelta(hours=1)
        )


class InputSanitizer:
    """Input sanitization utilities"""
    
    @staticmethod
    def sanitize_string(value: str, max_length: int = 255) -> str:
        """Sanitize string input"""
        if not value:
            return value
        
        # Trim whitespace
        value = value.strip()
        
        # Limit length
        if len(value) > max_length:
            value = value[:max_length]
        
        # Remove dangerous characters
        dangerous_chars = ["<", ">", "script", "javascript", "onload", "onerror"]
        for char in dangerous_chars:
            value = value.replace(char, "")
        
        return value
    
    @staticmethod
    def sanitize_url(url: str) -> str:
        """Sanitize URL input"""
        if not url:
            return url
        
        # Ensure URL starts with http:// or https://
        if not url.startswith(("http://", "https://")):
            url = "https://" + url
        
        # Remove dangerous protocols
        dangerous_protocols = ["javascript:", "data:", "file:"]
        for protocol in dangerous_protocols:
            if url.startswith(protocol):
                raise ValueError(f"Dangerous protocol: {protocol}")
        
        return url
    
    @staticmethod
    def sanitize_email(email: str) -> str:
        """Sanitize email input"""
        if not email:
            return email
        
        email = email.strip().lower()
        
        # Basic email validation
        if "@" not in email or "." not in email:
            raise ValueError("Invalid email format")
        
        # Remove dangerous characters
        dangerous_chars = ["<", ">", "(", ")", "[", "]", ";", ":", ","]
        for char in dangerous_chars:
            email = email.replace(char, "")
        
        return email
    
    @staticmethod
    def sanitize_phone(phone: str) -> str:
        """Sanitize phone number input"""
        if not phone:
            return phone
        
        # Remove all non-digit characters except +
        cleaned = ""
        for char in phone:
            if char.isdigit() or char == "+":
                cleaned += char
        
        return cleaned


# Global instances
security_utils = SecurityUtils()
encryption_utils = EncryptionUtils()
token_utils = TokenUtils()
input_sanitizer = InputSanitizer()