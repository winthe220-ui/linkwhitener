from datetime import datetime
from typing import Optional, List, Dict, Any

from app.models.admin import Admin, AdminStatus
from app.core.firestore_client import firestore_client
from app.core.cache import cache_manager


class AdminService:
    """Admin management service"""

    async def get_admin_by_email(self, email: str) -> Optional[Admin]:
        data = await firestore_client.get_document("admins", email)
        return Admin(**data) if data else None

    async def record_failed_login(self, admin_id: str, ip_address: str, user_agent: str):
        await firestore_client.update_document(
            "admins",
            admin_id,
            {
                "failed_logins": firestore_client.Increment(1),
                "last_failed_login": datetime.utcnow(),
                "last_failed_ip": ip_address,
                "last_failed_user_agent": user_agent,
            },
        )

    async def record_successful_login(self, admin_id: str, ip_address: str, user_agent: str):
        await firestore_client.update_document(
            "admins",
            admin_id,
            {
                "last_login": datetime.utcnow(),
                "last_login_ip": ip_address,
                "last_login_user_agent": user_agent,
                "failed_logins": 0,
            },
        )

    async def list_admins(self, page: int = 1, limit: int = 20):
        admins = await firestore_client.list_documents("admins", limit=limit)
        return [Admin(**a) for a in admins], len(admins), False

    async def deactivate_admin(self, admin_id: str, reason: str):
        await firestore_client.update_document(
            "admins",
            admin_id,
            {
                "status": AdminStatus.INACTIVE,
                "deactivated_at": datetime.utcnow(),
                "deactivation_reason": reason,
            },
        )
        await cache_manager.clear_pattern("admin_session:*")
        return True


admin_service = AdminService()
