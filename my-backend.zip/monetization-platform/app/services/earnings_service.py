from datetime import datetime
from typing import Dict, Any

from app.core.firestore_client import firestore_client


class EarningsService:
    """Earnings service"""

    async def get_user_earnings_summary(self, user_uid: str) -> Dict[str, Any]:
        data = await firestore_client.get_document("earnings", user_uid)
        return data or {}

    async def add_earnings(self, user_uid: str, amount: float):
        await firestore_client.update_document(
            "earnings",
            user_uid,
            {
                "available_balance": firestore_client.Increment(amount),
                "total_earned": firestore_client.Increment(amount),
                "updated_at": datetime.utcnow(),
            },
        )


earnings_service = EarningsService()
