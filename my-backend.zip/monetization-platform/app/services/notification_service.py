class NotificationService:
    """Notification delivery service"""

    async def send_welcome_email(self, email: str, username: str, referral_code: str):
        return True

    async def send_link_created_notification(self, email: str, username: str, link_title: str):
        return True

    async def send_account_suspended_notification(self, user_uid: str, reason: str, duration_days: int):
        return True

    async def send_account_banned_notification(self, user_uid: str, reason: str):
        return True

    async def send_account_reinstated_notification(self, user_uid: str):
        return True

    async def send_referral_bonus_notification(self, user_uid: str, amount: float, referred_user: str):
        return True

    async def send_withdrawal_request_notification(self, withdrawal_id: str):
        return True


notification_service = NotificationService()
