from typing import Optional, List, Dict, Any, Tuple
from datetime import datetime, timedelta
import uuid
import hashlib

from app.models.user import User, UserStatus, UserTier
from app.core.firestore_client import firestore_client
from app.core.auth import auth_service
from app.utils.generators import generate_referral_code
from app.utils.validators import validate_phone, validate_email
from app.services.notification_service import notification_service


class UserService:
    """Service for user management operations"""
    
    def __init__(self):
        self.firestore = firestore_client
    
    async def get_user_by_uid(self, uid: str) -> Optional[User]:
        """Get user by UID"""
        user_data = await self.firestore.get_document("users", uid)
        if user_data:
            return User(**user_data)
        return None
    
    async def create_user(
        self,
        uid: str,
        phone: str,
        email: Optional[str] = None,
        username: Optional[str] = None,
        ip_address: Optional[str] = None,
        user_agent: Optional[str] = None,
        referred_by: Optional[str] = None
    ) -> User:
        """Create new user"""
        # Generate username if not provided
        if not username:
            username = f"user_{uid[:8]}"
        
        # Generate referral code
        referral_code = generate_referral_code()
        
        # Create user model
        user = User(
            uid=uid,
            phone=phone,
            email=email,
            username=username,
            status=UserStatus.ACTIVE,
            tier=UserTier.BASIC,
            created_at=datetime.utcnow(),
            updated_at=datetime.utcnow(),
            last_login=datetime.utcnow(),
            last_active=datetime.utcnow(),
            is_phone_verified=True,
            referral_code=referral_code,
            referred_by=referred_by,
            metadata={
                "signup_ip": ip_address,
                "signup_user_agent": user_agent,
                "signup_time": datetime.utcnow().isoformat()
            }
        )
        
        # Validate data
        validate_phone(phone)
        if email:
            validate_email(email)
        
        # Check if username is available
        if username:
            existing = await self.firestore.query_document(
                collection="users",
                field="username",
                op="==",
                value=username
            )
            if existing:
                # Append numbers to username
                counter = 1
                while True:
                    new_username = f"{username}{counter}"
                    existing = await self.firestore.query_document(
                        collection="users",
                        field="username",
                        op="==",
                        value=new_username
                    )
                    if not existing:
                        user.username = new_username
                        break
                    counter += 1
        
        # Save to Firestore
        await self.firestore.create_document(
            collection="users",
            document_id=uid,
            data=user.to_firestore()
        )
        
        # Create earnings record
        earnings_data = {
            "user_uid": uid,
            "available_balance": 0.0,
            "pending_withdrawal": 0.0,
            "total_earned": 0.0,
            "withdrawn_amount": 0.0,
            "referral_earnings": 0.0,
            "bonus_earnings": 0.0,
            "today_earnings": 0.0,
            "yesterday_earnings": 0.0,
            "this_month_earnings": 0.0,
            "last_month_earnings": 0.0,
            "valid_page3_views": 0,
            "created_at": datetime.utcnow(),
            "updated_at": datetime.utcnow()
        }
        await self.firestore.create_document(
            collection="earnings",
            document_id=uid,
            data=earnings_data
        )
        
        # Handle referral if applicable
        if referred_by:
            await self.handle_referral_signup(uid, referred_by)
        
        return user
    
    async def update_user_login(
        self,
        user_uid: str,
        ip_address: str,
        user_agent: str
    ) -> User:
        """Update user login information"""
        update_data = {
            "last_login": datetime.utcnow(),
            "last_active": datetime.utcnow(),
            "login_attempts": 0,
            "metadata.last_login_ip": ip_address,
            "metadata.last_login_time": datetime.utcnow().isoformat(),
            "metadata.last_user_agent": user_agent
        }
        
        await self.firestore.update_document(
            collection="users",
            document_id=user_uid,
            data=update_data
        )
        
        # Get updated user
        return await self.get_user_by_uid(user_uid)
    
    async def update_user_profile(
        self,
        user_uid: str,
        update_data: Dict[str, Any]
    ) -> User:
        """Update user profile"""
        allowed_fields = [
            "username", "full_name", "avatar_url", "bio",
            "date_of_birth", "gender", "language", "timezone",
            "payout_preferences", "notification_preferences"
        ]
        
        # Filter allowed fields
        filtered_data = {
            k: v for k, v in update_data.items() 
            if k in allowed_fields
        }
        
        if not filtered_data:
            raise ValueError("No valid fields to update")
        
        # Add update timestamp
        filtered_data["updated_at"] = datetime.utcnow()
        
        # Update in Firestore
        await self.firestore.update_document(
            collection="users",
            document_id=user_uid,
            data=filtered_data
        )
        
        # Get updated user
        return await self.get_user_by_uid(user_uid)
    
    async def get_user_earnings_summary(self, user_uid: str) -> Dict[str, Any]:
        """Get user earnings summary"""
        earnings = await self.firestore.get_document("earnings", user_uid)
        if not earnings:
            # Create default earnings record
            earnings = {
                "available_balance": 0.0,
                "pending_withdrawal": 0.0,
                "total_earned": 0.0,
                "withdrawn_amount": 0.0,
                "referral_earnings": 0.0,
                "bonus_earnings": 0.0,
                "today_earnings": 0.0,
                "valid_page3_views": 0
            }
        
        # Calculate estimated monthly earnings
        today = datetime.utcnow()
        days_in_month = 30
        
        # Simple estimation based on daily average
        estimated_monthly = earnings.get("today_earnings", 0.0) * days_in_month
        
        return {
            "total_earned": earnings.get("total_earned", 0.0),
            "available_balance": earnings.get("available_balance", 0.0),
            "pending_withdrawal": earnings.get("pending_withdrawal", 0.0),
            "withdrawn_amount": earnings.get("withdrawn_amount", 0.0),
            "referral_earnings": earnings.get("referral_earnings", 0.0),
            "bonus_earnings": earnings.get("bonus_earnings", 0.0),
            "today_earnings": earnings.get("today_earnings", 0.0),
            "yesterday_earnings": earnings.get("yesterday_earnings", 0.0),
            "this_month_earnings": earnings.get("this_month_earnings", 0.0),
            "last_month_earnings": earnings.get("last_month_earnings", 0.0),
            "estimated_monthly": estimated_monthly,
            "valid_page3_views": earnings.get("valid_page3_views", 0)
        }
    
    async def handle_referral_signup(self, new_user_uid: str, referrer_uid: str):
        """Handle new user signup via referral"""
        try:
            # Get referrer
            referrer = await self.get_user_by_uid(referrer_uid)
            if not referrer:
                return
            
            # Update referrer's count
            await self.firestore.update_document(
                collection="users",
                document_id=referrer_uid,
                data={
                    "referral_count": referrer.referral_count + 1,
                    "updated_at": datetime.utcnow()
                }
            )
            
            # Add referral bonus to referrer
            referral_bonus = settings.referral_bonus
            
            # Update referrer's earnings
            await self.firestore.update_document(
                collection="earnings",
                document_id=referrer_uid,
                data={
                    "referral_earnings": firestore_client.Increment(referral_bonus),
                    "available_balance": firestore_client.Increment(referral_bonus),
                    "total_earned": firestore_client.Increment(referral_bonus),
                    "updated_at": datetime.utcnow()
                }
            )
            
            # Create transaction record
            transaction_data = {
                "transaction_id": f"ref_{str(uuid.uuid4())[:8]}",
                "user_uid": referrer_uid,
                "amount": referral_bonus,
                "type": "referral",
                "description": f"Referral bonus for {new_user_uid}",
                "created_at": datetime.utcnow(),
                "metadata": {
                    "referred_user": new_user_uid
                }
            }
            await firestore_client.create_document(
                collection="transactions",
                document_id=transaction_data["transaction_id"],
                data=transaction_data
            )
            
            # Send notification to referrer
            await notification_service.send_referral_bonus_notification(
                user_uid=referrer_uid,
                amount=referral_bonus,
                referred_user=new_user_uid
            )
            
        except Exception as e:
            # Log error but don't fail user registration
            print(f"Error handling referral: {str(e)}")
    
    async def search_users(
        self,
        query: str,
        field: str = "username",
        page: int = 1,
        limit: int = 20
    ) -> Tuple[List[User], int, bool]:
        """Search users by field"""
        offset = (page - 1) * limit
        
        # Firestore doesn't have native offset, use pagination with startAfter
        users_data = await self.firestore.query_document(
            collection="users",
            field=field,
            op=">=",
            value=query,
            limit=limit + 1  # Get one extra to check if there are more
        )
        
        has_next = len(users_data) > limit
        users_data = users_data[:limit]
        
        users = [User(**data) for data in users_data]
        total = len(users_data)  # Note: Firestore doesn't provide total count easily
        
        return users, total, has_next
    
    async def suspend_user(
        self,
        user_uid: str,
        reason: str,
        duration_days: int = 7,
        admin_id: Optional[str] = None
    ) -> bool:
        """Suspend user account"""
        suspended_until = datetime.utcnow() + timedelta(days=duration_days)
        
        update_data = {
            "status": UserStatus.SUSPENDED,
            "suspended_until": suspended_until,
            "suspension_reason": reason,
            "suspended_by": admin_id,
            "updated_at": datetime.utcnow()
        }
        
        await self.firestore.update_document(
            collection="users",
            document_id=user_uid,
            data=update_data
        )
        
        # Revoke all user tokens
        await auth_service.revoke_all_user_tokens(user_uid)
        
        # Send suspension notification
        await notification_service.send_account_suspended_notification(
            user_uid=user_uid,
            reason=reason,
            duration_days=duration_days
        )
        
        return True
    
    async def ban_user(
        self,
        user_uid: str,
        reason: str,
        admin_id: Optional[str] = None
    ) -> bool:
        """Permanently ban user"""
        update_data = {
            "status": UserStatus.BANNED,
            "suspension_reason": reason,
            "suspended_by": admin_id,
            "updated_at": datetime.utcnow(),
            "banned_at": datetime.utcnow()
        }
        
        await self.firestore.update_document(
            collection="users",
            document_id=user_uid,
            data=update_data
        )
        
        # Revoke all user tokens
        await auth_service.revoke_all_user_tokens(user_uid)
        
        # Send ban notification
        await notification_service.send_account_banned_notification(
            user_uid=user_uid,
            reason=reason
        )
        
        return True
    
    async def reinstate_user(
        self,
        user_uid: str,
        admin_id: Optional[str] = None
    ) -> bool:
        """Reinstate suspended/banned user"""
        update_data = {
            "status": UserStatus.ACTIVE,
            "suspended_until": None,
            "suspension_reason": None,
            "suspended_by": None,
            "updated_at": datetime.utcnow(),
            "reinstated_at": datetime.utcnow(),
            "reinstated_by": admin_id
        }
        
        await self.firestore.update_document(
            collection="users",
            document_id=user_uid,
            data=update_data
        )
        
        # Send reinstatement notification
        await notification_service.send_account_reinstated_notification(
            user_uid=user_uid
        )
        
        return True
    
    async def send_welcome_notification(self, user_uid: str, username: str):
        """Send welcome notification to new user"""
        user = await self.get_user_by_uid(user_uid)
        if user:
            await notification_service.send_welcome_email(
                email=user.email,
                username=username,
                referral_code=user.referral_code
            )
    
    async def notify_link_created(self, user_uid: str, link_title: str):
        """Send notification when user creates a link"""
        user = await self.get_user_by_uid(user_uid)
        if user and user.email:
            await notification_service.send_link_created_notification(
                email=user.email,
                username=user.username,
                link_title=link_title
            )


# Singleton instance
user_service = UserService()