from datetime import datetime
from typing import Optional, List, Dict, Any
import uuid

from app.core.firestore_client import firestore_client
from app.core.cache import cache_manager
from app.models.link import Link, LinkStatus


class LinkService:
    """Link management service"""

    async def create_link(
        self,
        user_uid: str,
        original_url: str,
        title: Optional[str],
        description: Optional[str],
        tags: Optional[List[str]],
        metadata: Optional[Dict[str, Any]],
        ip_address: str,
    ) -> Link:
        link_id = f"link_{uuid.uuid4().hex[:10]}"
        short_code = uuid.uuid4().hex[:6]

        link_data = {
            "link_id": link_id,
            "user_uid": user_uid,
            "short_code": short_code,
            "short_url": f"https://yourdomain.com/{short_code}",
            "original_url": original_url,
            "title": title,
            "description": description,
            "tags": tags or [],
            "metadata": metadata or {},
            "status": LinkStatus.ACTIVE,
            "created_at": datetime.utcnow(),
            "updated_at": datetime.utcnow(),
            "total_clicks": 0,
            "earnings_total": 0.0,
            "ip_address": ip_address,
        }

        await firestore_client.create_document("links", link_id, link_data)

        return Link(**link_data)

    async def get_user_links(
        self,
        user_uid: str,
        status: Optional[str],
        page: int,
        limit: int,
    ):
        filters = [("user_uid", "==", user_uid)]
        if status:
            filters.append(("status", "==", status))

        links = await firestore_client.query_documents(
            "links",
            filters=filters,
            limit=limit,
            offset=(page - 1) * limit,
        )

        return [Link(**l) for l in links], len(links), False

    async def disable_link(self, link_id: str, user_uid: str):
        await firestore_client.update_document(
            "links",
            link_id,
            {
                "status": LinkStatus.DISABLED,
                "updated_at": datetime.utcnow(),
            },
        )
        return True

    async def delete_link(self, link_id: str, user_uid: str):
        await firestore_client.delete_document("links", link_id)
        await cache_manager.delete(f"link:{link_id}")
        return True

    async def get_link_analytics(
        self,
        link_id: str,
        user_uid: str,
        period: str,
    ):
        analytics = await firestore_client.get_document("analytics", link_id)
        return analytics or {}

    async def index_link_for_search(self, link_id: str):
        # Placeholder for search indexing
        return True

    async def cleanup_link_data(self, link_id: str):
        await firestore_client.delete_document("analytics", link_id)
        return True


link_service = LinkService()
