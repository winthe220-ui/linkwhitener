from datetime import datetime
from typing import Dict, Any, Tuple, List
import uuid

from app.core.firestore_client import firestore_client
from app.core.cache import cache_manager


class WithdrawalService:
    """Withdrawal handling service"""

    async def request_withdrawal(
        self,
        user_uid: str,
        amount: float,
        method: str,
        payment_details: Dict[str, Any],
        ip_address: str,
        user_agent: str,
    ):
        withdrawal_id = f"wd_{uuid.uuid4().hex[:10]}"

        data = {
            "withdrawal_id": withdrawal_id,
            "user_uid": user_uid,
            "amount": amount,
            "method": method,
            "status": "pending",
            "payment_details": payment_details,
            "requested_at": datetime.utcnow(),
            "ip_address": ip_address,
            "user_agent": user_agent,
        }

        await firestore_client.create_document(
            "withdrawals", withdrawal_id, data
        )
        return type("Withdrawal", (), data)

    async def get_withdrawal_history(
        self,
        user_uid: str,
        status: str | None,
        page: int,
        limit: int,
        **_
    ):
        withdrawals = await firestore_client.query_document(
            "withdrawals", "user_uid", "==", user_uid
        )
        return withdrawals, len(withdrawals), False

    async def cancel_withdrawal(self, withdrawal_id: str, user_uid: str):
        await firestore_client.update_document(
            "withdrawals",
            withdrawal_id,
            {
                "status": "cancelled",
                "cancelled_at": datetime.utcnow(),
            },
        )
        return True

    async def get_user_withdrawal_stats(self, user_uid: str):
        return {
            "total_withdrawn": 0.0,
            "total_withdrawals": 0,
            "pending_withdrawals": 0,
            "pending_amount": 0.0,
        }


withdrawal_service = WithdrawalService()
