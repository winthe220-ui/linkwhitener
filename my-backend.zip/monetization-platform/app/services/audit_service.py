from datetime import datetime
from typing import Dict, Any
import uuid

from app.core.firestore_client import firestore_client


class AuditService:
    """Audit logging service"""

    async def create_user_action(
        self,
        user_uid: str,
        action: str,
        resource: str,
        resource_id: str,
        details: Dict[str, Any],
        ip_address: str,
    ):
        await firestore_client.create_document(
            "audit_logs",
            f"audit_{uuid.uuid4().hex}",
            {
                "user_uid": user_uid,
                "action": action,
                "resource": resource,
                "resource_id": resource_id,
                "details": details,
                "ip_address": ip_address,
                "created_at": datetime.utcnow(),
            },
        )

    async def create_admin_action(
        self,
        admin_id: str,
        action: str,
        resource: str,
        details: Dict[str, Any],
    ):
        await firestore_client.create_document(
            "audit_logs",
            f"audit_{uuid.uuid4().hex}",
            {
                "admin_id": admin_id,
                "action": action,
                "resource": resource,
                "details": details,
                "created_at": datetime.utcnow(),
            },
        )


audit_service = AuditService()
