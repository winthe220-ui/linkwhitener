from datetime import datetime
from typing import Dict, Any

from app.core.firestore_client import firestore_client


class AnalyticsService:
    """Analytics service"""

    async def create_link_analytics(self, link_id: str):
        await firestore_client.create_document(
            "analytics",
            link_id,
            {
                "link_id": link_id,
                "clicks": 0,
                "page_views": 0,
                "conversions": 0,
                "earnings": 0.0,
                "created_at": datetime.utcnow(),
                "updated_at": datetime.utcnow(),
            },
        )

    async def increment_metric(self, link_id: str, metric: str, value: int = 1):
        await firestore_client.update_document(
            "analytics",
            link_id,
            {
                metric: firestore_client.Increment(value),
                "updated_at": datetime.utcnow(),
            },
        )


analytics_service = AnalyticsService()
