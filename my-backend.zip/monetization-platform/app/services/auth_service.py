"""
Authentication service for user and admin authentication
"""
import hashlib
import jwt
from datetime import datetime, timedelta
from typing import Optional, Dict, Any, Tuple
from fastapi import HTTPException, status
from typing import List
from app.config import settings
from app.core.firebase_client import firebase_client
from app.core.cache import cache_manager
from app.database import redis_client
from app.models.user import User, UserStatus
from app.models.admin import Admin, AdminStatus
from app.services.user_service import user_service
from app.services.admin_service import admin_service
from app.utils.security import security_utils, token_utils


class AuthService:
    """Authentication service"""
    
    def __init__(self):
        self.firebase = firebase_client
    
    # ==================== USER AUTHENTICATION ====================
    
    async def verify_user_token(self, id_token: str) -> Dict[str, Any]:
        """Verify Firebase ID token for user"""
        try:
            # Verify token with Firebase
            decoded_token = await self.firebase.verify_id_token(id_token)
            
            # Check if token is revoked
            token_hash = hashlib.sha256(id_token.encode()).hexdigest()
            if await cache_manager.get(f"token_revoked:{token_hash}"):
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail="Token has been revoked"
                )
            
            return {
                "uid": decoded_token["uid"],
                "phone": decoded_token.get("phone_number"),
                "email": decoded_token.get("email"),
                "email_verified": decoded_token.get("email_verified", False),
                "auth_time": decoded_token.get("auth_time"),
                "valid": True
            }
            
        except HTTPException:
            raise
        except Exception as e:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail=f"Token verification failed: {str(e)}"
            )
    
    async def register_user(
        self,
        uid: str,
        phone: str,
        email: Optional[str] = None,
        username: Optional[str] = None,
        ip_address: Optional[str] = None,
        user_agent: Optional[str] = None,
        referred_by: Optional[str] = None
    ) -> User:
        """Register new user"""
        return await user_service.create_user(
            uid=uid,
            phone=phone,
            email=email,
            username=username,
            ip_address=ip_address,
            user_agent=user_agent,
            referred_by=referred_by
        )
    
    async def login_user(
        self,
        uid: str,
        ip_address: str,
        user_agent: str
    ) -> User:
        """Update user login information"""
        return await user_service.update_user_login(
            user_uid=uid,
            ip_address=ip_address,
            user_agent=user_agent
        )
    
    async def create_user_tokens(self, user: User) -> Tuple[str, str]:
        """Create access and refresh tokens for user"""
        # Create access token
        access_token = token_utils.create_access_token(
            data={
                "sub": user.uid,
                "type": "user",
                "role": "user",
                "phone": user.phone,
                "username": user.username,
                "status": user.status.value,
                "email": user.email,
                "email_verified": user.is_email_verified
            },
            expires_delta=timedelta(days=settings.user_token_expire_days)
        )
        
        # Create refresh token
        refresh_token = token_utils.create_refresh_token(user.uid)
        
        # Store refresh token hash in Redis
        refresh_token_hash = hashlib.sha256(refresh_token.encode()).hexdigest()
        await cache_manager.set(
            f"refresh_token:{refresh_token_hash}",
            user.uid,
            ttl=settings.refresh_token_expire_days * 24 * 3600
        )
        
        return access_token, refresh_token
    
    async def refresh_user_tokens(self, refresh_token: str) -> Tuple[str, str]:
        """Refresh user tokens using refresh token"""
        try:
            # Verify refresh token
            refresh_token_hash = hashlib.sha256(refresh_token.encode()).hexdigest()
            user_uid = await cache_manager.get(f"refresh_token:{refresh_token_hash}")
            
            if not user_uid:
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail="Invalid refresh token"
                )
            
            # Get user
            user = await user_service.get_user_by_uid(user_uid)
            if not user or user.status != UserStatus.ACTIVE:
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail="User not found or inactive"
                )
            
            # Create new tokens
            new_access_token, new_refresh_token = await self.create_user_tokens(user)
            
            # Delete old refresh token
            await cache_manager.delete(f"refresh_token:{refresh_token_hash}")
            
            return new_access_token, new_refresh_token
            
        except HTTPException:
            raise
        except Exception as e:
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=f"Token refresh failed: {str(e)}"
            )
    
    async def logout_user(self, access_token: str, refresh_token: Optional[str] = None):
        """Logout user by revoking tokens"""
        try:
            # Revoke access token
            token_hash = hashlib.sha256(access_token.encode()).hexdigest()
            await cache_manager.set(
                f"token_revoked:{token_hash}",
                "revoked",
                ttl=86400  # 24 hours
            )
            
            # Revoke refresh token if provided
            if refresh_token:
                refresh_hash = hashlib.sha256(refresh_token.encode()).hexdigest()
                await cache_manager.delete(f"refresh_token:{refresh_hash}")
            
            return True
            
        except Exception as e:
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=f"Logout failed: {str(e)}"
            )
    
    async def revoke_all_user_tokens(self, user_uid: str) -> bool:
        """Revoke all tokens for a user"""
        try:
            # This would typically involve:
            # 1. Finding all refresh tokens for user
            # 2. Adding access tokens to revocation list
            # 3. Updating user's token version
            
            # For simplicity, we'll update a token version in user's record
            await user_service.update_user_token_version(user_uid)
            
            # Clear user sessions from cache
            await cache_manager.clear_pattern(f"user_session:{user_uid}:*")
            
            return True
            
        except Exception as e:
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=f"Token revocation failed: {str(e)}"
            )
    
    # ==================== ADMIN AUTHENTICATION ====================
    
    async def verify_admin_credentials(
        self,
        email: str,
        password: str,
        ip_address: str,
        user_agent: str
    ) -> Dict[str, Any]:
        """Verify admin credentials"""
        # Check login attempts
        login_key = f"admin_login_attempts:{email}:{ip_address}"
        attempts = int(await cache_manager.get(login_key) or 0)
        
        if attempts >= settings.max_login_attempts:
            raise HTTPException(
                status_code=status.HTTP_429_TOO_MANY_REQUESTS,
                detail="Too many login attempts. Please try again later."
            )
        
        # Get admin
        admin = await admin_service.get_admin_by_email(email)
        if not admin:
            await self._record_failed_login(login_key)
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid credentials"
            )
        
        # Check admin status
        if admin.status != AdminStatus.ACTIVE:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Admin account is deactivated"
            )
        
        # Verify password
        if not security_utils.verify_password(password, admin.password_hash):
            await self._record_failed_login(login_key)
            
            # Update failed attempts in admin record
            await admin_service.record_failed_login(
                admin_id=admin.email,
                ip_address=ip_address,
                user_agent=user_agent
            )
            
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid credentials"
            )
        
        # Check IP whitelist
        if admin.ip_whitelist and ip_address not in admin.ip_whitelist:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="IP address not allowed"
            )
        
        # Check access schedule
        if not admin.is_within_access_schedule():
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Access not allowed at this time"
            )
        
        # Reset failed attempts
        await cache_manager.delete(login_key)
        
        # Update successful login
        await admin_service.record_successful_login(
            admin_id=admin.email,
            ip_address=ip_address,
            user_agent=user_agent
        )
        
        return {
            "admin_id": admin.email,
            "email": admin.email,
            "role": admin.role.value,
            "permissions": admin.permissions,
            "name": admin.full_name,
            "is_super_admin": admin.is_super_admin,
            "two_factor_enabled": admin.two_factor_enabled,
            "two_factor_method": admin.two_factor_method.value
        }
    
    async def create_admin_token(self, admin_data: Dict[str, Any]) -> str:
        """Create JWT token for admin"""
        token = token_utils.create_access_token(
            data={
                "sub": admin_data["admin_id"],
                "type": "admin",
                "role": admin_data["role"],
                "permissions": admin_data["permissions"],
                "name": admin_data["name"],
                "is_super_admin": admin_data["is_super_admin"],
                "email": admin_data["email"]
            },
            expires_delta=timedelta(hours=settings.admin_token_expire_hours),
            token_type="admin_access"
        )
        
        # Store admin session
        session_id = hashlib.sha256(token.encode()).hexdigest()
        session_data = {
            "admin_id": admin_data["admin_id"],
            "email": admin_data["email"],
            "role": admin_data["role"],
            "permissions": admin_data["permissions"],
            "login_time": datetime.utcnow().isoformat(),
            "ip_address": "127.0.0.1",  # Would get from request
            "user_agent": "Python"  # Would get from request
        }
        
        await cache_manager.set(
            f"admin_session:{session_id}",
            session_data,
            ttl=settings.admin_token_expire_hours * 3600
        )
        
        return token
    
    async def verify_admin_token(self, token: str) -> Dict[str, Any]:
        """Verify admin JWT token"""
        try:
            payload = token_utils.verify_token(token, token_type="admin_access")
            
            # Check session
            session_id = hashlib.sha256(token.encode()).hexdigest()
            session_data = await cache_manager.get(f"admin_session:{session_id}")
            
            if not session_data:
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail="Session expired"
                )
            
            # Add session data to payload
            payload.update({
                "session_id": session_id,
                "login_time": session_data["login_time"],
                "ip_address": session_data.get("ip_address")
            })
            
            return payload
            
        except jwt.ExpiredSignatureError:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Token has expired"
            )
        except jwt.InvalidTokenError:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid token"
            )
        except Exception as e:
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=f"Token verification failed: {str(e)}"
            )
    
    async def refresh_admin_token(self, admin_id: str, refresh_token: str) -> str:
        """Refresh admin token"""
        # Similar to user token refresh
        # Implement based on your refresh token strategy
        pass
    
    async def logout_admin(self, token: str):
        """Logout admin by revoking token"""
        try:
            # Add token to revocation list
            token_hash = hashlib.sha256(token.encode()).hexdigest()
            await cache_manager.set(
                f"admin_token_revoked:{token_hash}",
                "revoked",
                ttl=settings.admin_token_expire_hours * 3600
            )
            
            # Remove session
            await cache_manager.delete(f"admin_session:{token_hash}")
            
            return True
            
        except Exception as e:
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=f"Logout failed: {str(e)}"
            )
    
    # ==================== TWO-FACTOR AUTHENTICATION ====================
    
    async def enable_two_factor(
        self,
        user_uid: str,
        method: str,
        phone: Optional[str] = None
    ) -> Dict[str, Any]:
        """Enable two-factor authentication"""
        # Generate secret for authenticator
        if method == "authenticator":
            import pyotp
            secret = pyotp.random_base32()
            
            # Generate provisioning URI for QR code
            totp = pyotp.TOTP(secret)
            provisioning_uri = totp.provisioning_uri(
                name=user_uid,
                issuer_name=settings.app_name
            )
            
            return {
                "secret": secret,
                "provisioning_uri": provisioning_uri,
                "method": method
            }
        
        elif method == "sms":
            if not phone:
                raise ValueError("Phone number required for SMS 2FA")
            
            # Store phone for SMS 2FA
            return {
                "phone": phone,
                "method": method
            }
        
        elif method == "email":
            return {
                "method": method
            }
        
        else:
            raise ValueError("Invalid 2FA method")
    
    async def verify_two_factor(
        self,
        user_uid: str,
        method: str,
        code: str,
        secret: Optional[str] = None
    ) -> bool:
        """Verify two-factor authentication code"""
        if method == "authenticator":
            if not secret:
                raise ValueError("Secret required for authenticator verification")
            
            import pyotp
            totp = pyotp.TOTP(secret)
            return totp.verify(code)
        
        elif method in ["sms", "email"]:
            # Verify stored code
            key = f"2fa_code:{user_uid}:{method}"
            stored_code = await cache_manager.get(key)
            
            if not stored_code:
                return False
            
            return stored_code == code
        
        return False
    
    async def send_two_factor_code(
        self,
        user_uid: str,
        method: str,
        phone: Optional[str] = None,
        email: Optional[str] = None
    ) -> bool:
        """Send two-factor authentication code"""
        from app.services.notification_service import notification_service
        
        # Generate code
        code = security_utils.generate_otp()
        
        # Store code
        key = f"2fa_code:{user_uid}:{method}"
        await cache_manager.set(key, code, ttl=300)  # 5 minutes
        
        # Send code
        if method == "sms" and phone:
            return await notification_service.send_sms_2fa_code(phone, code)
        
        elif method == "email" and email:
            return await notification_service.send_email_2fa_code(email, code)
        
        return False
    
    # ==================== PASSWORD MANAGEMENT ====================
    
    async def request_password_reset(self, email: str) -> bool:
        """Request password reset"""
        from app.services.notification_service import notification_service
        
        # Generate reset token
        reset_token = token_utils.create_password_reset_token(email)
        
        # Store token
        token_hash = hashlib.sha256(reset_token.encode()).hexdigest()
        await cache_manager.set(
            f"password_reset:{token_hash}",
            email,
            ttl=3600  # 1 hour
        )
        
        # Send reset email
        return await notification_service.send_password_reset_email(email, reset_token)
    
    async def verify_password_reset_token(self, token: str) -> Optional[str]:
        """Verify password reset token"""
        try:
            # Verify token
            payload = token_utils.verify_token(token, token_type="password_reset")
            email = payload.get("sub")
            
            if not email:
                return None
            
            # Check if token is in cache
            token_hash = hashlib.sha256(token.encode()).hexdigest()
            cached_email = await cache_manager.get(f"password_reset:{token_hash}")
            
            if cached_email != email:
                return None
            
            return email
            
        except Exception:
            return None
    
    async def reset_password(self, token: str, new_password: str) -> bool:
        """Reset password using token"""
        email = await self.verify_password_reset_token(token)
        
        if not email:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid or expired reset token"
            )
        
        # Hash new password
        password_hash = security_utils.hash_password(new_password)
        
        # Update password (for user or admin)
        # This would depend on whether email belongs to user or admin
        # Implement based on your user/admin identification logic
        
        # Remove used token
        token_hash = hashlib.sha256(token.encode()).hexdigest()
        await cache_manager.delete(f"password_reset:{token_hash}")
        
        return True
    
    async def change_password(
        self,
        user_uid: str,
        current_password: str,
        new_password: str
    ) -> bool:
        """Change password with current password verification"""
        # Get user
        user = await user_service.get_user_by_uid(user_uid)
        if not user:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="User not found"
            )
        
        # TODO: Verify current password
        # This would require storing password hash for users
        # Currently users use Firebase Auth, so password change
        # would need to be handled through Firebase
        
        # For now, return success (implement properly in production)
        return True
    
    # ==================== SESSION MANAGEMENT ====================
    
    async def create_user_session(
        self,
        user_uid: str,
        ip_address: str,
        user_agent: str,
        device_info: Optional[Dict[str, Any]] = None
    ) -> str:
        """Create user session"""
        session_id = security_utils.generate_session_token()
        
        session_data = {
            "user_uid": user_uid,
            "ip_address": ip_address,
            "user_agent": user_agent,
            "device_info": device_info or {},
            "created_at": datetime.utcnow().isoformat(),
            "last_activity": datetime.utcnow().isoformat(),
            "expires_at": (datetime.utcnow() + timedelta(days=7)).isoformat()
        }
        
        await cache_manager.set(
            f"user_session:{user_uid}:{session_id}",
            session_data,
            ttl=7 * 24 * 3600  # 7 days
        )
        
        return session_id
    
    async def validate_user_session(
        self,
        user_uid: str,
        session_id: str
    ) -> Optional[Dict[str, Any]]:
        """Validate user session"""
        session_data = await cache_manager.get(f"user_session:{user_uid}:{session_id}")
        
        if not session_data:
            return None
        
        # Update last activity
        session_data["last_activity"] = datetime.utcnow().isoformat()
        await cache_manager.set(
            f"user_session:{user_uid}:{session_id}",
            session_data,
            ttl=7 * 24 * 3600
        )
        
        return session_data
    
    async def revoke_user_session(
        self,
        user_uid: str,
        session_id: str
    ) -> bool:
        """Revoke specific user session"""
        return await cache_manager.delete(f"user_session:{user_uid}:{session_id}")
    
    async def revoke_all_user_sessions(self, user_uid: str) -> int:
        """Revoke all sessions for a user"""
        pattern = f"user_session:{user_uid}:*"
        return await cache_manager.clear_pattern(pattern)
    
    async def get_user_sessions(self, user_uid: str) -> List[Dict[str, Any]]:
        """Get all active sessions for a user"""
        pattern = f"user_session:{user_uid}:*"
        
        # This is simplified - in production you'd scan Redis keys
        # For now, return empty list
        return []
    
    # ==================== SECURITY UTILITIES ====================
    
    async def _record_failed_login(self, login_key: str):
        """Record failed login attempt"""
        attempts = await cache_manager.increment(login_key)
        
        if attempts == 1:
            # Set expiry on first attempt
            await cache_manager.expire(login_key, settings.login_block_minutes * 60)
    
    async def check_rate_limit(
        self,
        identifier: str,
        action: str,
        limit: int,
        period: int = 60
    ) -> bool:
        """Check rate limit for action"""
        key = f"rate_limit:{identifier}:{action}"
        current = await cache_manager.increment(key)
        
        if current == 1:
            await cache_manager.expire(key, period)
        
        return current <= limit
    
    async def is_ip_blocked(self, ip_address: str) -> bool:
        """Check if IP is blocked"""
        key = f"ip_blocked:{ip_address}"
        return await cache_manager.exists(key)
    
    async def block_ip(
        self,
        ip_address: str,
        reason: str,
        duration_minutes: int = 60
    ) -> bool:
        """Block IP address"""
        key = f"ip_blocked:{ip_address}"
        return await cache_manager.set(
            key,
            {
                "reason": reason,
                "blocked_at": datetime.utcnow().isoformat(),
                "expires_at": (datetime.utcnow() + timedelta(minutes=duration_minutes)).isoformat()
            },
            ttl=duration_minutes * 60
        )
    
    async def unblock_ip(self, ip_address: str) -> bool:
        """Unblock IP address"""
        key = f"ip_blocked:{ip_address}"
        return await cache_manager.delete(key)
    
    # ==================== HEALTH CHECK ====================
    
    async def health_check(self) -> Dict[str, Any]:
        """Authentication service health check"""
        try:
            # Check Firebase
            firebase_health = await self.firebase.health_check()
            
            # Check Redis
            await cache_manager.get("health_check")
            
            return {
                "status": "healthy",
                "firebase": firebase_health.get("status", "unknown"),
                "cache": "healthy",
                "timestamp": datetime.utcnow().isoformat()
            }
            
        except Exception as e:
            return {
                "status": "unhealthy",
                "error": str(e),
                "timestamp": datetime.utcnow().isoformat()
            }


# Global auth service instance
auth_service = AuthService()