from datetime import datetime
from typing import Optional, Dict, Any
from pydantic import BaseModel, Field
from enum import Enum


class NotificationType(str, Enum):
    INFO = "info"
    SUCCESS = "success"
    WARNING = "warning"
    ERROR = "error"
    PAYMENT = "payment"
    SECURITY = "security"
    SYSTEM = "system"


class NotificationChannel(str, Enum):
    EMAIL = "email"
    PUSH = "push"
    SMS = "sms"
    IN_APP = "in_app"


class NotificationStatus(str, Enum):
    PENDING = "pending"
    SENT = "sent"
    DELIVERED = "delivered"
    READ = "read"
    FAILED = "failed"


class Notification(BaseModel):
    id: str = Field(..., description="Notification ID")
    user_id: str = Field(..., description="User ID")
    
    # Notification Details
    type: NotificationType = Field(NotificationType.INFO, description="Type")
    channel: NotificationChannel = Field(NotificationChannel.IN_APP, description="Channel")
    status: NotificationStatus = Field(NotificationStatus.PENDING, description="Status")
    
    # Content
    title: str = Field(..., description="Notification title")
    message: str = Field(..., description="Notification message")
    content: Optional[str] = Field(None, description="HTML content")
    
    # Action
    action_url: Optional[str] = Field(None, description="Action URL")
    action_text: Optional[str] = Field(None, description="Action button text")
    
    # Metadata
    metadata: Dict[str, Any] = Field(default_factory=dict)
    template_id: Optional[str] = Field(None, description="Template ID")
    
    # Priority
    priority: int = Field(0, description="Priority (0-10)")
    expire_at: Optional[datetime] = Field(None, description="Expiration time")
    
    # Delivery
    sent_at: Optional[datetime] = Field(None, description="Sent at")
    delivered_at: Optional[datetime] = Field(None, description="Delivered at")
    read_at: Optional[datetime] = Field(None, description="Read at")
    
    # Error Handling
    retry_count: int = Field(0, description="Retry count")
    error_message: Optional[str] = Field(None, description="Error message")
    
    # Timestamps
    created_at: datetime = Field(default_factory=datetime.utcnow)
    
    class Config:
        from_attributes = True