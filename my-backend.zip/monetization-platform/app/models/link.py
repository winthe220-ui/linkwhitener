from datetime import datetime
from typing import Optional, List, Dict, Any
from pydantic import BaseModel, Field, HttpUrl
from enum import Enum


class LinkStatus(str, Enum):
    ACTIVE = "active"
    PAUSED = "paused"
    DISABLED = "disabled"
    SUSPENDED = "suspended"


class LinkType(str, Enum):
    DIRECT = "direct"
    SMART = "smart"
    ROTATOR = "rotator"
    CONTENT_LOCK = "content_lock"


class Link(BaseModel):
    id: str = Field(..., description="Unique link ID")
    user_id: str = Field(..., description="Owner user ID")
    
    # Link Info
    title: str = Field(..., description="Link title")
    description: Optional[str] = Field(None, description="Link description")
    destination_url: HttpUrl = Field(..., description="Destination URL")
    short_code: str = Field(..., description="Short code for the link")
    domain: Optional[str] = Field(None, description="Custom domain")
    
    # Type & Status
    link_type: LinkType = Field(LinkType.DIRECT, description="Link type")
    status: LinkStatus = Field(LinkStatus.ACTIVE, description="Link status")
    
    # Monetization
    monetization_enabled: bool = Field(True, description="Monetization status")
    cpm_rate: float = Field(0.0, description="CPM rate")
    cpc_rate: float = Field(0.0, description="CPC rate")
    cpa_rate: float = Field(0.0, description="CPA rate")
    
    # Security
    password: Optional[str] = Field(None, description="Link password")
    expire_at: Optional[datetime] = Field(None, description="Expiration date")
    max_clicks: Optional[int] = Field(None, description="Maximum clicks")
    
    # Tracking
    total_clicks: int = Field(0, description="Total clicks")
    unique_clicks: int = Field(0, description="Unique clicks")
    conversions: int = Field(0, description="Conversions")
    
    # Geolocation
    allowed_countries: List[str] = Field(default_factory=list)
    blocked_countries: List[str] = Field(default_factory=list)
    
    # Schedule
    schedule_start: Optional[datetime] = Field(None, description="Schedule start")
    schedule_end: Optional[datetime] = Field(None, description="Schedule end")
    
    # Appearance
    thumbnail_url: Optional[str] = Field(None, description="Thumbnail URL")
    custom_css: Optional[str] = Field(None, description="Custom CSS")
    custom_js: Optional[str] = Field(None, description="Custom JavaScript")
    
    # Timestamps
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)
    last_clicked_at: Optional[datetime] = Field(None, description="Last clicked at")
    
    # Metadata
    tags: List[str] = Field(default_factory=list)
    metadata: Dict[str, Any] = Field(default_factory=dict)
    
    class Config:
        from_attributes = True