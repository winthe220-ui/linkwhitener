from pydantic import BaseModel
from typing import ClassVar


class BaseFirestoreModel(BaseModel):
    """
    Base model for Firestore-backed documents
    """
    collection_name: ClassVar[str]

    def to_dict(self):
        return self.dict(exclude_none=True)

    @classmethod
    def from_dict(cls, data: dict):
        return cls(**data)

    class Config:
        from_attributes = True
