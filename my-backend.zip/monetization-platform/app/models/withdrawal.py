from datetime import datetime
from typing import Optional
from pydantic import BaseModel, Field
from enum import Enum


class WithdrawalMethod(str, Enum):
    PAYPAL = "paypal"
    BANK_TRANSFER = "bank_transfer"
    CRYPTO = "crypto"
    PAYONEER = "payoneer"
    WISE = "wise"
    STRIPE = "stripe"


class WithdrawalStatus(str, Enum):
    PENDING = "pending"
    PROCESSING = "processing"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"
    ON_HOLD = "on_hold"


class Withdrawal(BaseModel):
    id: str = Field(..., description="Unique withdrawal ID")
    user_id: str = Field(..., description="User ID")
    
    # Withdrawal Details
    amount: float = Field(..., description="Withdrawal amount")
    currency: str = Field("USD", description="Currency")
    method: WithdrawalMethod = Field(..., description="Withdrawal method")
    status: WithdrawalStatus = Field(WithdrawalStatus.PENDING, description="Status")
    
    # Payment Details
    payment_address: str = Field(..., description="Payment address/account")
    payment_reference: Optional[str] = Field(None, description="Payment reference")
    transaction_id: Optional[str] = Field(None, description="Transaction ID")
    
    # Fees
    fee_amount: float = Field(0.0, description="Fee amount")
    fee_percentage: float = Field(0.0, description="Fee percentage")
    net_amount: float = Field(..., description="Net amount after fees")
    
    # Processing
    processed_by: Optional[str] = Field(None, description="Processed by user ID")
    processing_notes: Optional[str] = Field(None, description="Processing notes")
    
    # Timestamps
    requested_at: datetime = Field(default_factory=datetime.utcnow)
    processed_at: Optional[datetime] = Field(None, description="Processed at")
    completed_at: Optional[datetime] = Field(None, description="Completed at")
    
    # Audit
    failure_reason: Optional[str] = Field(None, description="Failure reason")
    admin_notes: Optional[str] = Field(None, description="Admin notes")
    
    class Config:
        from_attributes = True