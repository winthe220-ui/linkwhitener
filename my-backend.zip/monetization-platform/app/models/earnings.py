from datetime import datetime
from typing import Optional
from pydantic import BaseModel, Field
from enum import Enum


class EarningType(str, Enum):
    CPC = "cpc"
    CPM = "cpm"
    CPA = "cpa"
    FIXED = "fixed"
    BONUS = "bonus"
    REFERRAL = "referral"


class EarningStatus(str, Enum):
    PENDING = "pending"
    APPROVED = "approved"
    REJECTED = "rejected"
    PROCESSED = "processed"


class Earnings(BaseModel):
    id: str = Field(..., description="Unique earning ID")
    user_id: str = Field(..., description="User ID")
    link_id: Optional[str] = Field(None, description="Link ID (if applicable)")
    
    # Earning Details
    amount: float = Field(..., description="Earning amount")
    currency: str = Field("USD", description="Currency")
    earning_type: EarningType = Field(..., description="Type of earning")
    status: EarningStatus = Field(EarningStatus.PENDING, description="Earning status")
    
    # Source Details
    source_ip: Optional[str] = Field(None, description="Source IP")
    user_agent: Optional[str] = Field(None, description="User agent")
    referrer: Optional[str] = Field(None, description="HTTP referrer")
    
    # Country & Device
    country_code: Optional[str] = Field(None, description="Country code")
    country_name: Optional[str] = Field(None, description="Country name")
    device_type: Optional[str] = Field(None, description="Device type")
    browser: Optional[str] = Field(None, description="Browser")
    os: Optional[str] = Field(None, description="Operating system")
    
    # Transaction
    transaction_id: Optional[str] = Field(None, description="Transaction ID")
    campaign_id: Optional[str] = Field(None, description="Campaign ID")
    advertiser_id: Optional[str] = Field(None, description="Advertiser ID")
    
    # Timestamps
    created_at: datetime = Field(default_factory=datetime.utcnow)
    processed_at: Optional[datetime] = Field(None, description="Processed at")
    
    # Audit
    approved_by: Optional[str] = Field(None, description="Approved by user ID")
    rejection_reason: Optional[str] = Field(None, description="Rejection reason")
    
    class Config:
        from_attributes = True