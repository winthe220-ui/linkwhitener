from datetime import datetime
from typing import Optional, List, Dict, Any
from pydantic import BaseModel, Field
from enum import Enum


class FraudSeverity(str, Enum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


class FraudType(str, Enum):
    CLICK_FRAUD = "click_fraud"
    IMPRESSION_FRAUD = "impression_fraud"
    MULTI_ACCOUNT = "multi_account"
    VPN_PROXY = "vpn_proxy"
    BOT_TRAFFIC = "bot_traffic"
    GEO_SPOOFING = "geo_spoofing"


class FraudStatus(str, Enum):
    DETECTED = "detected"
    UNDER_REVIEW = "under_review"
    CONFIRMED = "confirmed"
    FALSE_POSITIVE = "false_positive"
    ACTION_TAKEN = "action_taken"


class FraudDetection(BaseModel):
    id: str = Field(..., description="Fraud detection ID")
    user_id: Optional[str] = Field(None, description="Associated user ID")
    link_id: Optional[str] = Field(None, description="Associated link ID")
    
    # Detection Details
    fraud_type: FraudType = Field(..., description="Type of fraud")
    severity: FraudSeverity = Field(FraudSeverity.MEDIUM, description="Severity")
    status: FraudStatus = Field(FraudStatus.DETECTED, description="Status")
    fraud_score: float = Field(..., description="Fraud score (0-100)")
    
    # Detection Data
    detection_data: Dict[str, Any] = Field(default_factory=dict)
    indicators: List[str] = Field(default_factory=list)
    
    # IP & Device Info
    ip_address: Optional[str] = Field(None, description="IP address")
    user_agent: Optional[str] = Field(None, description="User agent")
    device_fingerprint: Optional[str] = Field(None, description="Device fingerprint")
    
    # Geolocation
    country_code: Optional[str] = Field(None, description="Country code")
    city: Optional[str] = Field(None, description="City")
    isp: Optional[str] = Field(None, description="Internet Service Provider")
    
    # Impact
    estimated_loss: float = Field(0.0, description="Estimated financial loss")
    affected_clicks: int = Field(0, description="Number of affected clicks")
    affected_impressions: int = Field(0, description="Number of affected impressions")
    
    # Resolution
    action_taken: Optional[str] = Field(None, description="Action taken")
    resolved_by: Optional[str] = Field(None, description="Resolved by user ID")
    resolution_notes: Optional[str] = Field(None, description="Resolution notes")
    
    # Timestamps
    detected_at: datetime = Field(default_factory=datetime.utcnow)
    reviewed_at: Optional[datetime] = Field(None, description="Reviewed at")
    resolved_at: Optional[datetime] = Field(None, description="Resolved at")
    
    # Audit
    review_notes: Optional[str] = Field(None, description="Review notes")
    false_positive_reason: Optional[str] = Field(None, description="False positive reason")
    
    class Config:
        from_attributes = True