from datetime import datetime
from typing import Optional, Dict, List
from pydantic import BaseModel, Field


class AnalyticsMetric(BaseModel):
    """
    Single analytics metric
    """
    name: str = Field(..., description="Metric name")
    value: int = Field(..., description="Metric value")


class Analytics(BaseModel):
    """
    Analytics data model
    """

    id: str = Field(..., description="Analytics record ID")
    user_id: str = Field(..., description="User ID")
    link_id: Optional[str] = Field(None, description="Link ID")

    # Core metrics (SAFE TYPES)
    clicks: int = Field(0, description="Total clicks")
    page_views: int = Field(0, description="Page views")
    conversions: int = Field(0, description="Conversions")
    earnings: float = Field(0.0, description="Total earnings")

    # Aggregated metrics (SAFE typing)
    metrics: Dict[str, int] = Field(
        default_factory=dict,
        description="Dynamic metrics (country/device/etc.)"
    )

    # Breakdown
    countries: Dict[str, int] = Field(default_factory=dict)
    devices: Dict[str, int] = Field(default_factory=dict)
    browsers: Dict[str, int] = Field(default_factory=dict)
    referrers: Dict[str, int] = Field(default_factory=dict)

    # Time-based stats
    hourly: Dict[str, int] = Field(default_factory=dict)
    daily: Dict[str, int] = Field(default_factory=dict)

    # Metadata
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)

    class Config:
        from_attributes = True
