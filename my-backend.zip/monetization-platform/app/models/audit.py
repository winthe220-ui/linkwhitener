"""
Audit log models for tracking system activities
"""
from datetime import datetime
from typing import Optional, Dict, Any, List
from enum import Enum
from pydantic import BaseModel, Field
from app.models.base import BaseFirestoreModel
import uuid


class AuditAction(str, Enum):
    """Audit action types"""
    
    # User actions
    USER_REGISTER = "user_register"
    USER_LOGIN = "user_login"
    USER_LOGOUT = "user_logout"
    USER_PROFILE_UPDATE = "user_profile_update"
    USER_PASSWORD_CHANGE = "user_password_change"
    USER_DELETE = "user_delete"
    
    # Link actions
    LINK_CREATE = "link_create"
    LINK_UPDATE = "link_update"
    LINK_DISABLE = "link_disable"
    LINK_DELETE = "link_delete"
    LINK_VIEW = "link_view"
    
    # Earnings actions
    EARNINGS_CREDIT = "earnings_credit"
    EARNINGS_ADJUST = "earnings_adjust"
    EARNINGS_REFUND = "earnings_refund"
    
    # Withdrawal actions
    WITHDRAWAL_REQUEST = "withdrawal_request"
    WITHDRAWAL_APPROVE = "withdrawal_approve"
    WITHDRAWAL_REJECT = "withdrawal_reject"
    WITHDRAWAL_CANCEL = "withdrawal_cancel"
    WITHDRAWAL_PROCESS = "withdrawal_process"
    
    # Admin actions
    ADMIN_LOGIN = "admin_login"
    ADMIN_LOGOUT = "admin_logout"
    ADMIN_CREATE = "admin_create"
    ADMIN_UPDATE = "admin_update"
    ADMIN_DELETE = "admin_delete"
    ADMIN_PERMISSION_CHANGE = "admin_permission_change"
    
    # User management actions
    USER_SUSPEND = "user_suspend"
    USER_BAN = "user_ban"
    USER_REINSTATE = "user_reinstate"
    USER_FLAG = "user_flag"
    USER_UNFLAG = "user_unflag"
    
    # Settings actions
    SETTINGS_UPDATE = "settings_update"
    WEBSITE_ADD = "website_add"
    WEBSITE_REMOVE = "website_remove"
    BLACKLIST_ADD = "blacklist_add"
    BLACKLIST_REMOVE = "blacklist_remove"
    
    # System actions
    SYSTEM_BACKUP = "system_backup"
    SYSTEM_RESTORE = "system_restore"
    SYSTEM_CLEANUP = "system_cleanup"
    SYSTEM_MAINTENANCE = "system_maintenance"
    
    # Security actions
    SECURITY_ALERT = "security_alert"
    FRAUD_DETECTED = "fraud_detected"
    IP_BLOCKED = "ip_blocked"
    IP_UNBLOCKED = "ip_unblocked"
    
    # KYC actions
    KYC_SUBMIT = "kyc_submit"
    KYC_APPROVE = "kyc_approve"
    KYC_REJECT = "kyc_reject"
    KYC_VERIFY = "kyc_verify"
    
    # Notification actions
    NOTIFICATION_SEND = "notification_send"
    EMAIL_SEND = "email_send"
    SMS_SEND = "sms_send"
    PUSH_SEND = "push_send"


class AuditResource(str, Enum):
    """Audit resource types"""
    
    USER = "user"
    LINK = "link"
    EARNINGS = "earnings"
    TRANSACTION = "transaction"
    WITHDRAWAL = "withdrawal"
    ADMIN = "admin"
    SETTINGS = "settings"
    WEBSITE = "website"
    BLACKLIST = "blacklist"
    SYSTEM = "system"
    SECURITY = "security"
    FRAUD = "fraud"
    KYC = "kyc"
    NOTIFICATION = "notification"
    AUDIT = "audit"


class AuditSeverity(str, Enum):
    """Audit severity levels"""
    
    DEBUG = "debug"
    INFO = "info"
    WARNING = "warning"
    ERROR = "error"
    CRITICAL = "critical"


class AuditLog(BaseFirestoreModel):
    """Audit log model for Firestore"""
    collection_name = "audit_logs"
    
    # Identification
    log_id: str = Field(default_factory=lambda: f"audit_{datetime.utcnow().strftime('%Y%m%d_%H%M%S')}_{uuid.uuid4().hex[:8]}")
    trace_id: Optional[str] = None  # For distributed tracing
    
    # Actor information
    actor_type: str = Field(..., description="user, admin, system")
    actor_id: Optional[str] = None  # User UID or Admin ID
    actor_ip: str
    actor_user_agent: Optional[str] = None
    actor_location: Optional[str] = None
    
    # Action information
    action: AuditAction
    resource: AuditResource
    resource_id: Optional[str] = None  # Specific resource ID if applicable
    
    # Details
    details: Dict[str, Any] = Field(default_factory=dict)
    severity: AuditSeverity = AuditSeverity.INFO
    
    # Status
    status: str = "success"  # success, failed, partial
    error_message: Optional[str] = None
    error_stack: Optional[str] = None
    
    # Timestamps
    timestamp: datetime = Field(default_factory=datetime.utcnow)
    duration_ms: Optional[int] = None  # Action duration in milliseconds
    
    # Metadata
    metadata: Dict[str, Any] = Field(default_factory=dict)
    tags: List[str] = Field(default_factory=list)
    indexed_fields: Dict[str, Any] = Field(default_factory=dict)
    
    # Compliance
    retention_days: int = 365  # Default retention period
    compliance_required: bool = False
    compliance_tags: List[str] = Field(default_factory=list)
    
    class Config:
        json_encoders = {
            datetime: lambda v: v.isoformat() if v else None
        }
    
    @classmethod
    def create_user_action(
        cls,
        user_uid: str,
        action: AuditAction,
        resource: AuditResource,
        resource_id: Optional[str] = None,
        details: Optional[Dict[str, Any]] = None,
        ip_address: str = "0.0.0.0",
        user_agent: Optional[str] = None,
        severity: AuditSeverity = AuditSeverity.INFO,
        status: str = "success"
    ) -> "AuditLog":
        """Create audit log for user action"""
        return cls(
            actor_type="user",
            actor_id=user_uid,
            actor_ip=ip_address,
            actor_user_agent=user_agent,
            action=action,
            resource=resource,
            resource_id=resource_id,
            details=details or {},
            severity=severity,
            status=status
        )
    
    @classmethod
    def create_admin_action(
        cls,
        admin_id: str,
        action: AuditAction,
        resource: AuditResource,
        resource_id: Optional[str] = None,
        details: Optional[Dict[str, Any]] = None,
        ip_address: str = "0.0.0.0",
        user_agent: Optional[str] = None,
        severity: AuditSeverity = AuditSeverity.INFO,
        status: str = "success"
    ) -> "AuditLog":
        """Create audit log for admin action"""
        return cls(
            actor_type="admin",
            actor_id=admin_id,
            actor_ip=ip_address,
            actor_user_agent=user_agent,
            action=action,
            resource=resource,
            resource_id=resource_id,
            details=details or {},
            severity=severity,
            status=status
        )
    
    @classmethod
    def create_system_action(
        cls,
        action: AuditAction,
        resource: AuditResource,
        resource_id: Optional[str] = None,
        details: Optional[Dict[str, Any]] = None,
        severity: AuditSeverity = AuditSeverity.INFO,
        status: str = "success"
    ) -> "AuditLog":
        """Create audit log for system action"""
        return cls(
            actor_type="system",
            actor_ip="system",
            action=action,
            resource=resource,
            resource_id=resource_id,
            details=details or {},
            severity=severity,
            status=status
        )
    
    def set_duration(self, start_time: datetime):
        """Set duration based on start time"""
        self.duration_ms = int((datetime.utcnow() - start_time).total_seconds() * 1000)
    
    def add_tag(self, tag: str):
        """Add tag to audit log"""
        if tag not in self.tags:
            self.tags.append(tag)
    
    def add_compliance_tag(self, tag: str):
        """Add compliance tag"""
        if tag not in self.compliance_tags:
            self.compliance_tags.append(tag)
    
    def set_indexed_field(self, key: str, value: Any):
        """Set indexed field for efficient querying"""
        self.indexed_fields[key] = value
    
    def to_index_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for Firestore indexing"""
        data = self.dict(exclude={"details", "error_stack"})
        
        # Add indexed fields
        data.update(self.indexed_fields)
        
        # Add timestamp components for easy querying
        data["year"] = self.timestamp.year
        data["month"] = self.timestamp.month
        data["day"] = self.timestamp.day
        data["hour"] = self.timestamp.hour
        data["minute"] = self.timestamp.minute
        
        return data


class AuditQuery(BaseModel):
    """Audit log query parameters"""
    
    # Filtering
    actor_type: Optional[str] = None
    actor_id: Optional[str] = None
    action: Optional[str] = None
    resource: Optional[str] = None
    resource_id: Optional[str] = None
    severity: Optional[str] = None
    status: Optional[str] = None
    
    # Date range
    start_date: Optional[datetime] = None
    end_date: Optional[datetime] = None
    
    # Search
    search_text: Optional[str] = None
    tags: Optional[List[str]] = None
    compliance_tags: Optional[List[str]] = None
    
    # Pagination
    page: int = 1
    limit: int = 50
    sort_by: str = "timestamp"
    sort_order: str = "desc"  # asc, desc
    
    class Config:
        json_encoders = {
            datetime: lambda v: v.isoformat() if v else None
        }
    
    def to_firestore_query(self) -> Dict[str, Any]:
        """Convert to Firestore query parameters"""
        query_filters = []
        
        # Add filters
        if self.actor_type:
            query_filters.append(("actor_type", "==", self.actor_type))
        if self.actor_id:
            query_filters.append(("actor_id", "==", self.actor_id))
        if self.action:
            query_filters.append(("action", "==", self.action))
        if self.resource:
            query_filters.append(("resource", "==", self.resource))
        if self.resource_id:
            query_filters.append(("resource_id", "==", self.resource_id))
        if self.severity:
            query_filters.append(("severity", "==", self.severity))
        if self.status:
            query_filters.append(("status", "==", self.status))
        
        # Date range
        if self.start_date:
            query_filters.append(("timestamp", ">=", self.start_date))
        if self.end_date:
            query_filters.append(("timestamp", "<=", self.end_date))
        
        # Tags
        if self.tags:
            for tag in self.tags:
                query_filters.append(("tags", "array_contains", tag))
        
        # Compliance tags
        if self.compliance_tags:
            for tag in self.compliance_tags:
                query_filters.append(("compliance_tags", "array_contains", tag))
        
        # Sorting
        sort_field = self.sort_by
        sort_direction = self.sort_order
        
        return {
            "filters": query_filters,
            "sort_field": sort_field,
            "sort_direction": sort_direction,
            "limit": self.limit,
            "offset": (self.page - 1) * self.limit
        }


class AuditSummary(BaseModel):
    """Audit log summary"""
    
    total_logs: int = 0
    total_pages: int = 0
    current_page: int = 1
    limit: int = 50
    
    # Statistics
    by_actor_type: Dict[str, int] = Field(default_factory=dict)
    by_action: Dict[str, int] = Field(default_factory=dict)
    by_resource: Dict[str, int] = Field(default_factory=dict)
    by_severity: Dict[str, int] = Field(default_factory=dict)
    by_status: Dict[str, int] = Field(default_factory=dict)
    by_hour: Dict[int, int] = Field(default_factory=dict)
    by_day: Dict[str, int] = Field(default_factory=dict)
    
    # Time-based
    logs_today: int = 0
    logs_yesterday: int = 0
    logs_this_week: int = 0
    logs_this_month: int = 0
    
    # Error statistics
    error_count: int = 0
    warning_count: int = 0
    critical_count: int = 0
    
    # Top actors
    top_actors: List[Dict[str, Any]] = Field(default_factory=list)
    top_resources: List[Dict[str, Any]] = Field(default_factory=list)
    
    # Compliance
    compliance_logs: int = 0
    compliance_tags: Dict[str, int] = Field(default_factory=dict)
    
    class Config:
        json_encoders = {
            datetime: lambda v: v.isoformat() if v else None
        }


class AuditExport(BaseModel):
    """Audit log export configuration"""
    
    format: str = "json"  # json, csv, excel
    include_fields: List[str] = Field(default_factory=lambda: [
        "log_id", "timestamp", "actor_type", "actor_id", "action",
        "resource", "resource_id", "severity", "status", "actor_ip"
    ])
    filters: Optional[AuditQuery] = None
    compress: bool = False
    password_protect: bool = False
    password: Optional[str] = None
    
    class Config:
        json_encoders = {
            datetime: lambda v: v.isoformat() if v else None
        }


class AuditAlertRule(BaseFirestoreModel):
    """Audit alert rule for automatic notifications"""
    collection_name = "audit_alert_rules"
    
    rule_id: str
    name: str
    description: Optional[str] = None
    
    # Conditions
    conditions: List[Dict[str, Any]] = Field(default_factory=list)
    
    # Actions
    actions: List[str] = Field(default_factory=list)  # email, sms, webhook, slack
    action_config: Dict[str, Any] = Field(default_factory=dict)
    
    # Severity
    severity: AuditSeverity = AuditSeverity.WARNING
    
    # Status
    is_active: bool = True
    is_system: bool = False
    
    # Schedule
    schedule: Optional[Dict[str, Any]] = None  # cron expression or interval
    last_triggered: Optional[datetime] = None
    trigger_count: int = 0
    
    # Metadata
    created_by: Optional[str] = None
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)
    metadata: Dict[str, Any] = Field(default_factory=dict)
    
    class Config:
        json_encoders = {
            datetime: lambda v: v.isoformat() if v else None
        }
    
    def check_conditions(self, audit_log: AuditLog) -> bool:
        """Check if audit log matches rule conditions"""
        if not self.is_active:
            return False
        
        for condition in self.conditions:
            field = condition.get("field")
            operator = condition.get("operator")
            value = condition.get("value")
            
            if not self._check_condition(audit_log, field, operator, value):
                return False
        
        return True
    
    def _check_condition(self, audit_log: AuditLog, field: str, 
                        operator: str, value: Any) -> bool:
        """Check single condition"""
        # Get field value from audit log
        field_value = getattr(audit_log, field, None)
        if field_value is None:
            field_value = audit_log.details.get(field)
        
        if field_value is None:
            return False
        
        # Apply operator
        if operator == "==":
            return field_value == value
        elif operator == "!=":
            return field_value != value
        elif operator == ">":
            return field_value > value
        elif operator == ">=":
            return field_value >= value
        elif operator == "<":
            return field_value < value
        elif operator == "<=":
            return field_value <= value
        elif operator == "in":
            return field_value in value
        elif operator == "not_in":
            return field_value not in value
        elif operator == "contains":
            return value in field_value
        elif operator == "not_contains":
            return value not in field_value
        elif operator == "regex":
            import re
            return bool(re.match(value, str(field_value)))
        
        return False
    
    def trigger(self, audit_log: AuditLog):
        """Trigger alert rule"""
        self.last_triggered = datetime.utcnow()
        self.trigger_count += 1