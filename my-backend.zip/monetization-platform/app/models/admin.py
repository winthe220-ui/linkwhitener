from datetime import datetime
from typing import Optional, List, Dict, Any
from pydantic import BaseModel, Field
from decimal import Decimal


class AdminSettings(BaseModel):
    id: str = Field(..., description="Settings ID")
    
    # Platform Settings
    platform_name: str = Field("Monetization Platform", description="Platform name")
    platform_currency: str = Field("USD", description="Default currency")
    platform_language: str = Field("en", description="Default language")
    
    # Monetization Rates
    default_cpm_rate: float = Field(1.0, description="Default CPM rate")
    default_cpc_rate: float = Field(0.01, description="Default CPC rate")
    default_cpa_rate: float = Field(0.5, description="Default CPA rate")
    
    # Payout Settings
    minimum_payout: float = Field(10.0, description="Minimum payout amount")
    payout_fee_percentage: float = Field(2.5, description="Payout fee percentage")
    payout_fee_fixed: float = Field(0.3, description="Payout fixed fee")
    
    # Commission Rates
    commission_rate: float = Field(10.0, description="Platform commission %")
    referral_commission: float = Field(5.0, description="Referral commission %")
    
    # Security Settings
    max_login_attempts: int = Field(5, description="Max login attempts")
    session_timeout: int = Field(3600, description="Session timeout in seconds")
    password_min_length: int = Field(8, description="Minimum password length")
    
    # Email Settings
    email_verification_required: bool = Field(True, description="Email verification")
    notification_emails: bool = Field(True, description="Send notification emails")
    
    # Link Settings
    max_links_per_user: int = Field(100, description="Max links per user")
    link_expiry_days: int = Field(365, description="Default link expiry days")
    
    # Fraud Detection
    fraud_score_threshold: float = Field(70.0, description="Fraud score threshold")
    ip_block_threshold: int = Field(10, description="IP block threshold")
    
    # Maintenance
    maintenance_mode: bool = Field(False, description="Maintenance mode")
    maintenance_message: Optional[str] = Field(None, description="Maintenance message")
    
    # Analytics
    analytics_enabled: bool = Field(True, description="Analytics enabled")
    retention_days: int = Field(90, description="Data retention days")
    
    # Timestamps
    updated_at: datetime = Field(default_factory=datetime.utcnow)
    updated_by: Optional[str] = Field(None, description="Updated by user ID")
    
    # Metadata
    metadata: Dict[str, Any] = Field(default_factory=dict)
    
    class Config:
        from_attributes = True