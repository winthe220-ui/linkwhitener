from datetime import datetime
from typing import Optional, List, Dict, Any
from pydantic import BaseModel, Field, EmailStr
from enum import Enum


class UserRole(str, Enum):
    USER = "user"
    ADMIN = "admin"
    SUPER_ADMIN = "super_admin"


class UserTier(str, Enum):
    FREE = "free"
    PRO = "pro"
    ENTERPRISE = "enterprise"


class UserStatus(str, Enum):
    ACTIVE = "active"
    SUSPENDED = "suspended"
    BANNED = "banned"
    PENDING = "pending"


class User(BaseModel):
    id: str = Field(..., description="Unique user ID")
    email: EmailStr = Field(..., description="User email")
    username: str = Field(..., description="Username")
    display_name: Optional[str] = Field(None, description="Display name")
    
    # Auth
    hashed_password: str = Field(..., description="Hashed password")
    email_verified: bool = Field(False, description="Email verification status")
    
    # Roles & Status
    role: UserRole = Field(UserRole.USER, description="User role")
    tier: UserTier = Field(UserTier.FREE, description="Subscription tier")
    status: UserStatus = Field(UserStatus.ACTIVE, description="User status")
    
    # Profile
    avatar_url: Optional[str] = Field(None, description="Avatar URL")
    bio: Optional[str] = Field(None, description="User biography")
    website: Optional[str] = Field(None, description="Website URL")
    
    # Stats
    total_earnings: float = Field(0.0, description="Total earnings")
    pending_balance: float = Field(0.0, description="Pending balance")
    available_balance: float = Field(0.0, description="Available balance")
    total_withdrawn: float = Field(0.0, description="Total withdrawn")
    
    # Settings
    currency: str = Field("USD", description="Preferred currency")
    language: str = Field("en", description="Preferred language")
    timezone: str = Field("UTC", description="Timezone")
    
    # Security
    two_factor_enabled: bool = Field(False, description="2FA status")
    last_login_ip: Optional[str] = Field(None, description="Last login IP")
    failed_login_attempts: int = Field(0, description="Failed login attempts")
    
    # Timestamps
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)
    last_login_at: Optional[datetime] = Field(None, description="Last login time")
    
    # Links
    referral_code: Optional[str] = Field(None, description="Referral code")
    referred_by: Optional[str] = Field(None, description="Referrer user ID")
    
    # Metadata
    metadata: Dict[str, Any] = Field(default_factory=dict)
    
    class Config:
        from_attributes = True