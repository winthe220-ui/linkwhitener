"""
Monetization Platform Backend
Advanced URL shortener with monetization capabilities
"""

__version__ = "1.0.0"
__author__ = "Monetization Platform Team"
__description__ = "Advanced URL monetization platform with Firebase authentication"

from app.core.firebase_client import firebase_client
from app.core.cache import cache_manager
from app.database import redis_client, firestore_client
from app.services.auth_service import auth_service
from app.services.user_service import user_service
from app.services.link_service import link_service

# Initialize components
def init_app():
    """Initialize application components"""
    # Initialize Firebase
    firebase_client.init_app()
    
    # Initialize Redis
    redis_client.init_client()
    
    # Initialize Firestore
    firestore_client.init_client()
    
    print("✅ Application initialized successfully")