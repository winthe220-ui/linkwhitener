"""
Webhook handlers for external service integrations
"""

import logging
from typing import Dict, Any, Optional
from fastapi import Request, HTTPException, status

logger = logging.getLogger(__name__)


class WebhookManager:
    """Manager for webhook handlers"""
    
    def __init__(self):
        self.handlers = {}
    
    def register_handler(self, service: str, handler):
        """Register webhook handler for a service"""
        self.handlers[service] = handler
        logger.info(f"Registered webhook handler for {service}")
    
    async def handle_webhook(self, service: str, request: Request) -> Dict[str, Any]:
        """Handle webhook for a service"""
        if service not in self.handlers:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Unsupported webhook service: {service}"
            )
        
        handler = self.handlers[service]
        
        try:
            # Get request body
            body = await request.body()
            headers = dict(request.headers)
            
            # Process webhook
            result = await handler.process_webhook(body, headers, request)
            
            logger.info(f"Webhook handled successfully for {service}")
            return result
            
        except Exception as e:
            logger.error(f"Webhook handling failed for {service}: {str(e)}")
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Webhook processing failed: {str(e)}"
            )
    
    def get_supported_services(self) -> list:
        """Get list of supported webhook services"""
        return list(self.handlers.keys())


class BaseWebhookHandler:
    """Base class for webhook handlers"""
    
    def __init__(self, service_name: str):
        self.service_name = service_name
        self.secret_key: Optional[str] = None
    
    def set_secret(self, secret_key: str):
        """Set webhook secret for verification"""
        self.secret_key = secret_key
    
    async def verify_signature(self, payload: bytes, signature: str) -> bool:
        """Verify webhook signature"""
        raise NotImplementedError
    
    async def parse_payload(self, payload: bytes) -> Dict[str, Any]:
        """Parse webhook payload"""
        raise NotImplementedError
    
    async def process_event(self, event: Dict[str, Any]) -> Dict[str, Any]:
        """Process webhook event"""
        raise NotImplementedError
    
    async def process_webhook(self, payload: bytes, headers: Dict[str, str], request: Request) -> Dict[str, Any]:
        """Process webhook request"""
        # Verify signature if secret is set
        if self.secret_key:
            signature = headers.get("x-signature") or headers.get("signature")
            if not signature:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="Missing signature"
                )
            
            if not await self.verify_signature(payload, signature):
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="Invalid signature"
                )
        
        # Parse payload
        event = await self.parse_payload(payload)
        
        # Process event
        result = await self.process_event(event)
        
        return {
            "success": True,
            "service": self.service_name,
            "event_type": event.get("type"),
            "event_id": event.get("id"),
            "result": result
        }


# Import handlers
from app.webhooks.stripe import StripeWebhookHandler
from app.webhooks.razorpay import RazorpayWebhookHandler
from app.webhooks.firebase import FirebaseWebhookHandler

# Create webhook manager instance
webhook_manager = WebhookManager()

# Register handlers
stripe_handler = StripeWebhookHandler()
razorpay_handler = RazorpayWebhookHandler()
firebase_handler = FirebaseWebhookHandler()

webhook_manager.register_handler("stripe", stripe_handler)
webhook_manager.register_handler("razorpay", razorpay_handler)
webhook_manager.register_handler("firebase", firebase_handler)


async def handle_webhook_request(service: str, request: Request) -> Dict[str, Any]:
    """Handle webhook request"""
    return await webhook_manager.handle_webhook(service, request)


def get_webhook_config(service: str) -> Dict[str, Any]:
    """Get webhook configuration for a service"""
    # This would typically load from database or config
    configs = {
        "stripe": {
            "enabled": True,
            "events": ["payment_intent.succeeded", "payment_intent.payment_failed"],
            "url": "/webhooks/stripe",
            "secret_env_var": "STRIPE_WEBHOOK_SECRET"
        },
        "razorpay": {
            "enabled": True,
            "events": ["payment.captured", "payment.failed"],
            "url": "/webhooks/razorpay",
            "secret_env_var": "RAZORPAY_WEBHOOK_SECRET"
        },
        "firebase": {
            "enabled": True,
            "events": ["user.created", "user.deleted"],
            "url": "/webhooks/firebase",
            "secret_env_var": "FIREBASE_WEBHOOK_SECRET"
        }
    }
    
    return configs.get(service, {})


__all__ = [
    "WebhookManager",
    "BaseWebhookHandler",
    "webhook_manager",
    "handle_webhook_request",
    "get_webhook_config",
    "StripeWebhookHandler",
    "RazorpayWebhookHandler",
    "FirebaseWebhookHandler",
]