import hmac
import hashlib
import json
from typing import Dict, Any

from fastapi import HTTPException, status

from app.webhooks import BaseWebhookHandler


class RazorpayWebhookHandler(BaseWebhookHandler):
    """
    Razorpay webhook handler
    """

    def __init__(self):
        super().__init__("razorpay")

    async def verify_signature(self, payload: bytes, signature: str) -> bool:
        """
        Verify Razorpay webhook signature
        """
        if not self.secret_key:
            return True

        expected = hmac.new(
            self.secret_key.encode(),
            payload,
            hashlib.sha256
        ).hexdigest()

        return hmac.compare_digest(expected, signature)

    async def parse_payload(self, payload: bytes) -> Dict[str, Any]:
        try:
            return json.loads(payload.decode("utf-8"))
        except Exception:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid JSON payload"
            )

    async def process_event(self, event: Dict[str, Any]) -> Dict[str, Any]:
        event_type = event.get("event")

        if event_type == "payment.captured":
            return {"message": "Payment captured"}

        if event_type == "payment.failed":
            return {"message": "Payment failed"}

        return {"message": "Unhandled Razorpay event"}
