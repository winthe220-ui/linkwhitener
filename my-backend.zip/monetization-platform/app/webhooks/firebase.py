import json
from typing import Dict, Any

from fastapi import HTTPException, status

from app.webhooks import BaseWebhookHandler


class FirebaseWebhookHandler(BaseWebhookHandler):
    """
    Firebase webhook handler (Auth / User lifecycle events)
    """

    def __init__(self):
        super().__init__("firebase")

    async def verify_signature(self, payload: bytes, signature: str) -> bool:
        """
        Firebase webhooks usually rely on secure endpoints
        Signature verification is optional
        """
        return True

    async def parse_payload(self, payload: bytes) -> Dict[str, Any]:
        try:
            return json.loads(payload.decode("utf-8"))
        except Exception:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid JSON payload"
            )

    async def process_event(self, event: Dict[str, Any]) -> Dict[str, Any]:
        event_type = event.get("eventType")

        if event_type == "user.created":
            return {"message": "Firebase user created"}

        if event_type == "user.deleted":
            return {"message": "Firebase user deleted"}

        return {"message": "Unhandled Firebase event"}
