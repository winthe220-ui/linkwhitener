import logging
from fastapi import Request, HTTPException, status
from fastapi.responses import JSONResponse


logger = logging.getLogger("api.errors")


class ErrorHandlerMiddleware:
    """
    Global exception handler middleware
    """

    async def __call__(self, request: Request, call_next):
        try:
            return await call_next(request)

        except HTTPException as exc:
            raise exc

        except Exception as exc:
            request_id = getattr(request.state, "request_id", None)

            logger.error(
                f"Unhandled error | request_id={request_id}",
                exc_info=True
            )

            return JSONResponse(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                content={
                    "error": "Internal server error",
                    "request_id": request_id,
                },
            )


def error_handler_middleware(app):
    app.middleware("http")(ErrorHandlerMiddleware())
