from app.middleware.auth import (
    UserAuthMiddleware,
    AdminAuthMiddleware,
    OptionalAuthMiddleware,
    require_permission,
)

from app.middleware.cors import cors_middleware
from app.middleware.security import security_middleware
from app.middleware.logging import logging_middleware
from app.middleware.rate_limit import rate_limit_middleware
from app.middleware.error_handler import error_handler_middleware

__all__ = [
    # Auth
    "UserAuthMiddleware",
    "AdminAuthMiddleware",
    "OptionalAuthMiddleware",
    "require_permission",

    # Middleware setup functions
    "cors_middleware",
    "security_middleware",
    "logging_middleware",
    "rate_limit_middleware",
    "error_handler_middleware",
]
