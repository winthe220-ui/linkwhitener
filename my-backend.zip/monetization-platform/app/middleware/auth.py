"""
Authentication middleware for user and admin routes
"""
from datetime import datetime
from fastapi import Request, HTTPException, status, Depends
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from typing import Optional, Dict, Any, List
import re

from app.services.auth_service import auth_service
from app.services.user_service import user_service
from app.services.admin_service import admin_service
from app.models.user import UserStatus
from app.models.admin import AdminStatus
from app.core.cache import cache_manager


security = HTTPBearer(auto_error=False)


class AuthMiddleware:
    """Base authentication middleware"""
    
    async def __call__(self, request: Request):
        pass


class UserAuthMiddleware(AuthMiddleware):
    """User authentication middleware"""
    
    async def __call__(self, request: Request):
        # Get authorization header
        auth_header = request.headers.get("Authorization")
        
        if not auth_header:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Authorization header missing"
            )
        
        # Extract token
        try:
            scheme, token = auth_header.split()
            if scheme.lower() != "bearer":
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail="Invalid authentication scheme"
                )
        except ValueError:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid authorization header"
            )
        
        # Verify token
        try:
            # Verify JWT token
            payload = auth_service.token_utils.verify_token(token, token_type="access")
            
            # Check token type
            if payload.get("type") != "user":
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail="Invalid token type"
                )
            
            user_uid = payload.get("sub")
            if not user_uid:
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail="Invalid token payload"
                )
            
            # Check if token is revoked
            token_hash = auth_service.security_utils.hash_token(token)
            if await cache_manager.get(f"token_revoked:{token_hash}"):
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail="Token has been revoked"
                )
            
            # Get user from database
            user = await user_service.get_user_by_uid(user_uid)
            if not user:
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail="User not found"
                )
            
            # Check user status
            if user.status == UserStatus.BANNED:
                raise HTTPException(
                    status_code=status.HTTP_403_FORBIDDEN,
                    detail="Account is banned"
                )
            elif user.status == UserStatus.SUSPENDED:
                if user.suspended_until and user.suspended_until > datetime.utcnow():
                    raise HTTPException(
                        status_code=status.HTTP_403_FORBIDDEN,
                        detail=f"Account suspended until {user.suspended_until}"
                    )
                # Auto-reinstate if suspension expired
                await user_service.reinstate_user(user.uid)
            
            # Attach user to request state
            request.state.user = {
                "uid": user.uid,
                "phone": user.phone,
                "email": user.email,
                "username": user.username,
                "status": user.status.value,
                "role": "user",
                "permissions": ["user"],  # Basic user permissions
                "token_payload": payload
            }
            
        except HTTPException:
            raise
        except Exception as e:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail=f"Authentication failed: {str(e)}"
            )


class AdminAuthMiddleware(AuthMiddleware):
    """Admin authentication middleware"""
    
    def __init__(self, required_permissions: Optional[List[str]] = None):
        self.required_permissions = required_permissions or []
    
    async def __call__(self, request: Request):
        # Get authorization header
        auth_header = request.headers.get("Authorization")
        
        if not auth_header:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Authorization header missing"
            )
        
        # Extract token
        try:
            scheme, token = auth_header.split()
            if scheme.lower() != "bearer":
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail="Invalid authentication scheme"
                )
        except ValueError:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid authorization header"
            )
        
        # Verify token
        try:
            # Verify admin JWT token
            payload = await auth_service.verify_admin_token(token)
            
            # Check token type
            if payload.get("type") != "admin":
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail="Invalid token type"
                )
            
            admin_id = payload.get("sub")
            if not admin_id:
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail="Invalid token payload"
                )
            
            # Get admin from database
            admin = await admin_service.get_admin_by_email(admin_id)
            if not admin:
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail="Admin not found"
                )
            
            # Check admin status
            if admin.status != AdminStatus.ACTIVE:
                raise HTTPException(
                    status_code=status.HTTP_403_FORBIDDEN,
                    detail="Admin account is deactivated"
                )
            
            # Check IP whitelist if configured
            client_ip = request.client.host
            if admin.ip_whitelist and client_ip not in admin.ip_whitelist:
                raise HTTPException(
                    status_code=status.HTTP_403_FORBIDDEN,
                    detail="IP address not allowed"
                )
            
            # Check access schedule
            if not admin.is_within_access_schedule():
                raise HTTPException(
                    status_code=status.HTTP_403_FORBIDDEN,
                    detail="Access not allowed at this time"
                )
            
            # Check permissions if required
            if self.required_permissions:
                if not admin.has_all_permissions(self.required_permissions):
                    raise HTTPException(
                        status_code=status.HTTP_403_FORBIDDEN,
                        detail="Insufficient permissions"
                    )
            
            # Attach admin to request state
            request.state.admin = {
                "admin_id": admin.email,
                "email": admin.email,
                "role": admin.role.value,
                "permissions": admin.permissions,
                "name": admin.full_name,
                "is_super_admin": admin.is_super_admin,
                "ip_address": client_ip,
                "token_payload": payload
            }
            
        except HTTPException:
            raise
        except Exception as e:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail=f"Admin authentication failed: {str(e)}"
            )


class OptionalAuthMiddleware(AuthMiddleware):
    """Optional authentication middleware (for public endpoints)"""
    
    async def __call__(self, request: Request):
        # Get authorization header
        auth_header = request.headers.get("Authorization")
        
        if not auth_header:
            # No authentication provided, continue without user
            request.state.user = None
            return
        
        # Try to authenticate
        try:
            # Extract token
            scheme, token = auth_header.split()
            if scheme.lower() != "bearer":
                return
            
            # Try to verify as user token
            try:
                payload = auth_service.token_utils.verify_token(token, token_type="access")
                
                if payload.get("type") == "user":
                    user_uid = payload.get("sub")
                    if user_uid:
                        user = await user_service.get_user_by_uid(user_uid)
                        if user and user.status == UserStatus.ACTIVE:
                            request.state.user = {
                                "uid": user.uid,
                                "phone": user.phone,
                                "email": user.email,
                                "username": user.username,
                                "status": user.status.value,
                                "role": "user",
                                "permissions": ["user"]
                            }
                            return
            except:
                pass
            
            # Try to verify as admin token
            try:
                payload = await auth_service.verify_admin_token(token)
                
                if payload.get("type") == "admin":
                    admin_id = payload.get("sub")
                    if admin_id:
                        admin = await admin_service.get_admin_by_email(admin_id)
                        if admin and admin.status == AdminStatus.ACTIVE:
                            request.state.admin = {
                                "admin_id": admin.email,
                                "email": admin.email,
                                "role": admin.role.value,
                                "permissions": admin.permissions,
                                "name": admin.full_name,
                                "is_super_admin": admin.is_super_admin
                            }
                            return
            except:
                pass
            
        except Exception:
            # Any error, treat as no authentication
            pass
        
        # If we get here, authentication failed but it's optional
        request.state.user = None
        request.state.admin = None


# Dependency functions for FastAPI
async def get_current_user(request: Request) -> Dict[str, Any]:
    """Get current user from request"""
    if not hasattr(request.state, "user") or not request.state.user:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Not authenticated"
        )
    return request.state.user


async def get_current_active_user(current_user: Dict[str, Any] = Depends(get_current_user)) -> Dict[str, Any]:
    """Get current active user (not banned/suspended)"""
    if current_user.get("status") == "banned":
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Account is banned"
        )
    elif current_user.get("status") == "suspended":
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Account is suspended"
        )
    return current_user


async def get_current_admin(request: Request) -> Dict[str, Any]:
    """Get current admin from request"""
    if not hasattr(request.state, "admin") or not request.state.admin:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Not authenticated as admin"
        )
    return request.state.admin


async def get_current_active_admin(current_admin: Dict[str, Any] = Depends(get_current_admin)) -> Dict[str, Any]:
    """Get current active admin"""
    # Additional checks can be added here
    return current_admin


def require_permission(permissions: List[str]):
    """Decorator to require specific permissions"""
    async def permission_dependency(current_admin: Dict[str, Any] = Depends(get_current_admin)):
        admin_permissions = current_admin.get("permissions", [])
        
        # Super admin has all permissions
        if current_admin.get("is_super_admin") or "*" in admin_permissions:
            return current_admin
        
        # Check required permissions
        for perm in permissions:
            if perm not in admin_permissions:
                raise HTTPException(
                    status_code=status.HTTP_403_FORBIDDEN,
                    detail=f"Required permission: {perm}"
                )
        
        return current_admin
    
    return permission_dependency


def require_role(roles: List[str]):
    """Decorator to require specific role"""
    async def role_dependency(current_admin: Dict[str, Any] = Depends(get_current_admin)):
        admin_role = current_admin.get("role")
        
        if admin_role not in roles:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=f"Required role: {', '.join(roles)}"
            )
        
        return current_admin
    
    return role_dependency


# Rate limiting middleware
class RateLimitMiddleware:
    """Rate limiting middleware"""
    
    def __init__(self, rate_limiter):
        self.rate_limiter = rate_limiter
    
    async def __call__(self, request: Request, call_next):
        # Skip rate limiting for certain paths
        skip_paths = ["/health", "/docs", "/openapi.json", "/favicon.ico"]
        if any(request.url.path.startswith(path) for path in skip_paths):
            return await call_next(request)
        
        client_ip = request.client.host
        
        try:
            # Global rate limit
            endpoint = request.url.path.replace("/", "_").strip("_")
            await self.rate_limiter.check_rate_limit(
                identifier=f"global:{endpoint}",
                action=endpoint,
                limit=500,  # Global limit
                period=60
            )
            
            # IP-based rate limit
            await self.rate_limiter.check_rate_limit(
                identifier=f"ip:{client_ip}",
                action=endpoint,
                limit=100,  # Per IP limit
                period=60
            )
            
            # User-based rate limit (if authenticated)
            if hasattr(request.state, "user") and request.state.user:
                user_uid = request.state.user.get("uid")
                if user_uid:
                    await self.rate_limiter.check_rate_limit(
                        identifier=f"user:{user_uid}",
                        action=endpoint,
                        limit=60,  # Per user limit
                        period=60
                    )
            
        except HTTPException as e:
            # Add rate limit headers to response
            response = await call_next(request)
            for key, value in e.headers.items():
                if key.startswith("X-RateLimit-") or key == "Retry-After":
                    response.headers[key] = value
            return response
        
        return await call_next(request)


# CORS middleware configuration
from fastapi.middleware.cors import CORSMiddleware

def setup_cors(app, origins):
    """Setup CORS middleware"""
    app.add_middleware(
        CORSMiddleware,
        allow_origins=origins,
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
        expose_headers=["X-RateLimit-Limit", "X-RateLimit-Remaining", "X-RateLimit-Reset"]
    )


# Security headers middleware
class SecurityHeadersMiddleware:
    """Add security headers to responses"""
    
    async def __call__(self, request: Request, call_next):
        response = await call_next(request)
        
        # Security headers
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["X-Frame-Options"] = "DENY"
        response.headers["X-XSS-Protection"] = "1; mode=block"
        response.headers["Strict-Transport-Security"] = "max-age=31536000; includeSubDomains"
        response.headers["Content-Security-Policy"] = "default-src 'self'"
        response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
        
        return response


# Request logging middleware
class RequestLoggingMiddleware:
    """Log all requests"""
    
    async def __call__(self, request: Request, call_next):
        import logging
        logger = logging.getLogger("request")
        
        # Generate request ID
        import uuid
        request_id = str(uuid.uuid4())
        request.state.request_id = request_id
        
        # Log request
        logger.info(f"Request {request_id}: {request.method} {request.url.path} from {request.client.host}")
        
        # Process request
        start_time = datetime.utcnow()
        response = await call_next(request)
        end_time = datetime.utcnow()
        
        # Log response
        duration = (end_time - start_time).total_seconds() * 1000
        logger.info(f"Response {request_id}: {response.status_code} in {duration:.2f}ms")
        
        # Add request ID to response headers
        response.headers["X-Request-ID"] = request_id
        
        return response


# Error handling middleware
class ErrorHandlerMiddleware:
    """Global error handler"""
    
    async def __call__(self, request: Request, call_next):
        try:
            return await call_next(request)
        except HTTPException:
            # Let HTTP exceptions pass through
            raise
        except Exception as e:
            import logging
            logger = logging.getLogger("error")
            logger.error(f"Unhandled error: {str(e)}", exc_info=True)
            
            # Return generic error response
            from fastapi.responses import JSONResponse
            return JSONResponse(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                content={
                    "error": "Internal server error",
                    "request_id": getattr(request.state, "request_id", None)
                }
            )