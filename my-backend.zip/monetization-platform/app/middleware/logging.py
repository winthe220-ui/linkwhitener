import logging
import uuid
from datetime import datetime
from fastapi import Request


logger = logging.getLogger("api.requests")


class RequestLoggingMiddleware:
    """
    Logs incoming requests & outgoing responses
    """

    async def __call__(self, request: Request, call_next):
        request_id = str(uuid.uuid4())
        request.state.request_id = request_id

        start_time = datetime.utcnow()

        logger.info(
            f"[{request_id}] {request.method} {request.url.path} "
            f"IP={request.client.host if request.client else 'unknown'}"
        )

        response = await call_next(request)

        duration = (datetime.utcnow() - start_time).total_seconds() * 1000

        response.headers["X-Request-ID"] = request_id

        logger.info(
            f"[{request_id}] status={response.status_code} "
            f"duration={duration:.2f}ms"
        )

        return response


def logging_middleware(app):
    app.middleware("http")(RequestLoggingMiddleware())
