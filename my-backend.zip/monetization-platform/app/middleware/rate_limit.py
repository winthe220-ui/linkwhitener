from fastapi import Request, HTTPException
from app.core.rate_limiter import rate_limiter


class RateLimitMiddleware:
    """
    Global rate limiting middleware
    """

    async def __call__(self, request: Request, call_next):
        skip_paths = {"/health", "/docs", "/openapi.json", "/favicon.ico"}

        if request.url.path in skip_paths:
            return await call_next(request)

        client_ip = request.client.host if request.client else "unknown"
        endpoint = request.url.path.replace("/", "_").strip("_")

        try:
            await rate_limiter.check_global_rate_limit(endpoint)
            await rate_limiter.check_ip_rate_limit(client_ip, endpoint)

            if hasattr(request.state, "user") and request.state.user:
                uid = request.state.user.get("uid")
                if uid:
                    await rate_limiter.check_user_rate_limit(uid, endpoint)

        except HTTPException as exc:
            return exc

        return await call_next(request)


def rate_limit_middleware(app):
    app.middlewa
