import uuid
import random
import string
import secrets
from datetime import datetime


class ShortCodeGenerator:
    @staticmethod
    def generate(length: int = 6) -> str:
        return "".join(secrets.choice(string.ascii_letters + string.digits) for _ in range(length))


class ReferralCodeGenerator:
    @staticmethod
    def generate(prefix: str = "REF") -> str:
        return f"{prefix}{secrets.token_hex(4).upper()}"


class PasswordGenerator:
    @staticmethod
    def generate(length: int = 12) -> str:
        chars = string.ascii_letters + string.digits + "!@#$%^&*"
        return "".join(secrets.choice(chars) for _ in range(length))


class TokenGenerator:
    @staticmethod
    def generate() -> str:
        return secrets.token_urlsafe(32)


class OTPGenerator:
    @staticmethod
    def generate() -> str:
        return f"{random.randint(100000, 999999)}"


class IDGenerator:
    @staticmethod
    def generate(prefix: str = "") -> str:
        return f"{prefix}{uuid.uuid4().hex}"


# Aliases for compatibility
CodeGenerator = IDGenerator
NameGenerator = IDGenerator
LoremIpsumGenerator = IDGenerator
DataGenerator = IDGenerator
MockDataGenerator = IDGenerator
TestDataGenerator = IDGenerator
FixtureGenerator = IDGenerator
ReportGenerator = IDGenerator
ChartGenerator = IDGenerator
QRCodeGenerator = IDGenerator
BarcodeGenerator = IDGenerator
ImageGenerator = IDGenerator
DocumentGenerator = IDGenerator
PDFGenerator = IDGenerator
ExcelGenerator = IDGenerator
CSVGenerator = IDGenerator
JSONGenerator = IDGenerator
XMLGenerator = IDGenerator
HTMLGenerator = IDGenerator
TemplateGenerator = IDGenerator
EmailTemplateGenerator = IDGenerator
SMSTemplateGenerator = IDGenerator
NotificationTemplateGenerator = IDGenerator
AuditLogGenerator = IDGenerator
AnalyticsReportGenerator = IDGenerator
EarningsReportGenerator = IDGenerator
WithdrawalReportGenerator = IDGenerator
UserReportGenerator = IDGenerator
LinkReportGenerator = IDGenerator
AdminReportGenerator = IDGenerator
SystemReportGenerator = IDGenerator
