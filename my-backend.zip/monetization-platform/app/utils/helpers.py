import re
import uuid
from datetime import datetime
from urllib.parse import urlparse


def generate_short_code(length: int = 6) -> str:
    return uuid.uuid4().hex[:length]


def generate_session_id() -> str:
    return uuid.uuid4().hex


def generate_transaction_id() -> str:
    return f"txn_{uuid.uuid4().hex[:12]}"


def format_currency(amount: float, currency: str = "USD") -> str:
    return f"{currency} {amount:,.2f}"


def format_date(dt: datetime) -> str:
    return dt.isoformat() if dt else ""


def calculate_percentage(value: float, total: float) -> float:
    return round((value / total) * 100, 2) if total else 0.0


def validate_url(url: str) -> bool:
    return bool(urlparse(url).scheme)


def sanitize_input(text: str) -> str:
    return re.sub(r"[<>]", "", text)


def truncate_text(text: str, length: int = 100) -> str:
    return text[:length]


def generate_referral_code() -> str:
    return f"REF-{uuid.uuid4().hex[:8].upper()}"


def get_client_ip(request):
    if request and request.client:
        return request.client.host
    return None


def get_user_agent(request):
    return request.headers.get("User-Agent") if request else None


def extract_domain(url: str) -> str:
    return urlparse(url).netloc
