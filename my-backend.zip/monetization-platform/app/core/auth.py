import json
import firebase_admin
from firebase_admin import auth, credentials
from firebase_admin.exceptions import FirebaseError
import jwt
from datetime import datetime, timedelta
from typing import Optional, Dict, Any, Tuple
from fastapi import HTTPException, status
import redis
import hashlib
from app.core.firebase_client import FirebaseClient
from app.config import settings


class AuthService:
    """Authentication service for both users and admins"""
    
    def __init__(self):
        self.firebase = FirebaseClient()
        self.redis = redis.from_url(settings.redis_url)
        
    async def verify_firebase_token(self, id_token: str) -> Dict[str, Any]:
        """Verify Firebase ID token"""
        try:
            decoded_token = auth.verify_id_token(id_token)
            
            # Check if token is revoked
            token_hash = hashlib.sha256(id_token.encode()).hexdigest()
            if self.redis.get(f"token_revoked:{token_hash}"):
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail="Token has been revoked"
                )
            
            return {
                "uid": decoded_token["uid"],
                "phone": decoded_token.get("phone_number"),
                "email": decoded_token.get("email"),
                "email_verified": decoded_token.get("email_verified", False),
                "is_new_user": False,
                "valid": True
            }
            
        except auth.ExpiredIdTokenError:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Token has expired"
            )
        except auth.RevokedIdTokenError:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Token has been revoked"
            )
        except auth.InvalidIdTokenError:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid token"
            )
        except Exception as e:
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=f"Token verification failed: {str(e)}"
            )
    
    async def create_custom_token(self, user_uid: str, claims: Dict[str, Any] = None) -> str:
        """Create custom JWT token for user"""
        payload = {
            "sub": user_uid,
            "iss": settings.app_name,
            "iat": datetime.utcnow(),
            "exp": datetime.utcnow() + timedelta(days=settings.user_token_expire_days),
            "type": "access",
            **claims
        }
        
        token = jwt.encode(payload, settings.user_jwt_secret, algorithm="HS256")
        
        # Store token hash for revocation capability
        token_hash = hashlib.sha256(token.encode()).hexdigest()
        self.redis.setex(
            f"token:{token_hash}",
            settings.user_token_expire_days * 24 * 3600,
            user_uid
        )
        
        return token
    
    async def create_refresh_token(self, user_uid: str) -> str:
        """Create refresh token"""
        payload = {
            "sub": user_uid,
            "iss": settings.app_name,
            "iat": datetime.utcnow(),
            "exp": datetime.utcnow() + timedelta(days=settings.refresh_token_expire_days),
            "type": "refresh"
        }
        
        refresh_token = jwt.encode(payload, settings.user_jwt_secret, algorithm="HS256")
        
        # Store refresh token
        refresh_hash = hashlib.sha256(refresh_token.encode()).hexdigest()
        self.redis.setex(
            f"refresh_token:{refresh_hash}",
            settings.refresh_token_expire_days * 24 * 3600,
            user_uid
        )
        
        return refresh_token
    
    async def verify_custom_token(self, token: str) -> Dict[str, Any]:
        """Verify custom JWT token"""
        try:
            # Check if token is revoked
            token_hash = hashlib.sha256(token.encode()).hexdigest()
            if self.redis.get(f"token_revoked:{token_hash}"):
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail="Token has been revoked"
                )
            
            payload = jwt.decode(
                token,
                settings.user_jwt_secret,
                algorithms=["HS256"]
            )
            
            # Verify token is stored
            stored_uid = self.redis.get(f"token:{token_hash}")
            if not stored_uid or stored_uid.decode() != payload["sub"]:
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail="Token not found"
                )
            
            return payload
            
        except jwt.ExpiredSignatureError:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Token has expired"
            )
        except jwt.InvalidTokenError:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid token"
            )
    
    async def refresh_access_token(self, refresh_token: str) -> Tuple[str, str]:
        """Refresh access token using refresh token"""
        try:
            # Verify refresh token
            refresh_hash = hashlib.sha256(refresh_token.encode()).hexdigest()
            user_uid = self.redis.get(f"refresh_token:{refresh_hash}")
            
            if not user_uid:
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail="Invalid refresh token"
                )
            
            user_uid = user_uid.decode()
            
            # Create new tokens
            new_access_token = await self.create_custom_token(user_uid)
            new_refresh_token = await self.create_refresh_token(user_uid)
            
            # Delete old refresh token
            self.redis.delete(f"refresh_token:{refresh_hash}")
            
            return new_access_token, new_refresh_token
            
        except Exception as e:
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=f"Token refresh failed: {str(e)}"
            )
    
    async def revoke_token(self, token: str) -> bool:
        """Revoke a token (logout)"""
        try:
            token_hash = hashlib.sha256(token.encode()).hexdigest()
            
            # Add to revoked tokens (24 hour expiry for safety)
            self.redis.setex(f"token_revoked:{token_hash}", 86400, "revoked")
            
            # Remove from active tokens
            self.redis.delete(f"token:{token_hash}")
            
            return True
            
        except Exception as e:
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=f"Token revocation failed: {str(e)}"
            )
    
    async def revoke_all_user_tokens(self, user_uid: str) -> bool:
        """Revoke all tokens for a user (force logout)"""
        try:
            # Find all tokens for user (this is simplified - in production use Redis sets)
            pattern = f"token:*"
            keys = []
            cursor = 0
            
            while True:
                cursor, found_keys = self.redis.scan(cursor=cursor, match=pattern, count=100)
                keys.extend(found_keys)
                if cursor == 0:
                    break
            
            for key in keys:
                stored_uid = self.redis.get(key)
                if stored_uid and stored_uid.decode() == user_uid:
                    token_hash = key.decode().split(":")[1]
                    self.redis.setex(f"token_revoked:{token_hash}", 86400, "revoked")
                    self.redis.delete(key)
            
            # Revoke refresh tokens
            pattern = f"refresh_token:*"
            keys = []
            cursor = 0
            
            while True:
                cursor, found_keys = self.redis.scan(cursor=cursor, match=pattern, count=100)
                keys.extend(found_keys)
                if cursor == 0:
                    break
            
            for key in keys:
                stored_uid = self.redis.get(key)
                if stored_uid and stored_uid.decode() == user_uid:
                    self.redis.delete(key)
            
            return True
            
        except Exception as e:
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=f"Token revocation failed: {str(e)}"
            )
    
    # Admin Authentication
    async def verify_admin_credentials(self, email: str, password: str) -> Dict[str, Any]:
        """Verify admin credentials"""
        try:
            # Get admin from Firestore
            admin_doc = await self.firebase.get_document(
                collection="admins",
                document_id=email.lower()  # Using email as document ID
            )
            
            if not admin_doc:
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail="Invalid credentials"
                )
            
            # Verify password
            from app.utils.security import verify_password_hash
            if not verify_password_hash(password, admin_doc["password_hash"]):
                # Track failed attempts
                await self.track_failed_login(email)
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail="Invalid credentials"
                )
            
            # Check if admin is active
            if not admin_doc.get("is_active", True):
                raise HTTPException(
                    status_code=status.HTTP_403_FORBIDDEN,
                    detail="Admin account is deactivated"
                )
            
            # Reset failed attempts on successful login
            await self.reset_failed_login(email)
            
            return {
                "admin_id": admin_doc["email"],
                "email": admin_doc["email"],
                "role": admin_doc.get("role", "admin"),
                "permissions": admin_doc.get("permissions", []),
                "name": admin_doc.get("name", ""),
                "is_active": admin_doc.get("is_active", True)
            }
            
        except HTTPException:
            raise
        except Exception as e:
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=f"Admin authentication failed: {str(e)}"
            )
    
    async def create_admin_token(self, admin_data: Dict[str, Any]) -> str:
        """Create JWT token for admin"""
        payload = {
            "sub": admin_data["admin_id"],
            "email": admin_data["email"],
            "role": admin_data["role"],
            "permissions": admin_data["permissions"],
            "name": admin_data.get("name", ""),
            "iss": settings.app_name,
            "iat": datetime.utcnow(),
            "exp": datetime.utcnow() + timedelta(hours=settings.admin_token_expire_hours),
            "type": "admin_access"
        }
        
        token = jwt.encode(payload, settings.admin_jwt_secret, algorithm="HS256")
        
        # Store admin session
        session_id = hashlib.sha256(token.encode()).hexdigest()
        session_data = {
            "admin_id": admin_data["admin_id"],
            "email": admin_data["email"],
            "role": admin_data["role"],
            "login_time": datetime.utcnow().isoformat(),
            "ip_address": get_client_ip(),  # Function to get client IP
            "user_agent": get_user_agent()   # Function to get user agent
        }
        
        self.redis.setex(
            f"admin_session:{session_id}",
            settings.admin_token_expire_hours * 3600,
            json.dumps(session_data)
        )
        
        return token
    
    async def verify_admin_token(self, token: str) -> Dict[str, Any]:
        """Verify admin JWT token"""
        try:
            payload = jwt.decode(
                token,
                settings.admin_jwt_secret,
                algorithms=["HS256"]
            )
            
            # Check session
            session_id = hashlib.sha256(token.encode()).hexdigest()
            session_data = self.redis.get(f"admin_session:{session_id}")
            
            if not session_data:
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail="Session expired"
                )
            
            session_data = json.loads(session_data)
            
            # Add session data to payload
            payload.update({
                "session_id": session_id,
                "login_time": session_data["login_time"],
                "ip_address": session_data.get("ip_address")
            })
            
            return payload
            
        except jwt.ExpiredSignatureError:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Token has expired"
            )
        except jwt.InvalidTokenError:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid token"
            )
        except Exception as e:
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=f"Token verification failed: {str(e)}"
            )
    
    async def track_failed_login(self, identifier: str) -> None:
        """Track failed login attempts"""
        key = f"failed_login:{identifier}"
        attempts = self.redis.incr(key)
        
        if attempts == 1:
            # Set expiry on first attempt
            self.redis.expire(key, settings.login_block_minutes * 60)
        
        if attempts >= settings.max_login_attempts:
            # Block the account temporarily
            block_key = f"login_blocked:{identifier}"
            self.redis.setex(
                block_key,
                settings.login_block_minutes * 60,
                "blocked"
            )
    
    async def reset_failed_login(self, identifier: str) -> None:
        """Reset failed login attempts"""
        self.redis.delete(f"failed_login:{identifier}")
        self.redis.delete(f"login_blocked:{identifier}")
    
    async def is_login_blocked(self, identifier: str) -> bool:
        """Check if login is blocked"""
        return bool(self.redis.get(f"login_blocked:{identifier}"))


# Singleton instance
auth_service = AuthService()

from fastapi import Request
from typing import Optional


def get_client_ip(request: Optional[Request]) -> Optional[str]:
    """
    Safely extract client IP from request
    """
    if not request:
        return None

    # Check forwarded headers (behind proxy / load balancer)
    x_forwarded_for = request.headers.get("X-Forwarded-For")
    if x_forwarded_for:
        return x_forwarded_for.split(",")[0].strip()

    if request.client:
        return request.client.host

    return None


def get_user_agent(request: Optional[Request]) -> Optional[str]:
    """
    Extract user agent from request
    """
    if not request:
        return None

    return request.headers.get("User-Agent")
