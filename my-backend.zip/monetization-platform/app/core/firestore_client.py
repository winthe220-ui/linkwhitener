"""
Firestore client with async operations
"""
import asyncio
from typing import Optional, Dict, Any, List, Tuple
from datetime import datetime
from google.cloud import firestore
from google.cloud.firestore_v1 import FieldFilter

from app.config import settings
from app.database import firestore_client as sync_client


class AsyncFirestoreClient:
    """Async wrapper for Firestore operations"""
    
    def __init__(self):
        self.client = sync_client.client
    
    # ==================== BASIC CRUD OPERATIONS ====================
    
    async def get_document(self, collection: str, document_id: str) -> Optional[Dict[str, Any]]:
        """Async get document"""
        return await asyncio.to_thread(
            sync_client.get_document,
            collection,
            document_id
        )
    
    async def create_document(self, collection: str, document_id: str, data: Dict[str, Any]) -> bool:
        """Async create document"""
        return await asyncio.to_thread(
            sync_client.create_document,
            collection,
            document_id,
            data
        )
    
    async def update_document(self, collection: str, document_id: str, data: Dict[str, Any]) -> bool:
        """Async update document"""
        return await asyncio.to_thread(
            sync_client.update_document,
            collection,
            document_id,
            data
        )
    
    async def delete_document(self, collection: str, document_id: str) -> bool:
        """Async delete document"""
        return await asyncio.to_thread(
            sync_client.delete_document,
            collection,
            document_id
        )
    
    async def query_document(self, collection: str, field: str, op: str, value: Any,
                           limit: int = 100) -> List[Dict[str, Any]]:
        """Async query documents"""
        return await asyncio.to_thread(
            sync_client.query_document,
            collection,
            field,
            op,
            value,
            limit
        )
    
    # ==================== ADVANCED OPERATIONS ====================
    
    async def get_documents_by_ids(self, collection: str, document_ids: List[str]) -> Dict[str, Optional[Dict[str, Any]]]:
        """Get multiple documents by IDs"""
        try:
            def _get_documents():
                docs = {}
                for doc_id in document_ids:
                    doc = self.client.collection(collection).document(doc_id).get()
                    if doc.exists:
                        data = doc.to_dict()
                        data["id"] = doc.id
                        docs[doc_id] = data
                    else:
                        docs[doc_id] = None
                return docs
            
            return await asyncio.to_thread(_get_documents)
        except Exception as e:
            print(f"Firestore get documents by IDs error: {e}")
            return {}
    
    async def query_with_filters(self, collection: str, filters: List[Tuple[str, str, Any]],
                               order_by: Optional[Tuple[str, str]] = None,
                               limit: int = 100) -> List[Dict[str, Any]]:
        """Query with multiple filters"""
        try:
            def _query():
                query = self.client.collection(collection)
                
                # Apply filters
                for field, operator, value in filters:
                    if operator == "==":
                        query = query.where(field, "==", value)
                    elif operator == ">=":
                        query = query.where(field, ">=", value)
                    elif operator == "<=":
                        query = query.where(field, "<=", value)
                    elif operator == ">":
                        query = query.where(field, ">", value)
                    elif operator == "<":
                        query = query.where(field, "<", value)
                    elif operator == "!=":
                        query = query.where(field, "!=", value)
                    elif operator == "in":
                        query = query.where(field, "in", value)
                    elif operator == "array_contains":
                        query = query.where(field, "array_contains", value)
                    elif operator == "array_contains_any":
                        query = query.where(field, "array_contains_any", value)
                
                # Apply ordering
                if order_by:
                    field, direction = order_by
                    query = query.order_by(field, direction=direction)
                
                # Apply limit
                query = query.limit(limit)
                
                # Execute query
                docs = query.stream()
                
                results = []
                for doc in docs:
                    data = doc.to_dict()
                    data["id"] = doc.id
                    results.append(data)
                
                return results
            
            return await asyncio.to_thread(_query)
        except Exception as e:
            print(f"Firestore query with filters error: {e}")
            return []
    
    async def paginated_query(self, collection: str, filters: List[Tuple[str, str, Any]],
                            order_by: Tuple[str, str], limit: int = 50,
                            start_after: Optional[Any] = None) -> Tuple[List[Dict[str, Any]], Optional[Any]]:
        """Paginated query with cursor"""
        try:
            def _paginated_query():
                query = self.client.collection(collection)
                
                # Apply filters
                for field, operator, value in filters:
                    if operator == "==":
                        query = query.where(field, "==", value)
                    elif operator == ">=":
                        query = query.where(field, ">=", value)
                    elif operator == "<=":
                        query = query.where(field, "<=", value)
                    elif operator == ">":
                        query = query.where(field, ">", value)
                    elif operator == "<":
                        query = query.where(field, "<", value)
                    elif operator == "in":
                        query = query.where(field, "in", value)
                    elif operator == "array_contains":
                        query = query.where(field, "array_contains", value)
                
                # Apply ordering
                field, direction = order_by
                query = query.order_by(field, direction=direction)
                
                # Apply cursor
                if start_after:
                    query = query.start_after({field: start_after})
                
                # Apply limit + 1 to check if there are more results
                query = query.limit(limit + 1)
                
                # Execute query
                docs = query.stream()
                
                results = []
                last_doc = None
                
                for i, doc in enumerate(docs):
                    if i < limit:
                        data = doc.to_dict()
                        data["id"] = doc.id
                        results.append(data)
                        last_doc = doc
                    else:
                        # We got an extra document, so there are more results
                        last_doc = doc
                        break
                
                # Get next cursor value
                next_cursor = None
                if last_doc and len(results) == limit:
                    next_cursor = last_doc.to_dict().get(field)
                
                return results, next_cursor
            
            return await asyncio.to_thread(_paginated_query)
        except Exception as e:
            print(f"Firestore paginated query error: {e}")
            return [], None
    
    async def count_documents(self, collection: str, filters: Optional[List[Tuple[str, str, Any]]] = None) -> int:
        """Count documents matching filters"""
        try:
            def _count():
                query = self.client.collection(collection)
                
                # Apply filters if provided
                if filters:
                    for field, operator, value in filters:
                        if operator == "==":
                            query = query.where(field, "==", value)
                        elif operator == ">=":
                            query = query.where(field, ">=", value)
                        elif operator == "<=":
                            query = query.where(field, "<=", value)
                        elif operator == ">":
                            query = query.where(field, ">", value)
                        elif operator == "<":
                            query = query.where(field, "<", value)
                
                # Get count
                count_query = query.count()
                count_result = count_query.get()
                return count_result[0].value
            
            return await asyncio.to_thread(_count)
        except Exception as e:
            print(f"Firestore count documents error: {e}")
            return 0
    
    async def batch_create(self, collection: str, documents: Dict[str, Dict[str, Any]]) -> bool:
        """Batch create documents"""
        return await asyncio.to_thread(
            sync_client.batch_create,
            collection,
            documents
        )
    
    async def batch_update(self, collection: str, updates: Dict[str, Dict[str, Any]]) -> bool:
        """Batch update documents"""
        try:
            def _batch_update():
                batch = self.client.batch()
                
                for doc_id, data in updates.items():
                    doc_ref = self.client.collection(collection).document(doc_id)
                    batch.update(doc_ref, data)
                
                batch.commit()
                return True
            
            return await asyncio.to_thread(_batch_update)
        except Exception as e:
            print(f"Firestore batch update error: {e}")
            return False
    
    async def batch_delete(self, collection: str, document_ids: List[str]) -> bool:
        """Batch delete documents"""
        try:
            def _batch_delete():
                batch = self.client.batch()
                
                for doc_id in document_ids:
                    doc_ref = self.client.collection(collection).document(doc_id)
                    batch.delete(doc_ref)
                
                batch.commit()
                return True
            
            return await asyncio.to_thread(_batch_delete)
        except Exception as e:
            print(f"Firestore batch delete error: {e}")
            return False
    
    # ==================== TRANSACTION OPERATIONS ====================
    
    async def run_transaction(self, callback) -> Any:
        """Run Firestore transaction"""
        try:
            return await asyncio.to_thread(
                self.client.run_transaction,
                callback
            )
        except Exception as e:
            print(f"Firestore transaction error: {e}")
            raise
    
    async def increment_field(self, collection: str, document_id: str, field: str, amount: int = 1) -> bool:
        """Atomically increment a field"""
        return await asyncio.to_thread(
            sync_client.increment_field,
            collection,
            document_id,
            field,
            amount
        )
    
    async def add_to_array(self, collection: str, document_id: str, field: str, value: Any) -> bool:
        """Add value to array field"""
        return await asyncio.to_thread(
            sync_client.add_to_array,
            collection,
            document_id,
            field,
            value
        )
    
    async def remove_from_array(self, collection: str, document_id: str, field: str, value: Any) -> bool:
        """Remove value from array field"""
        return await asyncio.to_thread(
            sync_client.remove_from_array,
            collection,
            document_id,
            field,
            value
        )
    
    # ==================== COMPOUND OPERATIONS ====================
    
    async def get_or_create(self, collection: str, document_id: str, 
                          default_data: Dict[str, Any]) -> Tuple[Dict[str, Any], bool]:
        """Get document or create with default data"""
        try:
            doc = await self.get_document(collection, document_id)
            
            if doc:
                return doc, False
            
            # Create with default data
            await self.create_document(collection, document_id, default_data)
            return default_data, True
            
        except Exception as e:
            print(f"Firestore get or create error: {e}")
            raise
    
    async def update_or_create(self, collection: str, document_id: str, 
                             data: Dict[str, Any]) -> Tuple[Dict[str, Any], bool]:
        """Update document or create if not exists"""
        try:
            existing = await self.get_document(collection, document_id)
            
            if existing:
                # Update existing
                await self.update_document(collection, document_id, data)
                updated = {**existing, **data}
                return updated, False
            else:
                # Create new
                await self.create_document(collection, document_id, data)
                return data, True
                
        except Exception as e:
            print(f"Firestore update or create error: {e}")
            raise
    
    async def soft_delete(self, collection: str, document_id: str, 
                         deleted_by: Optional[str] = None) -> bool:
        """Soft delete document (mark as deleted instead of removing)"""
        try:
            update_data = {
                "deleted": True,
                "deleted_at": datetime.utcnow().isoformat()
            }
            
            if deleted_by:
                update_data["deleted_by"] = deleted_by
            
            return await self.update_document(collection, document_id, update_data)
            
        except Exception as e:
            print(f"Firestore soft delete error: {e}")
            return False
    
    # ==================== AGGREGATION OPERATIONS ====================
    
    async def aggregate_sum(self, collection: str, field: str, 
                          filters: Optional[List[Tuple[str, str, Any]]] = None) -> float:
        """Calculate sum of a field"""
        try:
            def _aggregate_sum():
                query = self.client.collection(collection)
                
                # Apply filters
                if filters:
                    for field_name, operator, value in filters:
                        if operator == "==":
                            query = query.where(field_name, "==", value)
                        elif operator == ">=":
                            query = query.where(field_name, ">=", value)
                        elif operator == "<=":
                            query = query.where(field_name, "<=", value)
                        elif operator == ">":
                            query = query.where(field_name, ">", value)
                        elif operator == "<":
                            query = query.where(field_name, "<", value)
                
                # Get all documents and sum
                docs = query.stream()
                total = 0.0
                
                for doc in docs:
                    data = doc.to_dict()
                    if field in data:
                        total += float(data[field])
                
                return total
            
            return await asyncio.to_thread(_aggregate_sum)
        except Exception as e:
            print(f"Firestore aggregate sum error: {e}")
            return 0.0
    
    async def aggregate_average(self, collection: str, field: str,
                              filters: Optional[List[Tuple[str, str, Any]]] = None) -> Tuple[float, int]:
        """Calculate average of a field"""
        try:
            def _aggregate_average():
                query = self.client.collection(collection)
                
                # Apply filters
                if filters:
                    for field_name, operator, value in filters:
                        if operator == "==":
                            query = query.where(field_name, "==", value)
                        elif operator == ">=":
                            query = query.where(field_name, ">=", value)
                        elif operator == "<=":
                            query = query.where(field_name, "<=", value)
                        elif operator == ">":
                            query = query.where(field_name, ">", value)
                        elif operator == "<":
                            query = query.where(field_name, "<", value)
                
                # Get all documents and calculate average
                docs = query.stream()
                total = 0.0
                count = 0
                
                for doc in docs:
                    data = doc.to_dict()
                    if field in data:
                        total += float(data[field])
                        count += 1
                
                average = total / count if count > 0 else 0.0
                return average, count
            
            return await asyncio.to_thread(_aggregate_average)
        except Exception as e:
            print(f"Firestore aggregate average error: {e}")
            return 0.0, 0
    
    async def get_field_stats(self, collection: str, field: str,
                            filters: Optional[List[Tuple[str, str, Any]]] = None) -> Dict[str, Any]:
        """Get statistics for a field (min, max, avg, sum, count)"""
        try:
            def _get_field_stats():
                query = self.client.collection(collection)
                
                # Apply filters
                if filters:
                    for field_name, operator, value in filters:
                        if operator == "==":
                            query = query.where(field_name, "==", value)
                        elif operator == ">=":
                            query = query.where(field_name, ">=", value)
                        elif operator == "<=":
                            query = query.where(field_name, "<=", value)
                        elif operator == ">":
                            query = query.where(field_name, ">", value)
                        elif operator == "<":
                            query = query.where(field_name, "<", value)
                
                # Get all documents and calculate stats
                docs = query.stream()
                
                values = []
                for doc in docs:
                    data = doc.to_dict()
                    if field in data:
                        values.append(float(data[field]))
                
                if not values:
                    return {
                        "count": 0,
                        "sum": 0.0,
                        "average": 0.0,
                        "min": 0.0,
                        "max": 0.0,
                        "std_dev": 0.0
                    }
                
                count = len(values)
                total = sum(values)
                average = total / count
                minimum = min(values)
                maximum = max(values)
                
                # Calculate standard deviation
                variance = sum((x - average) ** 2 for x in values) / count
                std_dev = variance ** 0.5
                
                return {
                    "count": count,
                    "sum": total,
                    "average": average,
                    "min": minimum,
                    "max": maximum,
                    "std_dev": std_dev
                }
            
            return await asyncio.to_thread(_get_field_stats)
        except Exception as e:
            print(f"Firestore field stats error: {e}")
            return {
                "count": 0,
                "sum": 0.0,
                "average": 0.0,
                "min": 0.0,
                "max": 0.0,
                "std_dev": 0.0
            }
    
    # ==================== SUBCOLLECTION OPERATIONS ====================
    
    async def get_subcollection(self, collection: str, document_id: str,
                              subcollection: str) -> List[Dict[str, Any]]:
        """Get documents from subcollection"""
        try:
            def _get_subcollection():
                docs = self.client.collection(collection)\
                    .document(document_id)\
                    .collection(subcollection)\
                    .stream()
                
                results = []
                for doc in docs:
                    data = doc.to_dict()
                    data["id"] = doc.id
                    results.append(data)
                
                return results
            
            return await asyncio.to_thread(_get_subcollection)
        except Exception as e:
            print(f"Firestore get subcollection error: {e}")
            return []
    
    async def create_in_subcollection(self, collection: str, document_id: str,
                                    subcollection: str, sub_doc_id: str,
                                    data: Dict[str, Any]) -> bool:
        """Create document in subcollection"""
        try:
            def _create_in_subcollection():
                doc_ref = self.client.collection(collection)\
                    .document(document_id)\
                    .collection(subcollection)\
                    .document(sub_doc_id)
                
                doc_ref.set(data)
                return True
            
            return await asyncio.to_thread(_create_in_subcollection)
        except Exception as e:
            print(f"Firestore create in subcollection error: {e}")
            return False
    
    # ==================== HEALTH CHECK ====================
    
    async def health_check(self) -> Dict[str, Any]:
        """Check Firestore health"""
        try:
            # Try to read a test document
            test_doc = await self.get_document("system", "health")
            
            return {
                "status": "healthy",
                "service": "firestore",
                "timestamp": datetime.utcnow().isoformat(),
                "details": {
                    "can_read": True,
                    "can_write": True,
                    "latency_ms": 0  # Would measure in production
                }
            }
            
        except Exception as e:
            return {
                "status": "unhealthy",
                "service": "firestore",
                "timestamp": datetime.utcnow().isoformat(),
                "error": str(e)
            }


# Global async Firestore client instance
async_firestore_client = AsyncFirestoreClient()