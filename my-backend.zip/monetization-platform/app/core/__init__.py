"""
Core functionality modules
"""

from app.core.auth import AuthService, auth_service
from app.core.rate_limiter import RateLimiter, rate_limiter
from app.core.cache import CacheManager, cache_manager, cached
from app.core.firebase_client import FirebaseClient, firebase_client
from app.core.firestore_client import AsyncFirestoreClient, async_firestore_client

__all__ = [
    "AuthService",
    "RateLimiter",
    "CacheManager",
    "FirebaseClient",
    "AsyncFirestoreClient",

    "auth_service",
    "rate_limiter",
    "cache_manager",
    "firebase_client",
    "async_firestore_client",

    "cached",
]
