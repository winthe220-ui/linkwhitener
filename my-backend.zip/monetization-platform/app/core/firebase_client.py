"""
Firebase client for authentication and other Firebase services
"""
import firebase_admin
from firebase_admin import auth, credentials, exceptions
from typing import Optional, Dict, Any, List
from datetime import datetime, timedelta
import json

from app.config import settings


class FirebaseClient:
    """Firebase client wrapper"""
    
    def __init__(self):
        self._app = None
        self._auth = None
    
    def init_app(self):
        """Initialize Firebase app"""
        try:
            if not firebase_admin._apps:
                if settings.firebase_private_key:
                    # Use credentials from environment variables
                    cred_dict = settings.firebase_credentials
                    cred = credentials.Certificate(cred_dict)
                else:
                    # Use default credentials (for GCP environments)
                    cred = credentials.ApplicationDefault()
                
                self._app = firebase_admin.initialize_app(
                    cred,
                    name='monetization-platform'
                )
                self._auth = auth
                
                print("✅ Firebase initialized successfully")
            else:
                self._app = firebase_admin.get_app()
                self._auth = auth
                
        except Exception as e:
            print(f"❌ Firebase initialization failed: {e}")
            raise
    
    @property
    def auth(self):
        if not self._auth:
            self.init_app()
        return self._auth
    
    # ==================== USER MANAGEMENT ====================
    
    async def create_user(self, phone: str, email: Optional[str] = None, 
                         password: Optional[str] = None) -> Dict[str, Any]:
        """Create user in Firebase Auth"""
        try:
            user_args = {"phone_number": phone}
            
            if email:
                user_args["email"] = email
            if password:
                user_args["password"] = password
            
            user = self.auth.create_user(**user_args)
            
            return {
                "uid": user.uid,
                "phone": user.phone_number,
                "email": user.email,
                "email_verified": user.email_verified,
                "disabled": user.disabled,
                "created_at": user.user_metadata.creation_timestamp if hasattr(user.user_metadata, 'creation_timestamp') else None,
                "last_login": user.user_metadata.last_sign_in_timestamp if hasattr(user.user_metadata, 'last_sign_in_timestamp') else None
            }
            
        except exceptions.FirebaseError as e:
            print(f"Firebase create user error: {e}")
            raise
    
    async def get_user(self, uid: str) -> Optional[Dict[str, Any]]:
        """Get user by UID"""
        try:
            user = self.auth.get_user(uid)
            
            return {
                "uid": user.uid,
                "phone": user.phone_number,
                "email": user.email,
                "email_verified": user.email_verified,
                "disabled": user.disabled,
                "created_at": user.user_metadata.creation_timestamp if hasattr(user.user_metadata, 'creation_timestamp') else None,
                "last_login": user.user_metadata.last_sign_in_timestamp if hasattr(user.user_metadata, 'last_sign_in_timestamp') else None,
                "providers": [p.provider_id for p in user.provider_data] if hasattr(user, 'provider_data') else []
            }
            
        except exceptions.FirebaseError as e:
            print(f"Firebase get user error: {e}")
            return None
    
    async def update_user(self, uid: str, **kwargs) -> Optional[Dict[str, Any]]:
        """Update user in Firebase Auth"""
        try:
            user = self.auth.update_user(uid, **kwargs)
            
            return {
                "uid": user.uid,
                "phone": user.phone_number,
                "email": user.email,
                "email_verified": user.email_verified,
                "disabled": user.disabled
            }
            
        except exceptions.FirebaseError as e:
            print(f"Firebase update user error: {e}")
            return None
    
    async def delete_user(self, uid: str) -> bool:
        """Delete user from Firebase Auth"""
        try:
            self.auth.delete_user(uid)
            return True
        except exceptions.FirebaseError as e:
            print(f"Firebase delete user error: {e}")
            return False
    
    async def list_users(self, limit: int = 1000, next_page_token: Optional[str] = None) -> Dict[str, Any]:
        """List users with pagination"""
        try:
            result = self.auth.list_users(
                max_results=limit,
                page_token=next_page_token
            )
            
            users = []
            for user in result.users:
                users.append({
                    "uid": user.uid,
                    "phone": user.phone_number,
                    "email": user.email,
                    "email_verified": user.email_verified,
                    "disabled": user.disabled,
                    "created_at": user.user_metadata.creation_timestamp if hasattr(user.user_metadata, 'creation_timestamp') else None
                })
            
            return {
                "users": users,
                "next_page_token": result.next_page_token,
                "has_next": result.next_page_token is not None
            }
            
        except exceptions.FirebaseError as e:
            print(f"Firebase list users error: {e}")
            return {"users": [], "next_page_token": None, "has_next": False}
    
    # ==================== TOKEN VERIFICATION ====================
    
    async def verify_id_token(self, id_token: str) -> Dict[str, Any]:
        """Verify Firebase ID token"""
        try:
            decoded_token = self.auth.verify_id_token(id_token)
            
            return {
                "uid": decoded_token["uid"],
                "phone": decoded_token.get("phone_number"),
                "email": decoded_token.get("email"),
                "email_verified": decoded_token.get("email_verified", False),
                "auth_time": decoded_token.get("auth_time"),
                "issued_at": decoded_token.get("iat"),
                "expires_at": decoded_token.get("exp"),
                "firebase": decoded_token.get("firebase", {}),
                "sign_in_provider": decoded_token.get("firebase", {}).get("sign_in_provider"),
                "claims": decoded_token.get("claims", {})
            }
            
        except exceptions.FirebaseError as e:
            print(f"Firebase verify token error: {e}")
            raise
    
    async def create_custom_token(self, uid: str, claims: Optional[Dict[str, Any]] = None) -> str:
        """Create custom token for user"""
        try:
            return self.auth.create_custom_token(uid, claims)
        except exceptions.FirebaseError as e:
            print(f"Firebase create custom token error: {e}")
            raise
    
    async def revoke_refresh_tokens(self, uid: str) -> bool:
        """Revoke all refresh tokens for a user"""
        try:
            self.auth.revoke_refresh_tokens(uid)
            return True
        except exceptions.FirebaseError as e:
            print(f"Firebase revoke tokens error: {e}")
            return False
    
    # ==================== PHONE AUTHENTICATION ====================
    
    async def send_phone_verification_code(self, phone_number: str) -> Dict[str, Any]:
        """
        Send phone verification code via Firebase
        Note: This requires Firebase Cloud Messaging setup for web
        For mobile apps, use Firebase SDK on client side
        """
        try:
            # This is a simplified version. In production, you'd use:
            # 1. Firebase Admin SDK for web
            # 2. Client SDK for mobile apps
            
            # For now, we'll simulate the response
            # In reality, you'd use:
            # session_info = self.auth.create_session_cookie(id_token, expires_in)
            
            return {
                "success": True,
                "message": "Verification code sent",
                "phone": phone_number,
                "session_info": "mock_session_info"  # Replace with actual session info
            }
            
        except Exception as e:
            print(f"Firebase send verification code error: {e}")
            raise
    
    async def verify_phone_code(self, phone_number: str, code: str, 
                               session_info: str) -> Dict[str, Any]:
        """
        Verify phone verification code
        Note: This requires proper Firebase setup
        """
        try:
            # This is a simplified version
            # In production, verify the code with Firebase
            
            return {
                "success": True,
                "message": "Phone verified successfully",
                "phone": phone_number,
                "id_token": "mock_id_token",  # Replace with actual ID token
                "refresh_token": "mock_refresh_token"  # Replace with actual refresh token
            }
            
        except Exception as e:
            print(f"Firebase verify phone code error: {e}")
            raise
    
    # ==================== CUSTOM CLAIMS ====================
    
    async def set_custom_user_claims(self, uid: str, claims: Dict[str, Any]) -> bool:
        """Set custom claims for a user"""
        try:
            self.auth.set_custom_user_claims(uid, claims)
            return True
        except exceptions.FirebaseError as e:
            print(f"Firebase set custom claims error: {e}")
            return False
    
    async def get_custom_user_claims(self, uid: str) -> Dict[str, Any]:
        """Get custom claims for a user"""
        try:
            user = self.auth.get_user(uid)
            return user.custom_claims or {}
        except exceptions.FirebaseError as e:
            print(f"Firebase get custom claims error: {e}")
            return {}
    
    # ==================== SESSION MANAGEMENT ====================
    
    async def create_session_cookie(self, id_token: str, expires_in: timedelta) -> str:
        """Create session cookie for web authentication"""
        try:
            return self.auth.create_session_cookie(id_token, expires_in=expires_in)
        except exceptions.FirebaseError as e:
            print(f"Firebase create session cookie error: {e}")
            raise
    
    async def verify_session_cookie(self, session_cookie: str) -> Dict[str, Any]:
        """Verify session cookie"""
        try:
            decoded_claims = self.auth.verify_session_cookie(session_cookie, check_revoked=True)
            return decoded_claims
        except exceptions.FirebaseError as e:
            print(f"Firebase verify session cookie error: {e}")
            raise
    
    # ==================== EMAIL/PASSWORD AUTH ====================
    
    async def get_user_by_email(self, email: str) -> Optional[Dict[str, Any]]:
        """Get user by email"""
        try:
            user = self.auth.get_user_by_email(email)
            
            return {
                "uid": user.uid,
                "phone": user.phone_number,
                "email": user.email,
                "email_verified": user.email_verified,
                "disabled": user.disabled
            }
            
        except exceptions.FirebaseError as e:
            print(f"Firebase get user by email error: {e}")
            return None
    
    async def update_user_email(self, uid: str, email: str) -> bool:
        """Update user email"""
        try:
            self.auth.update_user(uid, email=email, email_verified=False)
            return True
        except exceptions.FirebaseError as e:
            print(f"Firebase update user email error: {e}")
            return False
    
    async def send_email_verification(self, uid: str) -> bool:
        """Send email verification link"""
        try:
            # Note: Firebase Admin SDK doesn't have direct method for this
            # You need to use Firebase Client SDK or send custom email
            # This is a placeholder
            
            user = self.auth.get_user(uid)
            if not user.email:
                return False
            
            # In production, you'd send verification email via Firebase Auth
            # or your own email service with verification link
            
            return True
            
        except exceptions.FirebaseError as e:
            print(f"Firebase send email verification error: {e}")
            return False
    
    async def send_password_reset_email(self, email: str) -> bool:
        """Send password reset email"""
        try:
            # Note: Firebase Admin SDK doesn't have direct method for this
            # You need to use Firebase Client SDK or send custom email
            # This is a placeholder
            
            # In production, you'd send password reset email via Firebase Auth
            # or your own email service with reset link
            
            return True
            
        except exceptions.FirebaseError as e:
            print(f"Firebase send password reset email error: {e}")
            return False
    
    # ==================== BATCH OPERATIONS ====================
    
    async def batch_get_users(self, uids: List[str]) -> Dict[str, Any]:
        """Batch get users"""
        try:
            result = self.auth.get_users([auth.UidIdentifier(uid) for uid in uids])
            
            users = []
            not_found = []
            
            for user in result.users:
                users.append({
                    "uid": user.uid,
                    "phone": user.phone_number,
                    "email": user.email,
                    "email_verified": user.email_verified,
                    "disabled": user.disabled
                })
            
            for uid in result.not_found:
                not_found.append(uid.uid)
            
            return {
                "users": users,
                "not_found": not_found
            }
            
        except exceptions.FirebaseError as e:
            print(f"Firebase batch get users error: {e}")
            return {"users": [], "not_found": uids}
    
    async def batch_delete_users(self, uids: List[str]) -> Dict[str, Any]:
        """Batch delete users"""
        try:
            result = self.auth.delete_users(uids)
            
            return {
                "success_count": result.success_count,
                "failure_count": result.failure_count,
                "errors": [
                    {
                        "index": error.index,
                        "reason": error.reason
                    }
                    for error in result.errors
                ]
            }
            
        except exceptions.FirebaseError as e:
            print(f"Firebase batch delete users error: {e}")
            raise
    
    # ==================== UTILITY METHODS ====================
    
    async def generate_email_verification_link(self, email: str) -> Optional[str]:
        """Generate email verification link"""
        try:
            return self.auth.generate_email_verification_link(email)
        except exceptions.FirebaseError as e:
            print(f"Firebase generate email verification link error: {e}")
            return None
    
    async def generate_password_reset_link(self, email: str) -> Optional[str]:
        """Generate password reset link"""
        try:
            return self.auth.generate_password_reset_link(email)
        except exceptions.FirebaseError as e:
            print(f"Firebase generate password reset link error: {e}")
            return None
    
    async def generate_sign_in_with_email_link(self, email: str) -> Optional[str]:
        """Generate sign-in with email link"""
        try:
            return self.auth.generate_sign_in_with_email_link(email)
        except exceptions.FirebaseError as e:
            print(f"Firebase generate sign in link error: {e}")
            return None
    
    # ==================== HEALTH CHECK ====================
    
    async def health_check(self) -> Dict[str, Any]:
        """Check Firebase health"""
        try:
            # Try to list a small number of users as health check
            result = self.auth.list_users(max_results=1)
            
            return {
                "status": "healthy",
                "service": "firebase_auth",
                "timestamp": datetime.utcnow().isoformat(),
                "details": {
                    "total_users_estimated": "N/A",  # Firebase doesn't provide count
                    "can_list_users": True,
                    "can_create_user": True
                }
            }
            
        except exceptions.FirebaseError as e:
            return {
                "status": "unhealthy",
                "service": "firebase_auth",
                "timestamp": datetime.utcnow().isoformat(),
                "error": str(e)
            }


# Global Firebase client instance
firebase_client = FirebaseClient()