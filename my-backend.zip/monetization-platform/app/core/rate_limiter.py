import redis
from datetime import datetime, timedelta
from typing import Optional, Dict, Any
from fastapi import HTTPException, status, Request
import json
from app.config import settings


class RateLimiter:
    """Rate limiting service using Redis"""
    
    def __init__(self):
        self.redis = redis.from_url(settings.redis_url)
    
    async def check_rate_limit(
        self,
        identifier: str,
        limit: int,
        period: int = 60  # seconds
    ) -> Dict[str, Any]:
        """
        Check rate limit for an identifier
        
        Args:
            identifier: Unique identifier (IP, user ID, etc.)
            limit: Maximum number of requests
            period: Time period in seconds
        
        Returns:
            Dict with rate limit info
        """
        key = f"rate_limit:{identifier}"
        
        # Get current count
        current = self.redis.incr(key)
        
        if current == 1:
            # Set expiry on first request
            self.redis.expire(key, period)
        
        # Calculate reset time
        ttl = self.redis.ttl(key)
        if ttl == -1:
            ttl = period
        
        reset_time = datetime.utcnow() + timedelta(seconds=ttl)
        
        # Check if limit exceeded
        if current > limit:
            raise HTTPException(
                status_code=status.HTTP_429_TOO_MANY_REQUESTS,
                detail={
                    "error": "Rate limit exceeded",
                    "limit": limit,
                    "remaining": 0,
                    "reset": reset_time.isoformat(),
                    "retry_after": ttl
                },
                headers={
                    "X-RateLimit-Limit": str(limit),
                    "X-RateLimit-Remaining": "0",
                    "X-RateLimit-Reset": reset_time.isoformat(),
                    "Retry-After": str(ttl)
                }
            )
        
        return {
            "limit": limit,
            "remaining": limit - current,
            "reset": reset_time.isoformat(),
            "retry_after": ttl
        }
    
    async def check_user_rate_limit(
        self,
        user_uid: str,
        endpoint: str
    ) -> Dict[str, Any]:
        """Check rate limit for specific user endpoint"""
        identifier = f"user:{user_uid}:{endpoint}"
        
        # Different limits for different endpoints
        limits = {
            "create_link": 10,  # 10 links per minute
            "update_profile": 30,
            "request_withdrawal": 5,
            "verify_otp": 3,
            "default": 60
        }
        
        limit = limits.get(endpoint, limits["default"])
        return await self.check_rate_limit(identifier, limit)
    
    async def check_ip_rate_limit(
        self,
        ip_address: str,
        endpoint: str
    ) -> Dict[str, Any]:
        """Check rate limit for IP address"""
        identifier = f"ip:{ip_address}:{endpoint}"
        
        limits = {
            "login": 10,  # 10 login attempts per minute
            "register": 5,
            "verify_otp": 3,
            "create_link": 20,
            "track_page": 100,  # Higher for tracking
            "default": 60
        }
        
        limit = limits.get(endpoint, limits["default"])
        return await self.check_rate_limit(identifier, limit)
    
    async def check_global_rate_limit(self, endpoint: str) -> Dict[str, Any]:
        """Check global rate limit for endpoint"""
        identifier = f"global:{endpoint}"
        
        limits = {
            "admin_login": 100,
            "admin_create_user": 50,
            "send_otp": 1000,
            "default": 500
        }
        
        limit = limits.get(endpoint, limits["default"])
        return await self.check_rate_limit(identifier, limit)
    
    async def get_rate_limit_status(
        self,
        user_uid: Optional[str] = None,
        ip_address: Optional[str] = None
    ) -> Dict[str, Any]:
        """Get current rate limit status"""
        status = {}
        
        if user_uid:
            user_keys = self.redis.keys(f"rate_limit:user:{user_uid}:*")
            for key in user_keys:
                endpoint = key.decode().split(":")[-1]
                current = int(self.redis.get(key) or 0)
                ttl = self.redis.ttl(key)
                status[f"user_{endpoint}"] = {
                    "current": current,
                    "ttl": ttl
                }
        
        if ip_address:
            ip_keys = self.redis.keys(f"rate_limit:ip:{ip_address}:*")
            for key in ip_keys:
                endpoint = key.decode().split(":")[-1]
                current = int(self.redis.get(key) or 0)
                ttl = self.redis.ttl(key)
                status[f"ip_{endpoint}"] = {
                    "current": current,
                    "ttl": ttl
                }
        
        return status


# Middleware for rate limiting
class RateLimitMiddleware:
    def __init__(self, rate_limiter: RateLimiter):
        self.rate_limiter = rate_limiter
    
    async def __call__(self, request: Request, call_next):
        # Skip rate limiting for certain paths
        if request.url.path in ["/health", "/docs", "/openapi.json"]:
            return await call_next(request)
        
        client_ip = request.client.host
        
        try:
            # Global rate limit check
            endpoint = request.url.path.replace("/", "_").strip("_")
            await self.rate_limiter.check_global_rate_limit(endpoint)
            
            # IP-based rate limit
            await self.rate_limiter.check_ip_rate_limit(client_ip, endpoint)
            
            # User-based rate limit (if authenticated)
            if hasattr(request.state, "user"):
                user_uid = request.state.user.get("uid")
                if user_uid:
                    await self.rate_limiter.check_user_rate_limit(user_uid, endpoint)
        
        except HTTPException as e:
            # Add rate limit headers to all responses
            response = await call_next(request)
            for key, value in e.headers.items():
                if key.startswith("X-RateLimit-") or key == "Retry-After":
                    response.headers[key] = value
            return response
        
        return await call_next(request)


# Singleton instance
rate_limiter = RateLimiter()