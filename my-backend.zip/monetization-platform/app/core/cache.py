"""
Redis caching utilities with async support
"""
import json
import pickle
from typing import Optional, Any, Dict, List, Union
from datetime import timedelta
import asyncio
from functools import wraps

from app.database import redis_client
from app.config import settings


class CacheManager:
    """Cache manager for Redis operations"""
    
    def __init__(self):
        self.redis = redis_client
    
    async def get(self, key: str) -> Optional[Any]:
        """Get value from cache"""
        try:
            value = await self.redis.get(key)
            if value:
                return self._deserialize(value)
            return None
        except Exception as e:
            print(f"Cache get error: {e}")
            return None
    
    async def set(self, key: str, value: Any, ttl: Optional[int] = None) -> bool:
        """Set value in cache with optional TTL"""
        try:
            serialized = self._serialize(value)
            if ttl:
                return await self.redis.set(key, serialized, ex=ttl)
            else:
                return await self.redis.set(key, serialized)
        except Exception as e:
            print(f"Cache set error: {e}")
            return False
    
    async def delete(self, key: str) -> bool:
        """Delete key from cache"""
        try:
            return await self.redis.delete(key)
        except Exception as e:
            print(f"Cache delete error: {e}")
            return False
    
    async def exists(self, key: str) -> bool:
        """Check if key exists in cache"""
        try:
            return await self.redis.exists(key)
        except Exception as e:
            print(f"Cache exists error: {e}")
            return False
    
    async def increment(self, key: str, amount: int = 1) -> Optional[int]:
        """Increment integer value"""
        try:
            return await self.redis.incr(key, amount)
        except Exception as e:
            print(f"Cache increment error: {e}")
            return None
    
    async def decrement(self, key: str, amount: int = 1) -> Optional[int]:
        """Decrement integer value"""
        try:
            return await self.redis.decr(key, amount)
        except Exception as e:
            print(f"Cache decrement error: {e}")
            return None
    
    async def get_or_set(self, key: str, func, ttl: Optional[int] = None, *args, **kwargs) -> Any:
        """Get from cache or set using function"""
        cached = await self.get(key)
        if cached is not None:
            return cached
        
        value = await func(*args, **kwargs) if asyncio.iscoroutinefunction(func) else func(*args, **kwargs)
        await self.set(key, value, ttl)
        return value
    
    async def clear_pattern(self, pattern: str) -> int:
        """Clear keys matching pattern"""
        try:
            keys = []
            cursor = 0
            
            # Scan for keys matching pattern
            while True:
                cursor, found_keys = await asyncio.to_thread(
                    self.redis.client.scan,
                    cursor=cursor,
                    match=pattern,
                    count=1000
                )
                keys.extend(found_keys)
                if cursor == 0:
                    break
            
            # Delete keys
            if keys:
                await self.redis.client.delete(*keys)
            
            return len(keys)
        except Exception as e:
            print(f"Cache clear pattern error: {e}")
            return 0
    
    async def get_many(self, keys: List[str]) -> Dict[str, Any]:
        """Get multiple keys"""
        try:
            values = await asyncio.to_thread(self.redis.client.mget, keys)
            result = {}
            for key, value in zip(keys, values):
                if value:
                    result[key] = self._deserialize(value)
            return result
        except Exception as e:
            print(f"Cache get many error: {e}")
            return {}
    
    async def set_many(self, mapping: Dict[str, Any], ttl: Optional[int] = None) -> bool:
        """Set multiple keys"""
        try:
            pipeline = self.redis.client.pipeline()
            for key, value in mapping.items():
                serialized = self._serialize(value)
                if ttl:
                    pipeline.setex(key, ttl, serialized)
                else:
                    pipeline.set(key, serialized)
            await asyncio.to_thread(pipeline.execute)
            return True
        except Exception as e:
            print(f"Cache set many error: {e}")
            return False
    
    async def hset(self, key: str, field: str, value: Any) -> bool:
        """Set hash field"""
        try:
            serialized = self._serialize(value)
            return await self.redis.hset(key, field, serialized)
        except Exception as e:
            print(f"Cache hset error: {e}")
            return False
    
    async def hget(self, key: str, field: str) -> Optional[Any]:
        """Get hash field"""
        try:
            value = await self.redis.hget(key, field)
            if value:
                return self._deserialize(value)
            return None
        except Exception as e:
            print(f"Cache hget error: {e}")
            return None
    
    async def hgetall(self, key: str) -> Dict[str, Any]:
        """Get all hash fields"""
        try:
            values = await self.redis.hgetall(key)
            result = {}
            for field, value in values.items():
                result[field] = self._deserialize(value)
            return result
        except Exception as e:
            print(f"Cache hgetall error: {e}")
            return {}
    
    async def sadd(self, key: str, *members: Any) -> int:
        """Add members to set"""
        try:
            serialized_members = [self._serialize(m) for m in members]
            return await asyncio.to_thread(self.redis.client.sadd, key, *serialized_members)
        except Exception as e:
            print(f"Cache sadd error: {e}")
            return 0
    
    async def smembers(self, key: str) -> List[Any]:
        """Get set members"""
        try:
            members = await asyncio.to_thread(self.redis.client.smembers, key)
            return [self._deserialize(m) for m in members]
        except Exception as e:
            print(f"Cache smembers error: {e}")
            return []
    
    async def expire(self, key: str, ttl: int) -> bool:
        """Set expiry on key"""
        try:
            return await self.redis.expire(key, ttl)
        except Exception as e:
            print(f"Cache expire error: {e}")
            return False
    
    async def ttl(self, key: str) -> Optional[int]:
        """Get time to live for key"""
        try:
            return await self.redis.client.ttl(key)
        except Exception as e:
            print(f"Cache ttl error: {e}")
            return None
    
    def _serialize(self, value: Any) -> str:
        """Serialize value for Redis"""
        if isinstance(value, (str, int, float, bool)) or value is None:
            return json.dumps(value)
        return pickle.dumps(value)
    
    def _deserialize(self, value: str) -> Any:
        """Deserialize value from Redis"""
        try:
            return json.loads(value)
        except (json.JSONDecodeError, TypeError):
            try:
                return pickle.loads(value)
            except pickle.UnpicklingError:
                return value


def cached(ttl: Optional[int] = None, key_prefix: str = "cache"):
    """Decorator for caching function results"""
    def decorator(func):
        @wraps(func)
        async def wrapper(*args, **kwargs):
            cache_manager = CacheManager()
            
            # Generate cache key
            cache_key = f"{key_prefix}:{func.__module__}:{func.__name__}"
            if args:
                cache_key += f":{hash(str(args))}"
            if kwargs:
                cache_key += f":{hash(str(sorted(kwargs.items())))}"
            
            # Try to get from cache
            cached_result = await cache_manager.get(cache_key)
            if cached_result is not None:
                return cached_result
            
            # Execute function
            result = await func(*args, **kwargs) if asyncio.iscoroutinefunction(func) else func(*args, **kwargs)
            
            # Store in cache
            await cache_manager.set(cache_key, result, ttl)
            
            return result
        return wrapper
    return decorator


class CacheKeys:
    """Cache key patterns"""
    
    @staticmethod
    def user_profile(uid: str) -> str:
        return f"user:{uid}:profile"
    
    @staticmethod
    def user_earnings(uid: str) -> str:
        return f"user:{uid}:earnings"
    
    @staticmethod
    def user_links(uid: str, status: Optional[str] = None) -> str:
        key = f"user:{uid}:links"
        if status:
            key += f":{status}"
        return key
    
    @staticmethod
    def link_details(link_id: str) -> str:
        return f"link:{link_id}:details"
    
    @staticmethod
    def link_analytics(link_id: str, period: str) -> str:
        return f"link:{link_id}:analytics:{period}"
    
    @staticmethod
    def platform_stats() -> str:
        return "platform:stats"
    
    @staticmethod
    def admin_dashboard() -> str:
        return "admin:dashboard"
    
    @staticmethod
    def pending_withdrawals() -> str:
        return "withdrawals:pending"
    
    @staticmethod
    def website_pool() -> str:
        return "websites:pool"
    
    @staticmethod
    def blacklist() -> str:
        return "security:blacklist"


# Global cache instance
cache_manager = CacheManager()