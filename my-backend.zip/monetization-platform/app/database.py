"""
Firestore and Redis database clients
"""
import os
import json
from typing import Optional, Dict, Any
from google.cloud import firestore
from google.oauth2 import service_account
import redis
from redis.exceptions import RedisError
from contextlib import asynccontextmanager
import asyncio

from app.config import settings


class RedisClient:
    """Redis client wrapper with connection pooling"""
    
    def __init__(self):
        self._client: Optional[redis.Redis] = None
        self._pool = None
    
    def init_client(self):
        """Initialize Redis client"""
        try:
            connection_params = {
                "decode_responses": True,
                "socket_connect_timeout": 5,
                "socket_keepalive": True,
                "retry_on_timeout": True,
                "max_connections": 50
            }
            
            if settings.redis_password:
                connection_params["password"] = settings.redis_password
            
            if settings.redis_ssl:
                connection_params["ssl"] = True
                connection_params["ssl_cert_reqs"] = "none"
            
            self._client = redis.from_url(
                settings.redis_url,
                **connection_params
            )
            
            # Test connection
            self._client.ping()
            print("✅ Redis connected successfully")
            
        except RedisError as e:
            print(f"❌ Redis connection failed: {e}")
            raise
    
    @property
    def client(self) -> redis.Redis:
        if not self._client:
            self.init_client()
        return self._client
    
    async def get(self, key: str) -> Optional[str]:
        """Async get from Redis"""
        try:
            return await asyncio.to_thread(self.client.get, key)
        except RedisError:
            return None
    
    async def set(self, key: str, value: str, ex: Optional[int] = None) -> bool:
        """Async set in Redis"""
        try:
            return await asyncio.to_thread(self.client.set, key, value, ex=ex)
        except RedisError:
            return False
    
    async def delete(self, key: str) -> bool:
        """Async delete from Redis"""
        try:
            return await asyncio.to_thread(self.client.delete, key)
        except RedisError:
            return False
    
    async def incr(self, key: str) -> int:
        """Async increment in Redis"""
        try:
            return await asyncio.to_thread(self.client.incr, key)
        except RedisError:
            return 0
    
    async def expire(self, key: str, time: int) -> bool:
        """Async set expiry"""
        try:
            return await asyncio.to_thread(self.client.expire, key, time)
        except RedisError:
            return False
    
    async def exists(self, key: str) -> bool:
        """Async check if key exists"""
        try:
            return await asyncio.to_thread(self.client.exists, key)
        except RedisError:
            return False
    
    async def hset(self, key: str, mapping: Dict[str, Any]) -> bool:
        """Async hash set"""
        try:
            return await asyncio.to_thread(self.client.hset, key, mapping=mapping)
        except RedisError:
            return False
    
    async def hgetall(self, key: str) -> Dict[str, Any]:
        """Async get all hash fields"""
        try:
            return await asyncio.to_thread(self.client.hgetall, key)
        except RedisError:
            return {}
    
    def close(self):
        """Close Redis connection"""
        if self._client:
            self._client.close()
            self._client = None


class FirestoreClient:
    """Firestore client wrapper"""
    
    def __init__(self):
        self._client: Optional[firestore.Client] = None
        self._db: Optional[firestore.AsyncClient] = None
    
    def init_client(self):
        """Initialize Firestore client"""
        try:
            # Check for environment variable credentials
            if settings.firebase_private_key:
                # Use service account credentials from env
                creds_dict = settings.firebase_credentials
                credentials = service_account.Credentials.from_service_account_info(creds_dict)
            else:
                # Try to load from file
                if os.path.exists("firebase-service-account.json"):
                    credentials = service_account.Credentials.from_service_account_file(
                        "firebase-service-account.json"
                    )
                else:
                    # Use default credentials (for GCP environments)
                    credentials = None
            
            # Initialize Firestore client
            self._client = firestore.Client(
                project=settings.firestore_project_id,
                credentials=credentials,
                database=settings.firestore_database
            )
            
            print("✅ Firestore connected successfully")
            
        except Exception as e:
            print(f"❌ Firestore connection failed: {e}")
            raise
    
    @property
    def client(self) -> firestore.Client:
        if not self._client:
            self.init_client()
        return self._client
    
    # Synchronous operations
    def get_document(self, collection: str, document_id: str) -> Optional[Dict[str, Any]]:
        """Get document from Firestore"""
        try:
            doc_ref = self.client.collection(collection).document(document_id)
            doc = doc_ref.get()
            
            if doc.exists:
                data = doc.to_dict()
                data["id"] = doc.id
                return data
            return None
        except Exception as e:
            print(f"Error getting document: {e}")
            return None
    
    def create_document(self, collection: str, document_id: str, data: Dict[str, Any]) -> bool:
        """Create document in Firestore"""
        try:
            doc_ref = self.client.collection(collection).document(document_id)
            doc_ref.set(data)
            return True
        except Exception as e:
            print(f"Error creating document: {e}")
            return False
    
    def update_document(self, collection: str, document_id: str, data: Dict[str, Any]) -> bool:
        """Update document in Firestore"""
        try:
            doc_ref = self.client.collection(collection).document(document_id)
            doc_ref.update(data)
            return True
        except Exception as e:
            print(f"Error updating document: {e}")
            return False
    
    def delete_document(self, collection: str, document_id: str) -> bool:
        """Delete document from Firestore"""
        try:
            doc_ref = self.client.collection(collection).document(document_id)
            doc_ref.delete()
            return True
        except Exception as e:
            print(f"Error deleting document: {e}")
            return False
    
    def query_document(self, collection: str, field: str, op: str, value: Any, 
                      limit: int = 100) -> list:
        """Query documents in Firestore"""
        try:
            query = self.client.collection(collection)
            
            # Map operation
            if op == "==":
                query = query.where(field, "==", value)
            elif op == ">=":
                query = query.where(field, ">=", value)
            elif op == "<=":
                query = query.where(field, "<=", value)
            elif op == ">":
                query = query.where(field, ">", value)
            elif op == "<":
                query = query.where(field, "<", value)
            elif op == "in":
                query = query.where(field, "in", value)
            elif op == "array_contains":
                query = query.where(field, "array_contains", value)
            
            query = query.limit(limit)
            docs = query.stream()
            
            results = []
            for doc in docs:
                data = doc.to_dict()
                data["id"] = doc.id
                results.append(data)
            
            return results
        except Exception as e:
            print(f"Error querying documents: {e}")
            return []
    
    def batch_create(self, collection: str, documents: Dict[str, Dict[str, Any]]) -> bool:
        """Batch create documents"""
        try:
            batch = self.client.batch()
            
            for doc_id, data in documents.items():
                doc_ref = self.client.collection(collection).document(doc_id)
                batch.set(doc_ref, data)
            
            batch.commit()
            return True
        except Exception as e:
            print(f"Error batch creating: {e}")
            return False
    
    def transaction(self):
        """Get Firestore transaction"""
        return self.client.transaction()
    
    # Convenience operations for common use cases
    def increment_field(self, collection: str, document_id: str, field: str, amount: int = 1) -> bool:
        """Atomically increment a field"""
        try:
            import firestore
            doc_ref = self.client.collection(collection).document(document_id)
            doc_ref.update({field: firestore.Increment(amount)})
            return True
        except Exception as e:
            print(f"Error incrementing field: {e}")
            return False
    
    def add_to_array(self, collection: str, document_id: str, field: str, value: Any) -> bool:
        """Add value to array field"""
        try:
            import firestore
            doc_ref = self.client.collection(collection).document(document_id)
            doc_ref.update({field: firestore.ArrayUnion([value])})
            return True
        except Exception as e:
            print(f"Error adding to array: {e}")
            return False
    
    def remove_from_array(self, collection: str, document_id: str, field: str, value: Any) -> bool:
        """Remove value from array field"""
        try:
            import firestore
            doc_ref = self.client.collection(collection).document(document_id)
            doc_ref.update({field: firestore.ArrayRemove([value])})
            return True
        except Exception as e:
            print(f"Error removing from array: {e}")
            return False


# Global instances
redis_client = RedisClient()
firestore_client = FirestoreClient()


async def init_databases():
    """Initialize all database connections"""
    print("Initializing database connections...")
    
    # Initialize Redis
    redis_client.init_client()
    
    # Initialize Firestore
    firestore_client.init_client()
    
    print("✅ All database connections established")


async def close_databases():
    """Close all database connections"""
    print("Closing database connections...")
    redis_client.close()
    print("✅ Database connections closed")