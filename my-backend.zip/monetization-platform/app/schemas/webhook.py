"""
Webhook schemas for external service integrations
"""
from typing import Optional, List, Dict, Any
from datetime import datetime
from pydantic import BaseModel, Field, validator
import hmac
import hashlib


class WebhookBase(BaseModel):
    """Base webhook schema"""
    event_type: str
    event_id: str
    timestamp: datetime
    payload: Dict[str, Any]
    metadata: Optional[Dict[str, Any]] = None
    
    class Config:
        json_encoders = {
            datetime: lambda v: v.isoformat() if v else None
        }


class FirebaseWebhook(WebhookBase):
    """Firebase webhook schema"""
    
    @validator('event_type')
    def validate_event_type(cls, v):
        valid_events = [
            "user.created", "user.deleted", "user.email_verified",
            "user.disabled", "user.enabled", "user.signed_in",
            "auth.token_revoked", "auth.token_expired"
        ]
        if v not in valid_events:
            raise ValueError(f"Invalid Firebase event type: {v}")
        return v


class StripeWebhook(WebhookBase):
    """Stripe webhook schema"""
    signature: str
    
    @validator('event_type')
    def validate_event_type(cls, v):
        valid_events = [
            "payment_intent.succeeded", "payment_intent.payment_failed",
            "charge.succeeded", "charge.failed", "charge.refunded",
            "customer.created", "customer.updated", "customer.deleted",
            "subscription.created", "subscription.updated", "subscription.deleted"
        ]
        if v not in valid_events:
            raise ValueError(f"Invalid Stripe event type: {v}")
        return v
    
    def verify_signature(self, secret: str, payload: str) -> bool:
        """Verify Stripe webhook signature"""
        try:
            signature = self.signature
            expected_signature = hmac.new(
                secret.encode(),
                payload.encode(),
                hashlib.sha256
            ).hexdigest()
            return hmac.compare_digest(signature, expected_signature)
        except Exception:
            return False


class RazorpayWebhook(WebhookBase):
    """Razorpay webhook schema"""
    signature: str
    
    @validator('event_type')
    def validate_event_type(cls, v):
        valid_events = [
            "payment.captured", "payment.failed", "payment.dispute.created",
            "refund.created", "refund.processed", "subscription.activated",
            "subscription.cancelled", "subscription.completed",
            "subscription.charged", "subscription.pending"
        ]
        if v not in valid_events:
            raise ValueError(f"Invalid Razorpay event type: {v}")
        return v
    
    def verify_signature(self, secret: str, payload: str) -> bool:
        """Verify Razorpay webhook signature"""
        try:
            expected_signature = hashlib.sha256(
                (payload + secret).encode()
            ).hexdigest()
            return hmac.compare_digest(self.signature, expected_signature)
        except Exception:
            return False


class TwilioWebhook(WebhookBase):
    """Twilio webhook schema"""
    account_sid: str
    message_sid: Optional[str] = None
    from_number: Optional[str] = None
    to_number: Optional[str] = None
    body: Optional[str] = None
    status: Optional[str] = None
    
    @validator('event_type')
    def validate_event_type(cls, v):
        valid_events = [
            "message.received", "message.sent", "message.delivered",
            "message.failed", "call.initiated", "call.completed",
            "call.failed", "verification.started", "verification.approved",
            "verification.denied"
        ]
        if v not in valid_events:
            raise ValueError(f"Invalid Twilio event type: {v}")
        return v


class SendGridWebhook(WebhookBase):
    """SendGrid webhook schema"""
    
    @validator('event_type')
    def validate_event_type(cls, v):
        valid_events = [
            "delivered", "open", "click", "bounce", "dropped",
            "spam_report", "unsubscribe", "group_unsubscribe",
            "group_resubscribe", "processed", "deferred"
        ]
        if v not in valid_events:
            raise ValueError(f"Invalid SendGrid event type: {v}")
        return v


class WebhookConfig(BaseModel):
    """Webhook configuration"""
    url: str
    secret: Optional[str] = None
    events: List[str]
    enabled: bool = True
    retry_count: int = 3
    retry_delay: int = 60  # seconds
    timeout: int = 30  # seconds
    headers: Optional[Dict[str, str]] = None
    metadata: Optional[Dict[str, Any]] = None


class WebhookDelivery(BaseModel):
    """Webhook delivery attempt"""
    delivery_id: str
    webhook_id: str
    event_id: str
    url: str
    payload: Dict[str, Any]
    status: str  # pending, success, failed
    status_code: Optional[int] = None
    response_body: Optional[str] = None
    error_message: Optional[str] = None
    attempt_number: int = 1
    delivered_at: Optional[datetime] = None
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)
    
    class Config:
        json_encoders = {
            datetime: lambda v: v.isoformat() if v else None
        }


class WebhookStats(BaseModel):
    """Webhook statistics"""
    total_webhooks: int
    active_webhooks: int
    total_deliveries: int
    successful_deliveries: int
    failed_deliveries: int
    success_rate: float
    average_delivery_time_ms: float
    last_delivery_time: Optional[datetime]
    
    # By status
    deliveries_by_status: Dict[str, int]
    
    # By event type
    deliveries_by_event: Dict[str, int]
    
    # Recent failures
    recent_failures: List[Dict[str, Any]]
    
    class Config:
        json_encoders = {
            datetime: lambda v: v.isoformat() if v else None
        }