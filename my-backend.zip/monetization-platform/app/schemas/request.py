"""
Request schemas for API input validation
"""
from typing import Optional, List, Dict, Any
from datetime import datetime
from pydantic import BaseModel, Field, validator, HttpUrl, EmailStr
import re

from app.constants import ValidationPatterns, ErrorMessages


class PaginationParams(BaseModel):
    """Pagination parameters"""
    page: int = Field(1, ge=1, description="Page number")
    limit: int = Field(20, ge=1, le=100, description="Items per page")
    sort_by: Optional[str] = Field(None, description="Field to sort by")
    sort_order: Optional[str] = Field("desc", regex="^(asc|desc)$", description="Sort order")


class DateRangeParams(BaseModel):
    """Date range parameters"""
    start_date: Optional[datetime] = Field(None, description="Start date")
    end_date: Optional[datetime] = Field(None, description="End date")
    period: Optional[str] = Field(None, regex="^(today|yesterday|week|month|quarter|year)$", 
                                description="Predefined period")


# ==================== AUTH SCHEMAS ====================

class PhoneAuthRequest(BaseModel):
    """Phone authentication request"""
    phone: str = Field(..., description="Phone number with country code")
    
    @validator('phone')
    def validate_phone(cls, v):
        if not re.match(ValidationPatterns.PHONE_REGEX, v):
            raise ValueError(ErrorMessages.INVALID_PHONE)
        return v


class OTPVerifyRequest(BaseModel):
    """OTP verification request"""
    phone: str = Field(..., description="Phone number")
    otp: str = Field(..., min_length=6, max_length=6, description="6-digit OTP")
    session_id: Optional[str] = Field(None, description="Session ID")


class EmailAuthRequest(BaseModel):
    """Email authentication request"""
    email: EmailStr = Field(..., description="Email address")
    password: str = Field(..., min_length=8, max_length=128, description="Password")


class UserVerifyRequest(BaseModel):
    """User verification request"""
    id_token: str = Field(..., description="Firebase ID token")
    email: Optional[EmailStr] = Field(None, description="Email address")
    username: Optional[str] = Field(None, min_length=3, max_length=30, 
                                  regex=ValidationPatterns.USERNAME_REGEX,
                                  description="Username")
    
    @validator('username')
    def validate_username(cls, v):
        if v:
            reserved = ['admin', 'support', 'system', 'root', 'api']
            if v.lower() in reserved:
                raise ValueError("Username is reserved")
        return v


class AdminLoginRequest(BaseModel):
    """Admin login request"""
    email: EmailStr = Field(..., description="Admin email")
    password: str = Field(..., min_length=8, max_length=128, description="Password")
    otp: Optional[str] = Field(None, description="2FA OTP (if enabled)")


class PasswordResetRequest(BaseModel):
    """Password reset request"""
    email: EmailStr = Field(..., description="Email address")
    reset_token: str = Field(..., description="Password reset token")
    new_password: str = Field(..., min_length=8, max_length=128, description="New password")
    confirm_password: str = Field(..., description="Confirm new password")
    
    @validator('confirm_password')
    def passwords_match(cls, v, values):
        if 'new_password' in values and v != values['new_password']:
            raise ValueError("Passwords do not match")
        return v


class TwoFactorEnableRequest(BaseModel):
    """Two-factor authentication enable request"""
    method: str = Field(..., regex="^(authenticator|sms|email)$", description="2FA method")
    phone: Optional[str] = Field(None, description="Phone number for SMS 2FA")
    
    @validator('phone')
    def validate_phone_if_sms(cls, v, values):
        if values.get('method') == 'sms' and not v:
            raise ValueError("Phone number is required for SMS 2FA")
        if v and not re.match(ValidationPatterns.PHONE_REGEX, v):
            raise ValueError(ErrorMessages.INVALID_PHONE)
        return v


# ==================== USER SCHEMAS ====================

class UserProfileUpdate(BaseModel):
    """User profile update request"""
    username: Optional[str] = Field(None, min_length=3, max_length=30,
                                  regex=ValidationPatterns.USERNAME_REGEX)
    full_name: Optional[str] = Field(None, max_length=100)
    avatar_url: Optional[str] = Field(None, max_length=500)
    bio: Optional[str] = Field(None, max_length=500)
    date_of_birth: Optional[datetime] = Field(None)
    gender: Optional[str] = Field(None, regex="^(male|female|other)$")
    language: Optional[str] = Field(None, max_length=10)
    timezone: Optional[str] = Field(None, max_length=50)


class UserPreferencesUpdate(BaseModel):
    """User preferences update request"""
    payout_preferences: Optional[Dict[str, Any]] = Field(None)
    notification_preferences: Optional[Dict[str, bool]] = Field(None)


class KYCSubmitRequest(BaseModel):
    """KYC submission request"""
    document_type: str = Field(..., regex="^(aadhaar|pan|passport|driving_license)$")
    document_number: str = Field(..., min_length=1, max_length=50)
    document_front_url: str = Field(..., max_length=500)
    document_back_url: Optional[str] = Field(None, max_length=500)
    selfie_url: str = Field(..., max_length=500)
    
    @validator('document_number')
    def validate_document_number(cls, v, values):
        doc_type = values.get('document_type')
        
        if doc_type == 'aadhaar':
            if not re.match(ValidationPatterns.AADHAAR_REGEX, v):
                raise ValueError("Invalid Aadhaar number")
        elif doc_type == 'pan':
            if not re.match(ValidationPatterns.PAN_REGEX, v):
                raise ValueError("Invalid PAN number")
        
        return v


class DeviceRegisterRequest(BaseModel):
    """Device registration request"""
    device_id: str = Field(..., max_length=100)
    platform: str = Field(..., regex="^(android|ios|web)$")
    model: Optional[str] = Field(None, max_length=50)
    os_version: Optional[str] = Field(None, max_length=20)
    app_version: Optional[str] = Field(None, max_length=20)
    push_token: Optional[str] = Field(None, max_length=500)


# ==================== LINK SCHEMAS ====================

class LinkCreateRequest(BaseModel):
    """Link creation request"""
    url: HttpUrl = Field(..., description="Original URL")
    title: Optional[str] = Field(None, max_length=200, description="Link title")
    description: Optional[str] = Field(None, max_length=500, description="Link description")
    tags: Optional[List[str]] = Field(None, description="Link tags")
    custom_code: Optional[str] = Field(None, min_length=4, max_length=12,
                                     regex=ValidationPatterns.SHORT_CODE_REGEX,
                                     description="Custom short code")
    
    # UTM parameters
    utm_source: Optional[str] = Field(None, max_length=100)
    utm_medium: Optional[str] = Field(None, max_length=100)
    utm_campaign: Optional[str] = Field(None, max_length=100)
    utm_content: Optional[str] = Field(None, max_length=100)
    utm_term: Optional[str] = Field(None, max_length=100)
    
    # Security
    password: Optional[str] = Field(None, min_length=4, max_length=50)
    expiration_date: Optional[datetime] = Field(None)
    max_clicks: Optional[int] = Field(None, ge=1, le=1000000)
    
    @validator('custom_code')
    def validate_custom_code(cls, v):
        if v:
            reserved = ['admin', 'support', 'api', 'dashboard', 'login', 'register']
            if v.lower() in reserved:
                raise ValueError("Custom code is reserved")
        return v


class LinkUpdateRequest(BaseModel):
    """Link update request"""
    title: Optional[str] = Field(None, max_length=200)
    description: Optional[str] = Field(None, max_length=500)
    tags: Optional[List[str]] = Field(None)
    status: Optional[str] = Field(None, regex="^(active|paused|disabled)$")
    
    # UTM parameters
    utm_source: Optional[str] = Field(None, max_length=100)
    utm_medium: Optional[str] = Field(None, max_length=100)
    utm_campaign: Optional[str] = Field(None, max_length=100)
    utm_content: Optional[str] = Field(None, max_length=100)
    utm_term: Optional[str] = Field(None, max_length=100)
    
    # Security
    password: Optional[str] = Field(None, min_length=4, max_length=50)
    expiration_date: Optional[datetime] = Field(None)
    max_clicks: Optional[int] = Field(None, ge=1, le=1000000)


class LinkPasswordRequest(BaseModel):
    """Link password verification request"""
    password: str = Field(..., min_length=1, max_length=50)


class LinkAnalyticsQuery(BaseModel):
    """Link analytics query parameters"""
    period: str = Field("7d", regex="^(1d|7d|30d|90d|180d|365d|all)$")
    group_by: Optional[str] = Field(None, regex="^(hour|day|week|month)$")
    metrics: Optional[List[str]] = Field(None)


class BulkLinkCreateRequest(BaseModel):
    """Bulk link creation request"""
    links: List[Dict[str, Any]] = Field(..., max_items=100)
    metadata: Optional[Dict[str, Any]] = Field(None)


# ==================== EARNINGS SCHEMAS ====================

class EarningsQueryParams(BaseModel):
    """Earnings query parameters"""
    start_date: Optional[datetime] = Field(None)
    end_date: Optional[datetime] = Field(None)
    type: Optional[str] = Field(None, regex="^(page_view|referral|bonus|adjustment|all)$")
    link_id: Optional[str] = Field(None)
    page: int = Field(1, ge=1)
    limit: int = Field(50, ge=1, le=100)


class EarningsAdjustmentRequest(BaseModel):
    """Earnings adjustment request (admin only)"""
    user_uid: str = Field(..., description="User UID")
    amount: float = Field(..., gt=0, description="Adjustment amount")
    type: str = Field(..., regex="^(add|deduct|set)$", description="Adjustment type")
    reason: str = Field(..., max_length=500, description="Adjustment reason")
    description: Optional[str] = Field(None, max_length=1000, description="Detailed description")
    reference_id: Optional[str] = Field(None, max_length=100, description="External reference")
    
    @validator('amount')
    def validate_amount(cls, v, values):
        if values.get('type') == 'deduct' and v <= 0:
            raise ValueError("Deduction amount must be positive")
        return v


# ==================== WITHDRAWAL SCHEMAS ====================

class WithdrawalRequest(BaseModel):
    """Withdrawal request"""
    amount: float = Field(..., gt=0, description="Withdrawal amount")
    method: str = Field(..., regex="^(upi|bank_transfer|paytm|phonepe|google_pay)$")
    payment_details: Dict[str, Any] = Field(..., description="Payment details")
    
    @validator('amount')
    def validate_amount(cls, v):
        from app.config import settings
        if v < settings.min_withdrawal_amount:
            raise ValueError(f"Minimum withdrawal amount is {settings.min_withdrawal_amount}")
        if v > settings.max_withdrawal_amount:
            raise ValueError(f"Maximum withdrawal amount is {settings.max_withdrawal_amount}")
        return v
    
    @validator('payment_details')
    def validate_payment_details(cls, v, values):
        method = values.get('method')
        
        if method == 'upi':
            if 'upi_id' not in v:
                raise ValueError("UPI ID is required")
            if not re.match(ValidationPatterns.UPI_ID_REGEX, v['upi_id']):
                raise ValueError("Invalid UPI ID format")
        
        elif method == 'bank_transfer':
            required = ['account_holder', 'account_number', 'ifsc_code', 'bank_name']
            missing = [field for field in required if field not in v]
            if missing:
                raise ValueError(f"Missing fields: {missing}")
            
            if 'ifsc_code' in v and not re.match(ValidationPatterns.IFSC_CODE_REGEX, v['ifsc_code']):
                raise ValueError("Invalid IFSC code format")
        
        return v


class WithdrawalActionRequest(BaseModel):
    """Withdrawal action request (admin)"""
    notes: Optional[str] = Field(None, max_length=1000, description="Action notes")
    reference_id: Optional[str] = Field(None, max_length=100, description="External reference")


class BulkWithdrawalActionRequest(BaseModel):
    """Bulk withdrawal action request"""
    withdrawal_ids: List[str] = Field(..., min_items=1, max_items=100)
    action: str = Field(..., regex="^(approve|reject|cancel)$")
    notes: Optional[str] = Field(None, max_length=1000)


# ==================== ADMIN SCHEMAS ====================

class AdminCreateRequest(BaseModel):
    """Admin creation request"""
    email: EmailStr = Field(..., description="Admin email")
    password: str = Field(..., min_length=8, max_length=128, description="Password")
    full_name: str = Field(..., max_length=100, description="Full name")
    role: str = Field("admin", regex="^(super_admin|admin|support|moderator|analyst)$")
    permissions: Optional[List[str]] = Field(None, description="Permissions list")
    department: Optional[str] = Field(None, max_length=100)
    position: Optional[str] = Field(None, max_length=100)
    phone: Optional[str] = Field(None)
    
    @validator('phone')
    def validate_phone(cls, v):
        if v and not re.match(ValidationPatterns.PHONE_REGEX, v):
            raise ValueError(ErrorMessages.INVALID_PHONE)
        return v


class AdminUpdateRequest(BaseModel):
    """Admin update request"""
    full_name: Optional[str] = Field(None, max_length=100)
    role: Optional[str] = Field(None, regex="^(super_admin|admin|support|moderator|analyst)$")
    permissions: Optional[List[str]] = Field(None)
    department: Optional[str] = Field(None, max_length=100)
    position: Optional[str] = Field(None, max_length=100)
    phone: Optional[str] = Field(None)
    status: Optional[str] = Field(None, regex="^(active|inactive|suspended)$")
    
    @validator('phone')
    def validate_phone(cls, v):
        if v and not re.match(ValidationPatterns.PHONE_REGEX, v):
            raise ValueError(ErrorMessages.INVALID_PHONE)
        return v


class AdminInviteRequest(BaseModel):
    """Admin invitation request"""
    email: EmailStr = Field(..., description="Invitee email")
    role: str = Field("admin", regex="^(super_admin|admin|support|moderator|analyst)$")
    permissions: Optional[List[str]] = Field(None)
    notes: Optional[str] = Field(None, max_length=500)


class AdminPasswordChangeRequest(BaseModel):
    """Admin password change request"""
    current_password: str = Field(..., min_length=8, max_length=128)
    new_password: str = Field(..., min_length=8, max_length=128)
    confirm_password: str = Field(..., min_length=8, max_length=128)
    
    @validator('confirm_password')
    def passwords_match(cls, v, values):
        if 'new_password' in values and v != values['new_password']:
            raise ValueError("Passwords do not match")
        return v


# ==================== SETTINGS SCHEMAS ====================

class PlatformSettingsUpdate(BaseModel):
    """Platform settings update request"""
    min_withdrawal_amount: Optional[float] = Field(None, gt=0)
    max_withdrawal_amount: Optional[float] = Field(None, gt=0)
    payout_rate_per_view: Optional[float] = Field(None, gt=0)
    withdrawal_cooldown_hours: Optional[int] = Field(None, ge=1)
    max_links_per_user: Optional[int] = Field(None, ge=1)
    daily_link_limit: Optional[int] = Field(None, ge=1)
    referral_bonus: Optional[float] = Field(None, ge=0)
    kyc_required_amount: Optional[float] = Field(None, ge=0)
    
    # Fraud detection
    fraud_min_page_time: Optional[int] = Field(None, ge=1)
    fraud_max_clicks_per_ip: Optional[int] = Field(None, ge=1)
    fraud_score_threshold: Optional[float] = Field(None, ge=0, le=100)
    fraud_auto_block: Optional[bool] = Field(None)
    
    # Security
    user_token_expire_days: Optional[int] = Field(None, ge=1)
    admin_token_expire_hours: Optional[int] = Field(None, ge=1)
    rate_limit_per_minute: Optional[int] = Field(None, ge=1)
    max_login_attempts: Optional[int] = Field(None, ge=1)
    login_block_minutes: Optional[int] = Field(None, ge=1)
    
    # Maintenance
    maintenance_mode: Optional[bool] = Field(None)
    maintenance_message: Optional[str] = Field(None, max_length=1000)
    
    # Email/SMS settings
    email_enabled: Optional[bool] = Field(None)
    sms_enabled: Optional[bool] = Field(None)
    email_from: Optional[str] = Field(None, max_length=100)
    
    @validator('max_withdrawal_amount')
    def validate_max_withdrawal(cls, v, values):
        if 'min_withdrawal_amount' in values and v is not None:
            min_amount = values['min_withdrawal_amount']
            if min_amount is not None and v < min_amount:
                raise ValueError("Maximum withdrawal amount must be greater than minimum")
        return v


class WebsiteAddRequest(BaseModel):
    """Website add to pool request"""
    domain: str = Field(..., max_length=255)
    category: Optional[str] = Field(None, max_length=100)
    is_active: bool = Field(True)
    metadata: Optional[Dict[str, Any]] = Field(None)
    
    @validator('domain')
    def validate_domain(cls, v):
        import re
        domain_pattern = r'^(?:[a-zA-Z0-9](?:[a-zA-Z0-9\-]{0,61}[a-zA-Z0-9])?\.)+[a-zA-Z]{2,}$'
        if not re.match(domain_pattern, v):
            raise ValueError("Invalid domain format")
        return v


class BlacklistAddRequest(BaseModel):
    """Blacklist add request"""
    value: str = Field(..., max_length=500)
    type: str = Field(..., regex="^(url|domain|ip|email|phone)$")
    reason: Optional[str] = Field(None, max_length=500)
    expires_at: Optional[datetime] = Field(None)


# ==================== AUDIT SCHEMAS ====================

class AuditQueryRequest(BaseModel):
    """Audit log query request"""
    actor_type: Optional[str] = Field(None, regex="^(user|admin|system)$")
    actor_id: Optional[str] = Field(None)
    action: Optional[str] = Field(None)
    resource: Optional[str] = Field(None)
    resource_id: Optional[str] = Field(None)
    severity: Optional[str] = Field(None, regex="^(debug|info|warning|error|critical)$")
    status: Optional[str] = Field(None, regex="^(success|failed|partial)$")
    start_date: Optional[datetime] = Field(None)
    end_date: Optional[datetime] = Field(None)
    search_text: Optional[str] = Field(None)
    tags: Optional[List[str]] = Field(None)
    compliance_tags: Optional[List[str]] = Field(None)
    page: int = Field(1, ge=1)
    limit: int = Field(50, ge=1, le=1000)
    sort_by: str = Field("timestamp")
    sort_order: str = Field("desc", regex="^(asc|desc)$")


class AuditExportRequest(BaseModel):
    """Audit export request"""
    format: str = Field("json", regex="^(json|csv|excel)$")
    include_fields: Optional[List[str]] = Field(None)
    filters: Optional[AuditQueryRequest] = Field(None)
    compress: bool = Field(False)
    password_protect: bool = Field(False)
    password: Optional[str] = Field(None, min_length=8)


# ==================== FRAUD DETECTION SCHEMAS ====================

class FraudCheckRequest(BaseModel):
    """Fraud check request"""
    session_id: str
    link_id: str
    page_num: int = Field(..., ge=1, le=3)
    timestamp: datetime
    ip_address: str
    user_agent: str
    referrer: Optional[str] = Field(None)
    device_fingerprint: Optional[str] = Field(None)


class FraudOverrideRequest(BaseModel):
    """Fraud override request (admin)"""
    session_id: str
    override_reason: str = Field(..., max_length=500)
    notes: Optional[str] = Field(None, max_length=1000)


class FraudRuleCreateRequest(BaseModel):
    """Fraud rule creation request"""
    name: str = Field(..., max_length=100)
    description: Optional[str] = Field(None, max_length=500)
    conditions: List[Dict[str, Any]] = Field(..., min_items=1)
    action: str = Field(..., regex="^(block|flag|notify|review)$")
    severity: str = Field("medium", regex="^(low|medium|high|critical)$")
    is_active: bool = Field(True)


# ==================== SYSTEM SCHEMAS ====================

class SystemCleanupRequest(BaseModel):
    """System cleanup request"""
    cleanup_type: str = Field(..., regex="^(sessions|links|logs|users|all)$")
    older_than_days: int = Field(30, ge=1, le=3650)
    dry_run: bool = Field(True, description="Preview cleanup without executing")
    limit: Optional[int] = Field(None, ge=1, le=10000)


class SystemBackupRequest(BaseModel):
    """System backup request"""
    backup_type: str = Field("full", regex="^(full|incremental|differential)$")
    collections: Optional[List[str]] = Field(None)
    compress: bool = Field(True)
    encrypt: bool = Field(True)
    password: Optional[str] = Field(None, min_length=8)


class SystemRestoreRequest(BaseModel):
    """System restore request"""
    backup_id: str
    collections: Optional[List[str]] = Field(None)
    password: Optional[str] = Field(None, min_length=8)
    confirm: bool = Field(False, description="Confirm restoration")


class HealthCheckRequest(BaseModel):
    """Health check request"""
    detailed: bool = Field(False, description="Include detailed service checks")
    services: Optional[List[str]] = Field(None, description="Specific services to check")


class MetricsQueryRequest(BaseModel):
    """Metrics query request"""
    metric_name: str
    start_time: datetime
    end_time: datetime = Field(default_factory=datetime.utcnow)
    step: str = Field("1m", regex="^(1m|5m|15m|1h|6h|1d)$")
    filters: Optional[Dict[str, str]] = Field(None)