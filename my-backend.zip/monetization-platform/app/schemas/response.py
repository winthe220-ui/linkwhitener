"""
Response schemas for API output
"""
from typing import Optional, List, Dict, Any, Generic, TypeVar
from datetime import datetime
from pydantic import BaseModel, Field
from pydantic.generics import GenericModel

from app.models.user import UserStatus, UserTier
from app.models.link import LinkStatus, LinkType
from app.models.earnings import TransactionType, TransactionStatus
from app.models.withdrawal import WithdrawalStatus, WithdrawalMethod
from app.models.admin import AdminRole, AdminStatus
from app.models.audit import AuditAction, AuditResource, AuditSeverity


T = TypeVar('T')


class PaginatedResponse(GenericModel, Generic[T]):
    """Paginated response wrapper"""
    data: List[T]
    page: int
    limit: int
    total: int
    has_next: bool
    has_previous: bool
    total_pages: int


class SuccessResponse(BaseModel):
    """Generic success response"""
    success: bool = True
    message: str
    data: Optional[Dict[str, Any]] = None
    timestamp: datetime = Field(default_factory=datetime.utcnow)


class ErrorResponse(BaseModel):
    """Error response"""
    success: bool = False
    error: str
    code: Optional[str] = None
    details: Optional[Dict[str, Any]] = None
    timestamp: datetime = Field(default_factory=datetime.utcnow)


class ValidationErrorResponse(BaseModel):
    """Validation error response"""
    success: bool = False
    error: str = "Validation Error"
    details: List[Dict[str, Any]]
    timestamp: datetime = Field(default_factory=datetime.utcnow)


# ==================== AUTH RESPONSES ====================

class UserAuthResponse(BaseModel):
    """User authentication response"""
    uid: str
    username: Optional[str]
    phone: str
    email: Optional[str]
    status: UserStatus
    is_new_user: bool
    access_token: str
    refresh_token: str
    token_type: str = "bearer"
    expires_in: int  # seconds
    expires_at: Optional[datetime] = None
    created_at: Optional[datetime] = None
    last_login: Optional[datetime] = None


class AdminAuthResponse(BaseModel):
    """Admin authentication response"""
    admin_id: str
    email: str
    role: AdminRole
    permissions: List[str]
    name: str
    access_token: str
    token_type: str = "bearer"
    expires_in: int  # seconds
    expires_at: datetime
    last_login: Optional[datetime] = None
    two_factor_required: bool = False


class OTPResponse(BaseModel):
    """OTP response"""
    session_id: str
    expires_in: int  # seconds
    message: str
    retry_after: Optional[int] = None  # seconds


class TokenRefreshResponse(BaseModel):
    """Token refresh response"""
    access_token: str
    refresh_token: str
    token_type: str = "bearer"
    expires_in: int  # seconds
    expires_at: datetime


# ==================== USER RESPONSES ====================

class UserProfileResponse(BaseModel):
    """User profile response"""
    uid: str
    username: Optional[str]
    phone: str
    email: Optional[str]
    full_name: Optional[str]
    avatar_url: Optional[str]
    status: UserStatus
    tier: UserTier
    created_at: datetime
    last_login: Optional[datetime]
    last_active: Optional[datetime]
    
    # Stats
    total_links: int
    active_links: int
    total_clicks: int
    valid_page3_views: int
    conversion_rate: float
    
    # Earnings
    total_earned: float
    available_balance: float
    pending_withdrawal: float
    withdrawn_amount: float
    referral_earnings: float
    bonus_earnings: float
    
    # KYC
    is_kyc_verified: bool
    kyc_status: Optional[str]
    
    # Referral
    referral_code: Optional[str]
    referral_count: int
    
    # Preferences
    payout_preferences: Dict[str, Any]
    notification_preferences: Dict[str, bool]
    
    class Config:
        json_encoders = {
            datetime: lambda v: v.isoformat() if v else None
        }


class UserStatusResponse(BaseModel):
    """User status response"""
    uid: str
    status: UserStatus
    suspended_until: Optional[datetime]
    suspension_reason: Optional[str]
    flagged: bool
    flag_reason: Optional[str]
    is_kyc_verified: bool
    kyc_required: bool
    kyc_status: Optional[str]
    can_withdraw: bool
    withdrawal_block_reason: Optional[str]
    
    class Config:
        json_encoders = {
            datetime: lambda v: v.isoformat() if v else None
        }


class UserKYCResponse(BaseModel):
    """User KYC response"""
    status: str
    document_type: Optional[str]
    submitted_at: Optional[datetime]
    verified_at: Optional[datetime]
    verified_by: Optional[str]
    rejection_reason: Optional[str]
    next_submission_after: Optional[datetime]
    
    class Config:
        json_encoders = {
            datetime: lambda v: v.isoformat() if v else None
        }


class ReferralInfoResponse(BaseModel):
    """Referral information response"""
    referral_code: str
    referral_url: str
    referral_count: int
    total_referral_earnings: float
    pending_referral_earnings: float
    referral_commission_rate: float
    referral_stats: Dict[str, Any]
    top_referrals: List[Dict[str, Any]]
    
    class Config:
        json_encoders = {
            datetime: lambda v: v.isoformat() if v else None
        }


# ==================== LINK RESPONSES ====================

class LinkResponse(BaseModel):
    """Link response"""
    link_id: str
    short_code: str
    short_url: str
    original_url: str
    title: Optional[str]
    description: Optional[str]
    status: LinkStatus
    link_type: LinkType
    created_at: datetime
    updated_at: datetime
    expires_at: Optional[datetime]
    
    # Stats
    total_clicks: int
    unique_clicks: int
    page1_views: int
    page2_views: int
    page3_views: int
    conversion_rate: float
    earnings_total: float
    earnings_today: float
    earnings_this_month: float
    
    # Security
    has_password: bool
    is_expired: bool
    max_clicks_reached: bool
    
    # Metadata
    tags: List[str]
    qr_code_url: Optional[str]
    analytics_url: str
    
    class Config:
        json_encoders = {
            datetime: lambda v: v.isoformat() if v else None
        }


class LinkAnalyticsResponse(BaseModel):
    """Link analytics response"""
    link_id: str
    period: str
    total_clicks: int
    unique_clicks: int
    page1_views: int
    page2_views: int
    page3_views: int
    conversion_rate: float
    earnings_total: float
    
    # Time series data
    clicks_by_day: List[Dict[str, Any]]
    views_by_page: Dict[str, int]
    earnings_by_day: List[Dict[str, Any]]
    
    # Geographic data
    clicks_by_country: List[Dict[str, Any]]
    clicks_by_city: List[Dict[str, Any]]
    
    # Device data
    clicks_by_device: Dict[str, int]
    clicks_by_browser: Dict[str, int]
    clicks_by_os: Dict[str, int]
    
    # Referrer data
    top_referrers: List[Dict[str, Any]]
    referrer_types: Dict[str, int]
    
    # Performance metrics
    average_page_time: Dict[str, float]  # seconds per page
    bounce_rate: float
    click_through_rate: float
    
    class Config:
        json_encoders = {
            datetime: lambda v: v.isoformat() if v else None
        }


class BulkLinkCreateResponse(BaseModel):
    """Bulk link creation response"""
    success_count: int
    failed_count: int
    total_count: int
    created_links: List[LinkResponse]
    failed_links: List[Dict[str, Any]]
    batch_id: Optional[str]


# ==================== EARNINGS RESPONSES ====================

class EarningsSummaryResponse(BaseModel):
    """Earnings summary response"""
    total_earned: float
    available_balance: float
    pending_withdrawal: float
    withdrawn_amount: float
    referral_earnings: float
    bonus_earnings: float
    
    # Time-based earnings
    today_earnings: float
    yesterday_earnings: float
    this_week_earnings: float
    this_month_earnings: float
    last_month_earnings: float
    
    # Projections
    estimated_daily: float
    estimated_weekly: float
    estimated_monthly: float
    
    # Stats
    valid_page3_views: int
    conversion_rate: float
    average_earnings_per_view: float
    
    # Limits
    min_withdrawal_amount: float
    max_withdrawal_amount: float
    withdrawal_cooldown_hours: int
    kyc_required_amount: float
    
    class Config:
        json_encoders = {
            datetime: lambda v: v.isoformat() if v else None
        }


class EarningsTransactionResponse(BaseModel):
    """Earnings transaction response"""
    transaction_id: str
    user_uid: str
    link_id: Optional[str]
    amount: float
    type: TransactionType
    status: TransactionStatus
    description: str
    created_at: datetime
    processed_at: Optional[datetime]
    metadata: Dict[str, Any]
    balance_before: Optional[float]
    balance_after: Optional[float]
    
    class Config:
        json_encoders = {
            datetime: lambda v: v.isoformat() if v else None
        }


class EarningsByLinkResponse(BaseModel):
    """Earnings breakdown by link"""
    link_id: str
    title: Optional[str]
    short_url: str
    total_clicks: int
    page3_views: int
    earnings_total: float
    earnings_today: float
    earnings_this_week: float
    earnings_this_month: float
    conversion_rate: float
    created_at: datetime
    
    class Config:
        json_encoders = {
            datetime: lambda v: v.isoformat() if v else None
        }


class ReferralEarningsResponse(BaseModel):
    """Referral earnings response"""
    total_referral_earnings: float
    pending_referral_earnings: float
    withdrawn_referral_earnings: float
    referral_count: int
    active_referrals: int
    referral_commission_rate: float
    referral_transactions: List[EarningsTransactionResponse]
    referral_stats: Dict[str, Any]
    
    class Config:
        json_encoders = {
            datetime: lambda v: v.isoformat() if v else None
        }


# ==================== WITHDRAWAL RESPONSES ====================

class WithdrawalResponse(BaseModel):
    """Withdrawal response"""
    withdrawal_id: str
    user_uid: str
    amount: float
    method: WithdrawalMethod
    status: WithdrawalStatus
    requested_at: datetime
    processed_at: Optional[datetime]
    completed_at: Optional[datetime]
    cancelled_at: Optional[datetime]
    
    # Processing details
    processing_fee: float
    net_amount: Optional[float]
    transaction_fee: Optional[float]
    gateway_fee: Optional[float]
    
    # Payment details
    payment_details: Dict[str, Any]
    
    # References
    internal_reference: Optional[str]
    external_reference: Optional[str]
    receipt_url: Optional[str]
    
    # Status info
    estimated_processing: str
    status_history: List[Dict[str, Any]]
    
    # Admin
    approved_by: Optional[str]
    rejected_by: Optional[str]
    rejection_reason: Optional[str]
    notes: Optional[str]
    
    class Config:
        json_encoders = {
            datetime: lambda v: v.isoformat() if v else None
        }


class WithdrawalValidationResponse(BaseModel):
    """Withdrawal validation response"""
    eligible: bool
    amount: float
    method: str
    available_balance: float
    min_withdrawal_amount: float
    max_withdrawal_amount: float
    processing_fee: float
    net_amount: float
    withdrawal_cooldown_hours: int
    next_withdrawal_time: Optional[datetime]
    kyc_required: bool
    kyc_status: Optional[str]
    reasons: List[str]
    warnings: List[str]
    
    class Config:
        json_encoders = {
            datetime: lambda v: v.isoformat() if v else None
        }


class WithdrawalStatsResponse(BaseModel):
    """Withdrawal statistics response"""
    total_withdrawn: float
    total_withdrawals: int
    pending_withdrawals: int
    pending_amount: float
    approved_withdrawals: int
    approved_amount: float
    rejected_withdrawals: int
    rejected_amount: float
    
    # Time-based stats
    today_withdrawals: int
    today_amount: float
    this_week_withdrawals: int
    this_week_amount: float
    this_month_withdrawals: int
    this_month_amount: float
    
    # Method breakdown
    withdrawals_by_method: Dict[str, int]
    amount_by_method: Dict[str, float]
    
    # Status breakdown
    withdrawals_by_status: Dict[str, int]
    amount_by_status: Dict[str, float]
    
    class Config:
        json_encoders = {
            datetime: lambda v: v.isoformat() if v else None
        }


class WithdrawalAdminResponse(WithdrawalResponse):
    """Withdrawal response for admin (includes user info)"""
    user_info: Dict[str, Any]
    user_status: UserStatus
    kyc_status: Optional[str]
    fraud_score: float
    fraud_checked: bool
    manual_review_required: bool
    admin_notes: Optional[str]
    
    class Config:
        json_encoders = {
            datetime: lambda v: v.isoformat() if v else None
        }


# ==================== ADMIN RESPONSES ====================

class AdminProfileResponse(BaseModel):
    """Admin profile response"""
    admin_id: str
    email: str
    username: Optional[str]
    full_name: str
    avatar_url: Optional[str]
    phone: Optional[str]
    department: Optional[str]
    position: Optional[str]
    role: AdminRole
    status: AdminStatus
    permissions: List[str]
    is_super_admin: bool
    
    # Security
    two_factor_enabled: bool
    two_factor_method: Optional[str]
    ip_whitelist: List[str]
    last_password_change: Optional[datetime]
    require_password_change: bool
    
    # Dates
    created_at: datetime
    updated_at: datetime
    last_login: Optional[datetime]
    last_active: Optional[datetime]
    
    # Activity
    login_count: int
    failed_login_attempts: int
    
    # API access
    api_access_enabled: bool
    api_rate_limit: int
    api_last_used: Optional[datetime]
    
    # Metadata
    metadata: Dict[str, Any]
    notes: Optional[str]
    created_by: Optional[str]
    
    class Config:
        json_encoders = {
            datetime: lambda v: v.isoformat() if v else None
        }


class AdminDashboardResponse(BaseModel):
    """Admin dashboard response"""
    # User statistics
    total_users: int
    active_users: int
    new_users_today: int
    new_users_this_week: int
    new_users_this_month: int
    suspended_users: int
    banned_users: int
    
    # Link statistics
    total_links: int
    active_links: int
    new_links_today: int
    new_links_this_week: int
    new_links_this_month: int
    disabled_links: int
    
    # Traffic statistics
    total_clicks_today: int
    total_clicks_this_week: int
    total_clicks_this_month: int
    page3_views_today: int
    page3_views_this_week: int
    page3_views_this_month: int
    conversion_rate_today: float
    conversion_rate_this_week: float
    conversion_rate_this_month: float
    
    # Earnings statistics
    earnings_today: float
    earnings_this_week: float
    earnings_this_month: float
    total_earnings: float
    total_withdrawn: float
    platform_balance: float
    
    # Withdrawal statistics
    pending_withdrawals: int
    pending_amount: float
    approved_withdrawals_today: int
    approved_amount_today: float
    rejected_withdrawals_today: int
    
    # Fraud statistics
    fraud_attempts_today: int
    fraud_attempts_this_week: int
    blocked_sessions_today: int
    flagged_users_today: int
    
    # System statistics
    active_sessions: int
    api_requests_today: int
    error_rate_today: float
    system_health: str  # healthy, warning, critical
    
    # Growth metrics
    user_growth_rate: float
    link_growth_rate: float
    earnings_growth_rate: float
    conversion_growth_rate: float
    
    # Top performers
    top_users: List[Dict[str, Any]]
    top_links: List[Dict[str, Any]]
    top_referrers: List[Dict[str, Any]]
    
    # Recent activity
    recent_signups: List[Dict[str, Any]]
    recent_withdrawals: List[Dict[str, Any]]
    recent_fraud_attempts: List[Dict[str, Any]]
    
    class Config:
        json_encoders = {
            datetime: lambda v: v.isoformat() if v else None
        }


class UserProfileAdminResponse(BaseModel):
    """User profile response for admin (includes all details)"""
    user: Dict[str, Any]
    earnings: Dict[str, Any]
    links: Dict[str, Any]
    withdrawals: Dict[str, Any]
    fraud_flags: Dict[str, Any]
    audit_logs: List[Dict[str, Any]]
    devices: List[Dict[str, Any]]
    kyc: Optional[Dict[str, Any]]
    
    # Statistics
    account_age_days: int
    average_daily_clicks: float
    average_daily_earnings: float
    referral_network_size: int
    risk_score: float
    
    # Behavior analysis
    activity_pattern: Dict[str, Any]
    click_patterns: Dict[str, Any]
    earning_patterns: Dict[str, Any]
    withdrawal_patterns: Dict[str, Any]
    
    # Risk assessment
    risk_factors: List[str]
    risk_level: str  # low, medium, high, critical
    recommendations: List[str]
    
    class Config:
        json_encoders = {
            datetime: lambda v: v.isoformat() if v else None
        }


class PlatformSettingsResponse(BaseModel):
    """Platform settings response"""
    # Withdrawal settings
    min_withdrawal_amount: float
    max_withdrawal_amount: float
    payout_rate_per_view: float
    withdrawal_cooldown_hours: int
    
    # User limits
    max_links_per_user: int
    daily_link_limit: int
    
    # Referral settings
    referral_bonus: float
    referral_commission_rate: float
    
    # KYC settings
    kyc_required_amount: float
    kyc_verification_days: int
    
    # Fraud detection
    fraud_min_page_time: int
    fraud_max_clicks_per_ip: int
    fraud_score_threshold: float
    fraud_auto_block: bool
    bot_detection_enabled: bool
    
    # Security settings
    user_token_expire_days: int
    admin_token_expire_hours: int
    rate_limit_per_minute: int
    max_login_attempts: int
    login_block_minutes: int
    
    # Notification settings
    email_enabled: bool
    sms_enabled: bool
    push_notifications: bool
    email_from: str
    
    # Maintenance
    maintenance_mode: bool
    maintenance_message: Optional[str]
    
    # Website pool
    allowed_domains: List[str]
    blacklisted_urls: List[str]
    
    # Payment methods
    enabled_payment_methods: List[str]
    
    # Timestamps
    updated_at: datetime
    updated_by: Optional[str]
    
    class Config:
        json_encoders = {
            datetime: lambda v: v.isoformat() if v else None
        }


# ==================== AUDIT RESPONSES ====================

class AuditLogResponse(BaseModel):
    """Audit log response"""
    log_id: str
    trace_id: Optional[str]
    actor_type: str
    actor_id: Optional[str]
    actor_ip: str
    actor_user_agent: Optional[str]
    actor_location: Optional[str]
    action: AuditAction
    resource: AuditResource
    resource_id: Optional[str]
    details: Dict[str, Any]
    severity: AuditSeverity
    status: str
    error_message: Optional[str]
    timestamp: datetime
    duration_ms: Optional[int]
    tags: List[str]
    compliance_tags: List[str]
    
    class Config:
        json_encoders = {
            datetime: lambda v: v.isoformat() if v else None
        }


class AuditSummaryResponse(BaseModel):
    """Audit summary response"""
    total_logs: int
    total_pages: int
    current_page: int
    limit: int
    
    # Statistics
    by_actor_type: Dict[str, int]
    by_action: Dict[str, int]
    by_resource: Dict[str, int]
    by_severity: Dict[str, int]
    by_status: Dict[str, int]
    by_hour: Dict[int, int]
    by_day: Dict[str, int]
    
    # Time-based
    logs_today: int
    logs_yesterday: int
    logs_this_week: int
    logs_this_month: int
    
    # Error statistics
    error_count: int
    warning_count: int
    critical_count: int
    
    # Top actors
    top_actors: List[Dict[str, Any]]
    top_resources: List[Dict[str, Any]]
    
    # Compliance
    compliance_logs: int
    compliance_tags: Dict[str, int]
    
    class Config:
        json_encoders = {
            datetime: lambda v: v.isoformat() if v else None
        }


# ==================== FRAUD RESPONSES ====================

class FraudSessionResponse(BaseModel):
    """Fraud session response"""
    session_id: str
    user_uid: Optional[str]
    link_id: str
    ip_address: str
    user_agent: str
    device_fingerprint: Optional[str]
    fraud_score: float
    reasons: List[str]
    status: str  # suspicious, confirmed, blocked, whitelisted
    detected_at: datetime
    reviewed_at: Optional[datetime]
    reviewed_by: Optional[str]
    review_notes: Optional[str]
    actions_taken: List[str]
    
    # Session details
    total_clicks: int
    page_view_times: List[float]
    click_pattern: List[Dict[str, Any]]
    geographic_inconsistencies: List[str]
    device_spoofing_indicators: List[str]
    
    class Config:
        json_encoders = {
            datetime: lambda v: v.isoformat() if v else None
        }


class FraudStatsResponse(BaseModel):
    """Fraud statistics response"""
    total_sessions_today: int
    fraudulent_sessions_today: int
    fraud_rate_today: float
    total_sessions_this_week: int
    fraudulent_sessions_this_week: int
    fraud_rate_this_week: float
    
    # By type
    by_reason: Dict[str, int]
    by_severity: Dict[str, int]
    by_action: Dict[str, int]
    
    # Top sources
    top_fraudulent_ips: List[Dict[str, Any]]
    top_fraudulent_devices: List[Dict[str, Any]]
    top_fraudulent_users: List[Dict[str, Any]]
    
    # Prevention stats
    prevented_loss_today: float
    prevented_loss_this_week: float
    prevented_loss_this_month: float
    blocked_sessions_today: int
    flagged_users_today: int
    
    # Detection performance
    true_positives: int
    false_positives: int
    true_negatives: int
    false_negatives: int
    detection_accuracy: float
    
    class Config:
        json_encoders = {
            datetime: lambda v: v.isoformat() if v else None
        }


# ==================== SYSTEM RESPONSES ====================

class HealthCheckResponse(BaseModel):
    """Health check response"""
    status: str  # healthy, degraded, unhealthy
    timestamp: datetime
    version: str
    environment: str
    uptime_seconds: float
    services: Dict[str, str]
    database_status: str
    cache_status: str
    firebase_status: str
    last_backup: Optional[datetime]
    next_backup: Optional[datetime]
    metrics: Dict[str, Any]
    
    class Config:
        json_encoders = {
            datetime: lambda v: v.isoformat() if v else None
        }


class SystemMetricsResponse(BaseModel):
    """System metrics response"""
    timestamp: datetime
    
    # Process metrics
    process_cpu_percent: float
    process_memory_percent: float
    process_memory_rss_mb: float
    process_threads: int
    process_open_files: int
    
    # System metrics
    system_cpu_percent: float
    system_memory_percent: float
    system_disk_percent: float
    system_load_1m: float
    system_load_5m: float
    system_load_15m: float
    
    # Application metrics
    active_connections: int
    active_sessions: int
    request_rate_per_minute: float
    error_rate_per_minute: float
    average_response_time_ms: float
    p95_response_time_ms: float
    p99_response_time_ms: float
    
    # Database metrics
    database_connections: int
    database_query_rate: float
    database_error_rate: float
    database_cache_hit_rate: float
    
    # Cache metrics
    cache_hit_rate: float
    cache_memory_usage_mb: float
    cache_keys: int
    cache_evictions: int
    
    # Business metrics
    active_users: int
    new_users_today: int
    total_clicks_today: int
    earnings_today: float
    pending_withdrawals: int
    
    class Config:
        json_encoders = {
            datetime: lambda v: v.isoformat() if v else None
        }


class CleanupReportResponse(BaseModel):
    """Cleanup report response"""
    cleanup_type: str
    total_processed: int
    total_deleted: int
    total_skipped: int
    total_errors: int
    start_time: datetime
    end_time: datetime
    duration_seconds: float
    dry_run: bool
    
    # Details
    deleted_items: List[Dict[str, Any]]
    skipped_items: List[Dict[str, Any]]
    error_items: List[Dict[str, Any]]
    
    # Statistics
    space_freed_mb: float
    optimization_gain: float
    
    class Config:
        json_encoders = {
            datetime: lambda v: v.isoformat() if v else None
        }


class BackupResponse(BaseModel):
    """Backup response"""
    backup_id: str
    backup_type: str
    status: str  # in_progress, completed, failed
    collections: List[str]
    total_documents: int
    total_size_mb: float
    start_time: datetime
    end_time: Optional[datetime]
    duration_seconds: Optional[float]
    download_url: Optional[str]
    download_expires_at: Optional[datetime]
    encryption_key: Optional[str]  # Only if encrypted
    metadata: Dict[str, Any]
    
    class Config:
        json_encoders = {
            datetime: lambda v: v.isoformat() if v else None
        }


class RateLimitStatusResponse(BaseModel):
    """Rate limit status response"""
    user_limits: Dict[str, Any]
    ip_limits: Dict[str, Any]
    global_limits: Dict[str, Any]
    total_requests_today: int
    rate_limited_requests_today: int
    rate_limit_percentage: float
    top_limited_users: List[Dict[str, Any]]
    top_limited_ips: List[Dict[str, Any]]
    
    class Config:
        json_encoders = {
            datetime: lambda v: v.isoformat() if v else None
        }