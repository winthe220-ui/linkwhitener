"""
API root module
"""

from fastapi import APIRouter
from app.api.v1 import router as v1_router

router = APIRouter()

# Versioned API
router.include_router(v1_router, prefix="/v1")

__all__ = ["router"]
