"""
Health check endpoints
"""
from fastapi import APIRouter, Depends
from datetime import datetime
import psutil
import os

from app.schemas.response import HealthCheckResponse
from app.database import redis_client, firestore_client
from app.core.firebase_client import firebase_client

router = APIRouter(prefix="/api/v1/system", tags=["System"])


@router.get("/health", response_model=HealthCheckResponse)
async def health_check():
    """
    Comprehensive health check endpoint
    Returns health status of all services
    """
    start_time = datetime.utcnow()
    
    health_status = {
        "status": "healthy",
        "timestamp": datetime.utcnow().isoformat(),
        "version": "1.0.0",
        "environment": os.getenv("ENVIRONMENT", "development"),
        "uptime_seconds": psutil.boot_time(),
        "services": {},
        "database_status": "unknown",
        "cache_status": "unknown",
        "firebase_status": "unknown"
    }
    
    # Check Redis
    try:
        redis_client.client.ping()
        health_status["services"]["redis"] = "healthy"
        health_status["cache_status"] = "healthy"
    except Exception as e:
        health_status["services"]["redis"] = f"unhealthy: {str(e)}"
        health_status["status"] = "degraded"
        health_status["cache_status"] = "unhealthy"
    
    # Check Firestore
    try:
        # Try a simple read operation
        firestore_client.get_document("system", "health")
        health_status["services"]["firestore"] = "healthy"
        health_status["database_status"] = "healthy"
    except Exception as e:
        health_status["services"]["firestore"] = f"unhealthy: {str(e)}"
        health_status["status"] = "degraded"
        health_status["database_status"] = "unhealthy"
    
    # Check Firebase Auth
    try:
        # Try to initialize Firebase
        await firebase_client.health_check()
        health_status["services"]["firebase_auth"] = "healthy"
        health_status["firebase_status"] = "healthy"
    except Exception as e:
        health_status["services"]["firebase_auth"] = f"unhealthy: {str(e)}"
        health_status["status"] = "degraded"
        health_status["firebase_status"] = "unhealthy"
    
    # Check disk space
    try:
        disk_usage = psutil.disk_usage("/")
        health_status["services"]["disk"] = "healthy"
        health_status["disk_usage_percent"] = disk_usage.percent
    except Exception as e:
        health_status["services"]["disk"] = f"unhealthy: {str(e)}"
        health_status["status"] = "degraded"
    
    # Check memory
    try:
        memory = psutil.virtual_memory()
        health_status["services"]["memory"] = "healthy"
        health_status["memory_usage_percent"] = memory.percent
    except Exception as e:
        health_status["services"]["memory"] = f"unhealthy: {str(e)}"
        health_status["status"] = "degraded"
    
    # Calculate response time
    response_time = (datetime.utcnow() - start_time).total_seconds() * 1000
    health_status["response_time_ms"] = response_time
    
    # Add metrics
    process = psutil.Process(os.getpid())
    health_status["metrics"] = {
        "process_cpu_percent": process.cpu_percent(),
        "process_memory_mb": process.memory_info().rss / 1024 / 1024,
        "active_threads": process.num_threads(),
        "open_files": len(process.open_files())
    }
    
    return health_status


@router.get("/health/liveness")
async def liveness_probe():
    """
    Liveness probe for Kubernetes/container orchestration
    Simple check if application is running
    """
    return {
        "status": "alive",
        "timestamp": datetime.utcnow().isoformat()
    }


@router.get("/health/readiness")
async def readiness_probe():
    """
    Readiness probe for Kubernetes/container orchestration
    Check if application is ready to serve traffic
    """
    checks = {}
    
    # Check Redis
    try:
        redis_client.client.ping()
        checks["redis"] = "ready"
    except Exception:
        checks["redis"] = "not_ready"
    
    # Check Firestore
    try:
        firestore_client.get_document("system", "health")
        checks["firestore"] = "ready"
    except Exception:
        checks["firestore"] = "not_ready"
    
    # Check if all services are ready
    all_ready = all(status == "ready" for status in checks.values())
    
    return {
        "status": "ready" if all_ready else "not_ready",
        "timestamp": datetime.utcnow().isoformat(),
        "checks": checks
    }


@router.get("/metrics")
async def get_metrics():
    """
    Application metrics for monitoring
    """
    process = psutil.Process(os.getpid())
    
    # System metrics
    system_cpu = psutil.cpu_percent(interval=1)
    system_memory = psutil.virtual_memory()
    system_disk = psutil.disk_usage("/")
    
    # Process metrics
    process_cpu = process.cpu_percent()
    process_memory = process.memory_info()
    process_threads = process.num_threads()
    
    # Network metrics
    net_io = psutil.net_io_counters()
    
    # Redis metrics (simplified)
    redis_info = {}
    try:
        redis_info = redis_client.client.info()
    except:
        pass
    
    return {
        "timestamp": datetime.utcnow().isoformat(),
        "system": {
            "cpu_percent": system_cpu,
            "memory_percent": system_memory.percent,
            "memory_available_gb": system_memory.available / 1024 / 1024 / 1024,
            "disk_percent": system_disk.percent,
            "disk_free_gb": system_disk.free / 1024 / 1024 / 1024,
            "load_1m": psutil.getloadavg()[0] if hasattr(psutil, 'getloadavg') else 0,
            "load_5m": psutil.getloadavg()[1] if hasattr(psutil, 'getloadavg') and len(psutil.getloadavg()) > 1 else 0,
            "load_15m": psutil.getloadavg()[2] if hasattr(psutil, 'getloadavg') and len(psutil.getloadavg()) > 2 else 0
        },
        "process": {
            "cpu_percent": process_cpu,
            "memory_rss_mb": process_memory.rss / 1024 / 1024,
            "memory_vms_mb": process_memory.vms / 1024 / 1024,
            "threads": process_threads,
            "open_files": len(process.open_files()),
            "connections": len(process.connections())
        },
        "network": {
            "bytes_sent": net_io.bytes_sent,
            "bytes_recv": net_io.bytes_recv,
            "packets_sent": net_io.packets_sent,
            "packets_recv": net_io.packets_recv
        },
        "redis": {
            "connected_clients": redis_info.get('connected_clients', 0),
            "used_memory_mb": redis_info.get('used_memory', 0) / 1024 / 1024,
            "keys": redis_info.get('db0', {}).get('keys', 0) if 'db0' in redis_info else 0,
            "hit_rate": (redis_info.get('keyspace_hits', 0) / 
                        (redis_info.get('keyspace_hits', 0) + redis_info.get('keyspace_misses', 1))) * 100
        }
    }


@router.get("/version")
async def get_version():
    """
    Get application version information
    """
    import pkg_resources
    
    # Try to get version from package
    try:
        version = pkg_resources.get_distribution("monetization-platform").version
    except:
        version = "1.0.0"
    
    return {
        "name": "Monetization Platform",
        "version": version,
        "environment": os.getenv("ENVIRONMENT", "development"),
        "python_version": os.getenv("PYTHON_VERSION", "3.11"),
        "api_version": "v1",
        "timestamp": datetime.utcnow().isoformat()
    }


@router.get("/status")
async def get_status():
    """
    Get detailed system status
    """
    from datetime import datetime, timedelta
    
    # Get counts from Firestore (simplified)
    user_count = 0
    link_count = 0
    earnings_today = 0.0
    
    try:
        # In production, you'd get actual counts
        # This is simplified for example
        user_count = 1000
        link_count = 5000
        earnings_today = 1500.75
    except:
        pass
    
    return {
        "status": "operational",
        "timestamp": datetime.utcnow().isoformat(),
        "services": {
            "api": "operational",
            "database": "operational",
            "cache": "operational",
            "authentication": "operational",
            "payments": "operational"
        },
        "statistics": {
            "total_users": user_count,
            "total_links": link_count,
            "earnings_today": earnings_today,
            "active_sessions": 0,  # Would get from Redis
            "pending_withdrawals": 0  # Would get from database
        },
        "uptime": {
            "started_at": (datetime.utcnow() - timedelta(hours=24)).isoformat(),
            "uptime_days": 1,
            "last_restart": (datetime.utcnow() - timedelta(hours=24)).isoformat()
        },
        "maintenance": {
            "scheduled": False,
            "next_maintenance": None,
            "message": None
        }
    }