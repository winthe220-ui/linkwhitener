from fastapi import (
    APIRouter,
    Depends,
    HTTPException,
    status,
    Request,
    BackgroundTasks,
    Query,
    Body
)
from typing import Optional
from datetime import datetime

from app.schemas.request import (
    UserVerifyRequest,
    UserProfileUpdate,
    LinkCreateRequest,
    WithdrawalRequest
)
from app.schemas.response import (
    UserAuthResponse,
    UserProfileResponse,
    LinkResponse,
    EarningsSummaryResponse,
    WithdrawalResponse,
    PaginatedResponse
)
from app.middleware.auth import get_current_user, get_current_active_user
from app.services import (
    auth_service,
    user_service,
    link_service,
    earnings_service,
    withdrawal_service,
    fraud_service
)
from app.core.rate_limiter import rate_limiter
from app.config import settings

router = APIRouter(prefix="/api/v1/user", tags=["User"])

# ==================== AUTH ====================

@router.post("/auth/verify", response_model=UserAuthResponse)
async def verify_user(
    request: Request,
    verify_data: UserVerifyRequest,
    background_tasks: BackgroundTasks
):
    """
    Verify Firebase token and login/register user
    """
    await rate_limiter.check_ip_rate_limit(request.client.host, "user_verify")

    firebase_user = await auth_service.verify_firebase_token(
        verify_data.id_token
    )

    user = await user_service.get_user_by_uid(firebase_user["uid"])

    if not user:
        user = await user_service.create_user(
            uid=firebase_user["uid"],
            phone=firebase_user["phone"],
            email=verify_data.email,
            username=verify_data.username,
            ip_address=request.client.host,
            user_agent=request.headers.get("User-Agent")
        )

        background_tasks.add_task(
            user_service.send_welcome_notification,
            user_uid=user.uid,
            username=user.username
        )

        is_new_user = True
    else:
        user = await user_service.update_user_login(
            user_uid=user.uid,
            ip_address=request.client.host,
            user_agent=request.headers.get("User-Agent")
        )
        is_new_user = False

    access_token = await auth_service.create_custom_token(
        user_uid=user.uid,
        claims={
            "role": "user",
            "username": user.username,
            "status": user.status
        }
    )

    refresh_token = await auth_service.create_refresh_token(user.uid)

    return UserAuthResponse(
        uid=user.uid,
        username=user.username,
        phone=user.phone,
        email=user.email,
        status=user.status,
        is_new_user=is_new_user,
        access_token=access_token,
        refresh_token=refresh_token,
        token_type="bearer",
        expires_in=settings.user_token_expire_days * 86400
    )


@router.post("/auth/refresh", response_model=UserAuthResponse)
async def refresh_access_token(
    request: Request,
    refresh_token: str = Body(..., embed=True)
):
    """
    Refresh access token using refresh token
    """
    await rate_limiter.check_ip_rate_limit(
        request.client.host, "user_refresh"
    )

    access_token, new_refresh_token = await auth_service.refresh_access_token(
        refresh_token
    )

    user_uid = await auth_service.get_user_from_token(access_token)
    user = await user_service.get_user_by_uid(user_uid)

    return UserAuthResponse(
        uid=user.uid,
        username=user.username,
        phone=user.phone,
        email=user.email,
        status=user.status,
        is_new_user=False,
        access_token=access_token,
        refresh_token=new_refresh_token,
        token_type="bearer",
        expires_in=settings.user_token_expire_days * 86400
    )


@router.post("/auth/logout")
async def logout_user(
    request: Request,
    current_user: dict = Depends(get_current_user)
):
    """
    Logout user and revoke token
    """
    auth_header = request.headers.get("Authorization")
    if auth_header and auth_header.startswith("Bearer "):
        await auth_service.revoke_token(auth_header.split(" ")[1])

    return {"message": "Logged out successfully"}

# ==================== PROFILE ====================

@router.get("/profile", response_model=UserProfileResponse)
async def get_profile(
    current_user: dict = Depends(get_current_active_user)
):
    user = await user_service.get_user_by_uid(current_user["uid"])
    earnings = await earnings_service.get_user_earnings_summary(user.uid)

    return UserProfileResponse(
        uid=user.uid,
        username=user.username,
        phone=user.phone,
        email=user.email,
        full_name=user.full_name,
        avatar_url=user.avatar_url,
        status=user.status,
        tier=user.tier,
        created_at=user.created_at,
        last_login=user.last_login,
        total_links=user.total_links,
        active_links=user.active_links,
        total_clicks=user.total_clicks,
        valid_page3_views=user.valid_page3_views,
        conversion_rate=user.conversion_rate,
        total_earned=earnings.total_earned,
        available_balance=earnings.available_balance,
        pending_withdrawal=earnings.pending_withdrawal,
        withdrawn_amount=earnings.withdrawn_amount,
        referral_earnings=earnings.referral_earnings,
        bonus_earnings=earnings.bonus_earnings,
        is_kyc_verified=user.is_kyc_verified,
        kyc_status=user.kyc.status if user.kyc else None,
        referral_code=user.referral_code,
        referral_count=user.referral_count,
        payout_preferences=user.payout_preferences
    )


@router.patch("/profile")
async def update_profile(
    profile_update: UserProfileUpdate,
    current_user: dict = Depends(get_current_active_user)
):
    user = await user_service.update_user_profile(
        user_uid=current_user["uid"],
        update_data=profile_update.dict(exclude_unset=True)
    )
    return {"message": "Profile updated", "user": user}

# ==================== LINKS ====================

@router.post("/links/create", response_model=LinkResponse)
async def create_link(
    request: Request,
    link_data: LinkCreateRequest,
    background_tasks: BackgroundTasks,
    current_user: dict = Depends(get_current_active_user)
):
    await rate_limiter.check_user_rate_limit(
        current_user["uid"], "create_link"
    )

    link = await link_service.create_link(
        user_uid=current_user["uid"],
        original_url=link_data.url,
        title=link_data.title,
        description=link_data.description,
        tags=link_data.tags,
        metadata=link_data.metadata,
        ip_address=request.client.host
    )

    background_tasks.add_task(
        link_service.index_link_for_search, link.link_id
    )

    return LinkResponse.from_orm(link)


@router.get("/links/my", response_model=PaginatedResponse[LinkResponse])
async def list_links(
    status: Optional[str] = None,
    page: int = Query(1, ge=1),
    limit: int = Query(20, le=50),
    current_user: dict = Depends(get_current_active_user)
):
    links, total, has_next = await link_service.get_user_links(
        user_uid=current_user["uid"],
        status=status,
        page=page,
        limit=limit
    )

    return PaginatedResponse(
        data=[LinkResponse.from_orm(l) for l in links],
        page=page,
        limit=limit,
        total=total,
        has_next=has_next
    )

# ==================== EARNINGS ====================

@router.get("/earnings/summary", response_model=EarningsSummaryResponse)
async def earnings_summary(
    current_user: dict = Depends(get_current_active_user)
):
    earnings = await earnings_service.get_user_earnings_summary(
        current_user["uid"]
    )
    return EarningsSummaryResponse(**earnings.dict())

# ==================== WITHDRAWALS ====================

@router.post("/withdraw/request", response_model=WithdrawalResponse)
async def request_withdrawal(
    request: Request,
    withdrawal_data: WithdrawalRequest,
    background_tasks: BackgroundTasks,
    current_user: dict = Depends(get_current_active_user)
):
    await rate_limiter.check_user_rate_limit(
        current_user["uid"], "withdraw_request"
    )

    withdrawal = await withdrawal_service.request_withdrawal(
        user_uid=current_user["uid"],
        amount=withdrawal_data.amount,
        method=withdrawal_data.method,
        payment_details=withdrawal_data.payment_details,
        ip_address=request.client.host,
        user_agent=request.headers.get("User-Agent")
    )

    background_tasks.add_task(
        fraud_service.check_withdrawal_for_fraud,
        withdrawal.withdrawal_id
    )

    return WithdrawalResponse.from_orm(withdrawal)


@router.get("/withdraw/history", response_model=PaginatedResponse[WithdrawalResponse])
async def withdrawal_history(
    page: int = Query(1, ge=1),
    limit: int = Query(20, le=50),
    status: Optional[str] = None,
    current_user: dict = Depends(get_current_active_user)
):
    withdrawals, total, has_next = await withdrawal_service.get_withdrawal_history(
        user_uid=current_user["uid"],
        status=status,
        page=page,
        limit=limit
    )

    return PaginatedResponse(
        data=[WithdrawalResponse.from_orm(w) for w in withdrawals],
        page=page,
        limit=limit,
        total=total,
        has_next=has_next
    )
