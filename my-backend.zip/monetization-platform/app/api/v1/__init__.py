"""
API version 1 endpoints
"""

from fastapi import APIRouter

router = APIRouter()

from app.api.v1.health import router as health_router
from app.api.v1.user import router as user_router
from app.api.v1.admin import router as admin_router
from app.api.v1.link import router as link_router
from app.api.v1.earnings import router as earnings_router
from app.api.v1.withdrawal import router as withdrawal_router
from app.api.v1.system import router as system_router

router.include_router(health_router, tags=["System"])
router.include_router(user_router, tags=["User"])
router.include_router(admin_router, tags=["Admin"])
router.include_router(link_router, tags=["Links"])
router.include_router(earnings_router, tags=["Earnings"])
router.include_router(withdrawal_router, tags=["Withdrawals"])
router.include_router(system_router, tags=["System"])

__all__ = ["router"]
