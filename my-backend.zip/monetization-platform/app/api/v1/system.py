"""
System health & diagnostics endpoints
"""

from fastapi import APIRouter, Depends
from datetime import datetime

from app.middleware.auth import get_current_admin, require_permission
from app.core import (
    firebase_client,
    async_firestore_client,
    cache_manager
)
from app.database import redis_client

router = APIRouter(prefix="/api/v1/system", tags=["System"])


@router.get("/health")
async def system_health():
    """
    Public health check (used by load balancers, uptime monitors)
    """
    return {
        "status": "ok",
        "service": "monetization-platform",
        "timestamp": datetime.utcnow().isoformat()
    }


@router.get("/status")
@require_permission(["view_system"])
async def system_status(
    current_admin: dict = Depends(get_current_admin)
):
    """
    Detailed internal system status (ADMIN ONLY)
    """
    firebase = await firebase_client.health_check()
    firestore = await async_firestore_client.health_check()

    redis_status = {
        "status": "healthy",
        "service": "redis",
        "timestamp": datetime.utcnow().isoformat()
    }
    try:
        await redis_client.ping()
    except Exception as e:
        redis_status["status"] = "unhealthy"
        redis_status["error"] = str(e)

    return {
        "firebase": firebase,
        "firestore": firestore,
        "redis": redis_status,
        "checked_at": datetime.utcnow().isoformat()
    }


@router.post("/cache/clear")
@require_permission(["manage_system"])
async def clear_cache(
    pattern: str = "*",
    current_admin: dict = Depends(get_current_admin)
):
    """
    Clear Redis cache by pattern
    """
    deleted = await cache_manager.clear_pattern(pattern)
    return {
        "message": "Cache cleared successfully",
        "deleted_keys": deleted,
        "pattern": pattern
    }
