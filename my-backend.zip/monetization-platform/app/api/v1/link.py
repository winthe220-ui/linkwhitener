"""
Link management endpoints
"""
from fastapi import APIRouter, Depends, HTTPException, status, Request, Query
from typing import List, Optional
from datetime import datetime, timedelta

from app.schemas.request import (
    LinkCreateRequest,
    LinkUpdateRequest,
    LinkAnalyticsQuery,
    BulkLinkCreateRequest,
    PaginationParams
)
from app.schemas.response import (
    LinkResponse,
    LinkAnalyticsResponse,
    BulkLinkCreateResponse,
    PaginatedResponse,
    SuccessResponse,
    ErrorResponse
)
from app.middleware.auth import get_current_active_user
from app.services.link_service import link_service
from app.core.rate_limiter import rate_limiter

router = APIRouter(prefix="/api/v1/links", tags=["Links"])


@router.post("/create", response_model=LinkResponse)
async def create_link(
    request: Request,
    link_data: LinkCreateRequest,
    current_user: dict = Depends(get_current_active_user)
):
    """
    Create a new smart link
    
    - Validates URL
    - Checks blacklist
    - Applies rate limiting
    - Generates short code
    - Stores in database
    """
    # Rate limiting
    await rate_limiter.check_user_rate_limit(current_user["uid"], "create_link")
    
    # Create link
    link = await link_service.create_link(
        user_uid=current_user["uid"],
        original_url=str(link_data.url),
        title=link_data.title,
        description=link_data.description,
        tags=link_data.tags or [],
        custom_code=link_data.custom_code,
        utm_params={
            "source": link_data.utm_source,
            "medium": link_data.utm_medium,
            "campaign": link_data.utm_campaign,
            "content": link_data.utm_content,
            "term": link_data.utm_term
        } if any([link_data.utm_source, link_data.utm_medium, link_data.utm_campaign,
                 link_data.utm_content, link_data.utm_term]) else None,
        password=link_data.password,
        expiration_date=link_data.expiration_date,
        max_clicks=link_data.max_clicks,
        ip_address=request.client.host
    )
    
    return LinkResponse(
        link_id=link.link_id,
        short_code=link.short_code,
        short_url=link.short_url,
        original_url=link.original_url,
        title=link.title,
        description=link.description,
        status=link.status,
        link_type=link.link_type,
        created_at=link.created_at,
        updated_at=link.updated_at,
        expires_at=link.expires_at,
        total_clicks=link.total_clicks,
        unique_clicks=link.unique_clicks,
        page1_views=link.page1_views,
        page2_views=link.page2_views,
        page3_views=link.page3_views,
        conversion_rate=link.conversion_rate,
        earnings_total=link.earnings_total,
        earnings_today=link.earnings_today,
        earnings_this_month=link.earnings_this_month,
        has_password=bool(link.password_hash),
        is_expired=link.expires_at and link.expires_at < datetime.utcnow(),
        max_clicks_reached=link.max_clicks and link.total_clicks >= link.max_clicks,
        tags=link.tags,
        qr_code_url=link.qr_code_url,
        analytics_url=f"/api/v1/links/{link.link_id}/analytics"
    )


@router.post("/bulk-create", response_model=BulkLinkCreateResponse)
async def bulk_create_links(
    request: Request,
    bulk_data: BulkLinkCreateRequest,
    current_user: dict = Depends(get_current_active_user)
):
    """
    Create multiple links in bulk
    
    - Limited to 100 links per request
    - Each link is validated individually
    - Returns success/failure for each link
    """
    # Rate limiting
    await rate_limiter.check_user_rate_limit(current_user["uid"], "bulk_create_links")
    
    # Check limit
    if len(bulk_data.links) > 100:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Maximum 100 links per bulk request"
        )
    
    # Process bulk creation
    result = await link_service.bulk_create_links(
        user_uid=current_user["uid"],
        links=bulk_data.links,
        metadata=bulk_data.metadata or {},
        ip_address=request.client.host
    )
    
    return BulkLinkCreateResponse(
        success_count=result["success_count"],
        failed_count=result["failed_count"],
        total_count=result["total_count"],
        created_links=result["created_links"],
        failed_links=result["failed_links"],
        batch_id=result.get("batch_id")
    )


@router.get("/my", response_model=PaginatedResponse[LinkResponse])
async def get_my_links(
    request: Request,
    status: Optional[str] = Query(None, regex="^(active|paused|disabled|archived|all)$"),
    search: Optional[str] = Query(None, min_length=2),
    tags: Optional[List[str]] = Query(None),
    pagination: PaginationParams = Depends(),
    current_user: dict = Depends(get_current_active_user)
):
    """
    Get paginated list of user's links
    
    - Filter by status
    - Search in title/description/URL
    - Filter by tags
    - Paginated response
    """
    links, total, has_next = await link_service.get_user_links(
        user_uid=current_user["uid"],
        status=status if status != "all" else None,
        search=search,
        tags=tags,
        page=pagination.page,
        limit=pagination.limit,
        sort_by=pagination.sort_by,
        sort_order=pagination.sort_order
    )
    
    # Convert to response models
    link_responses = []
    for link in links:
        link_responses.append(LinkResponse(
            link_id=link.link_id,
            short_code=link.short_code,
            short_url=link.short_url,
            original_url=link.original_url,
            title=link.title,
            description=link.description,
            status=link.status,
            link_type=link.link_type,
            created_at=link.created_at,
            updated_at=link.updated_at,
            expires_at=link.expires_at,
            total_clicks=link.total_clicks,
            unique_clicks=link.unique_clicks,
            page1_views=link.page1_views,
            page2_views=link.page2_views,
            page3_views=link.page3_views,
            conversion_rate=link.conversion_rate,
            earnings_total=link.earnings_total,
            earnings_today=link.earnings_today,
            earnings_this_month=link.earnings_this_month,
            has_password=bool(link.password_hash),
            is_expired=link.expires_at and link.expires_at < datetime.utcnow(),
            max_clicks_reached=link.max_clicks and link.total_clicks >= link.max_clicks,
            tags=link.tags,
            qr_code_url=link.qr_code_url,
            analytics_url=f"/api/v1/links/{link.link_id}/analytics"
        ))
    
    return PaginatedResponse(
        data=link_responses,
        page=pagination.page,
        limit=pagination.limit,
        total=total,
        has_next=has_next,
        has_previous=pagination.page > 1,
        total_pages=(total + pagination.limit - 1) // pagination.limit
    )


@router.get("/{link_id}", response_model=LinkResponse)
async def get_link(
    link_id: str,
    current_user: dict = Depends(get_current_active_user)
):
    """
    Get detailed information about a specific link
    
    - Verifies link belongs to user
    - Returns all link details
    """
    link = await link_service.get_link(
        link_id=link_id,
        user_uid=current_user["uid"]
    )
    
    if not link:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Link not found"
        )
    
    return LinkResponse(
        link_id=link.link_id,
        short_code=link.short_code,
        short_url=link.short_url,
        original_url=link.original_url,
        title=link.title,
        description=link.description,
        status=link.status,
        link_type=link.link_type,
        created_at=link.created_at,
        updated_at=link.updated_at,
        expires_at=link.expires_at,
        total_clicks=link.total_clicks,
        unique_clicks=link.unique_clicks,
        page1_views=link.page1_views,
        page2_views=link.page2_views,
        page3_views=link.page3_views,
        conversion_rate=link.conversion_rate,
        earnings_total=link.earnings_total,
        earnings_today=link.earnings_today,
        earnings_this_month=link.earnings_this_month,
        has_password=bool(link.password_hash),
        is_expired=link.expires_at and link.expires_at < datetime.utcnow(),
        max_clicks_reached=link.max_clicks and link.total_clicks >= link.max_clicks,
        tags=link.tags,
        qr_code_url=link.qr_code_url,
        analytics_url=f"/api/v1/links/{link.link_id}/analytics"
    )


@router.put("/{link_id}", response_model=LinkResponse)
async def update_link(
    link_id: str,
    update_data: LinkUpdateRequest,
    current_user: dict = Depends(get_current_active_user)
):
    """
    Update link information
    
    - Only certain fields can be updated
    - Validates user ownership
    - Returns updated link
    """
    updated_link = await link_service.update_link(
        link_id=link_id,
        user_uid=current_user["uid"],
        update_data=update_data.dict(exclude_unset=True)
    )
    
    if not updated_link:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Link not found or not authorized"
        )
    
    return LinkResponse(
        link_id=updated_link.link_id,
        short_code=updated_link.short_code,
        short_url=updated_link.short_url,
        original_url=updated_link.original_url,
        title=updated_link.title,
        description=updated_link.description,
        status=updated_link.status,
        link_type=updated_link.link_type,
        created_at=updated_link.created_at,
        updated_at=updated_link.updated_at,
        expires_at=updated_link.expires_at,
        total_clicks=updated_link.total_clicks,
        unique_clicks=updated_link.unique_clicks,
        page1_views=updated_link.page1_views,
        page2_views=updated_link.page2_views,
        page3_views=updated_link.page3_views,
        conversion_rate=updated_link.conversion_rate,
        earnings_total=updated_link.earnings_total,
        earnings_today=updated_link.earnings_today,
        earnings_this_month=updated_link.earnings_this_month,
        has_password=bool(updated_link.password_hash),
        is_expired=updated_link.expires_at and updated_link.expires_at < datetime.utcnow(),
        max_clicks_reached=updated_link.max_clicks and updated_link.total_clicks >= updated_link.max_clicks,
        tags=updated_link.tags,
        qr_code_url=updated_link.qr_code_url,
        analytics_url=f"/api/v1/links/{updated_link.link_id}/analytics"
    )


@router.get("/{link_id}/analytics", response_model=LinkAnalyticsResponse)
async def get_link_analytics(
    link_id: str,
    analytics_query: LinkAnalyticsQuery = Depends(),
    current_user: dict = Depends(get_current_active_user)
):
    """
    Get detailed analytics for a link
    
    - Time series data
    - Geographic distribution
    - Device breakdown
    - Referrer analysis
    - Performance metrics
    """
    analytics = await link_service.get_link_analytics(
        link_id=link_id,
        user_uid=current_user["uid"],
        period=analytics_query.period,
        group_by=analytics_query.group_by,
        metrics=analytics_query.metrics
    )
    
    if not analytics:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Link not found or no analytics data"
        )
    
    return LinkAnalyticsResponse(
        link_id=analytics["link_id"],
        period=analytics_query.period,
        total_clicks=analytics["total_clicks"],
        unique_clicks=analytics["unique_clicks"],
        page1_views=analytics["page1_views"],
        page2_views=analytics["page2_views"],
        page3_views=analytics["page3_views"],
        conversion_rate=analytics["conversion_rate"],
        earnings_total=analytics["earnings_total"],
        clicks_by_day=analytics.get("clicks_by_day", []),
        views_by_page=analytics.get("views_by_page", {}),
        earnings_by_day=analytics.get("earnings_by_day", []),
        clicks_by_country=analytics.get("clicks_by_country", []),
        clicks_by_city=analytics.get("clicks_by_city", []),
        clicks_by_device=analytics.get("clicks_by_device", {}),
        clicks_by_browser=analytics.get("clicks_by_browser", {}),
        clicks_by_os=analytics.get("clicks_by_os", {}),
        top_referrers=analytics.get("top_referrers", []),
        referrer_types=analytics.get("referrer_types", {}),
        average_page_time=analytics.get("average_page_time", {}),
        bounce_rate=analytics.get("bounce_rate", 0.0),
        click_through_rate=analytics.get("click_through_rate", 0.0)
    )


@router.post("/{link_id}/disable", response_model=SuccessResponse)
async def disable_link(
    link_id: str,
    current_user: dict = Depends(get_current_active_user)
):
    """
    Disable a link (soft delete)
    
    - Link becomes inaccessible
    - Analytics preserved
    - Can be re-enabled later
    """
    success = await link_service.disable_link(
        link_id=link_id,
        user_uid=current_user["uid"]
    )
    
    if not success:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Link not found or not authorized"
        )
    
    return SuccessResponse(
        message="Link disabled successfully"
    )


@router.delete("/{link_id}", response_model=SuccessResponse)
async def delete_link(
    link_id: str,
    permanent: bool = Query(False, description="Permanently delete link"),
    current_user: dict = Depends(get_current_active_user)
):
    """
    Delete a link
    
    - Soft delete by default (archived)
    - Permanent delete removes all data
    - Requires confirmation for permanent delete
    """
    if permanent:
        # Confirm permanent deletion
        success = await link_service.permanent_delete_link(
            link_id=link_id,
            user_uid=current_user["uid"]
        )
        message = "Link permanently deleted"
    else:
        success = await link_service.delete_link(
            link_id=link_id,
            user_uid=current_user["uid"]
        )
        message = "Link deleted successfully"
    
    if not success:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Link not found or not authorized"
        )
    
    return SuccessResponse(message=message)


@router.post("/{link_id}/enable", response_model=SuccessResponse)
async def enable_link(
    link_id: str,
    current_user: dict = Depends(get_current_active_user)
):
    """
    Re-enable a disabled link
    """
    success = await link_service.enable_link(
        link_id=link_id,
        user_uid=current_user["uid"]
    )
    
    if not success:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Link not found or not authorized"
        )
    
    return SuccessResponse(
        message="Link enabled successfully"
    )


@router.post("/{link_id}/password", response_model=SuccessResponse)
async def set_link_password(
    link_id: str,
    password: str,
    current_user: dict = Depends(get_current_active_user)
):
    """
    Set or update link password
    """
    success = await link_service.set_link_password(
        link_id=link_id,
        user_uid=current_user["uid"],
        password=password
    )
    
    if not success:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Link not found or not authorized"
        )
    
    return SuccessResponse(
        message="Link password updated successfully"
    )


@router.delete("/{link_id}/password", response_model=SuccessResponse)
async def remove_link_password(
    link_id: str,
    current_user: dict = Depends(get_current_active_user)
):
    """
    Remove password protection from link
    """
    success = await link_service.remove_link_password(
        link_id=link_id,
        user_uid=current_user["uid"]
    )
    
    if not success:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Link not found or not authorized"
        )
    
    return SuccessResponse(
        message="Link password removed successfully"
    )


@router.get("/{link_id}/qr", response_model=dict)
async def get_qr_code(
    link_id: str,
    size: int = Query(300, ge=100, le=1000),
    current_user: dict = Depends(get_current_active_user)
):
    """
    Get QR code for link
    
    - Generates QR code URL
    - Customizable size
    """
    qr_code_url = await link_service.generate_qr_code(
        link_id=link_id,
        user_uid=current_user["uid"],
        size=size
    )
    
    if not qr_code_url:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Link not found or not authorized"
        )
    
    return {
        "qr_code_url": qr_code_url,
        "size": size,
        "link_id": link_id,
        "short_url": qr_code_url.split("/")[-1].split("?")[0]  # Extract short code
    }


@router.get("/{link_id}/stats/summary", response_model=dict)
async def get_link_stats_summary(
    link_id: str,
    period: str = Query("7d", regex="^(1d|7d|30d|90d|all)$"),
    current_user: dict = Depends(get_current_active_user)
):
    """
    Get summary statistics for link
    
    - Key metrics
    - Performance indicators
    - Comparison with previous period
    """
    stats = await link_service.get_link_stats_summary(
        link_id=link_id,
        user_uid=current_user["uid"],
        period=period
    )
    
    if not stats:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Link not found or no stats available"
        )
    
    return stats


@router.get("/{link_id}/referrers", response_model=dict)
async def get_link_referrers(
    link_id: str,
    limit: int = Query(10, ge=1, le=50),
    current_user: dict = Depends(get_current_active_user)
):
    """
    Get top referrers for link
    """
    referrers = await link_service.get_top_referrers(
        link_id=link_id,
        user_uid=current_user["uid"],
        limit=limit
    )
    
    return {
        "link_id": link_id,
        "total_referrers": len(referrers),
        "top_referrers": referrers,
        "timestamp": datetime.utcnow().isoformat()
    }


@router.get("/{link_id}/geographic", response_model=dict)
async def get_link_geographic(
    link_id: str,
    current_user: dict = Depends(get_current_active_user)
):
    """
    Get geographic distribution of link clicks
    """
    geographic = await link_service.get_geographic_distribution(
        link_id=link_id,
        user_uid=current_user["uid"]
    )
    
    return {
        "link_id": link_id,
        "total_countries": len(geographic.get("countries", [])),
        "total_cities": len(geographic.get("cities", [])),
        "countries": geographic.get("countries", []),
        "cities": geographic.get("cities", []),
        "timestamp": datetime.utcnow().isoformat()
    }


@router.post("/{link_id}/clone", response_model=LinkResponse)
async def clone_link(
    link_id: str,
    new_title: Optional[str] = None,
    current_user: dict = Depends(get_current_active_user)
):
    """
    Clone an existing link
    
    - Creates new link with same settings
    - Resets statistics
    - Generates new short code
    """
    cloned_link = await link_service.clone_link(
        link_id=link_id,
        user_uid=current_user["uid"],
        new_title=new_title
    )
    
    if not cloned_link:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Link not found or not authorized"
        )
    
    return LinkResponse(
        link_id=cloned_link.link_id,
        short_code=cloned_link.short_code,
        short_url=cloned_link.short_url,
        original_url=cloned_link.original_url,
        title=cloned_link.title,
        description=cloned_link.description,
        status=cloned_link.status,
        link_type=cloned_link.link_type,
        created_at=cloned_link.created_at,
        updated_at=cloned_link.updated_at,
        expires_at=cloned_link.expires_at,
        total_clicks=0,  # Reset for cloned link
        unique_clicks=0,
        page1_views=0,
        page2_views=0,
        page3_views=0,
        conversion_rate=0.0,
        earnings_total=0.0,
        earnings_today=0.0,
        earnings_this_month=0.0,
        has_password=bool(cloned_link.password_hash),
        is_expired=cloned_link.expires_at and cloned_link.expires_at < datetime.utcnow(),
        max_clicks_reached=False,
        tags=cloned_link.tags,
        qr_code_url=cloned_link.qr_code_url,
        analytics_url=f"/api/v1/links/{cloned_link.link_id}/analytics"
    )


@router.get("/stats/overview", response_model=dict)
async def get_user_links_overview(
    current_user: dict = Depends(get_current_active_user)
):
    """
    Get overview of all user links
    
    - Total links by status
    - Total clicks/earnings
    - Performance summary
    """
    overview = await link_service.get_user_links_overview(
        user_uid=current_user["uid"]
    )
    
    return overview