"""
Withdrawal management endpoints
"""

from fastapi import (
    APIRouter,
    Depends,
    HTTPException,
    status,
    Request,
    Query,
    Body
)
from typing import Optional
from datetime import datetime

from app.schemas.request import (
    WithdrawalRequest,
    WithdrawalActionRequest,
    PaginationParams
)
from app.schemas.response import (
    WithdrawalResponse,
    WithdrawalValidationResponse,
    WithdrawalStatsResponse,
    PaginatedResponse,
    SuccessResponse
)
from app.middleware.auth import (
    get_current_active_user,
    get_current_admin,
    require_permission
)
from app.services.withdrawal_service import withdrawal_service
from app.api.dependencies import get_pagination, get_date_range
from app.core.rate_limiter import rate_limiter

router = APIRouter(prefix="/api/v1/withdraw", tags=["Withdrawals"])

# ==================== USER ENDPOINTS ====================

@router.post("/request", response_model=WithdrawalResponse)
async def request_withdrawal(
    request: Request,
    withdrawal_data: WithdrawalRequest,
    current_user: dict = Depends(get_current_active_user)
):
    """
    Request a withdrawal
    """
    await rate_limiter.check_user_rate_limit(
        current_user["uid"], "withdraw_request"
    )

    withdrawal = await withdrawal_service.request_withdrawal(
        user_uid=current_user["uid"],
        amount=withdrawal_data.amount,
        method=withdrawal_data.method,
        payment_details=withdrawal_data.payment_details,
        ip_address=request.client.host,
        user_agent=request.headers.get("User-Agent")
    )

    return WithdrawalResponse.from_orm(withdrawal)


@router.post("/validate", response_model=WithdrawalValidationResponse)
async def validate_withdrawal(
    amount: float = Query(..., gt=0),
    method: str = Query(
        ...,
        regex="^(upi|bank_transfer|paytm|phonepe|google_pay)$"
    ),
    current_user: dict = Depends(get_current_active_user)
):
    """
    Validate withdrawal before submitting
    """
    validation = await withdrawal_service.validate_withdrawal(
        user_uid=current_user["uid"],
        amount=amount,
        method=method
    )

    return WithdrawalValidationResponse(**validation)


@router.get("/history", response_model=PaginatedResponse[WithdrawalResponse])
async def get_withdrawal_history(
    status: Optional[str] = Query(
        None,
        regex="^(pending|approved|rejected|completed|cancelled|all)$"
    ),
    pagination: PaginationParams = Depends(get_pagination),
    date_range=Depends(get_date_range),
    current_user: dict = Depends(get_current_active_user)
):
    """
    Get withdrawal history (paginated)
    """
    withdrawals, total, has_next = await withdrawal_service.get_withdrawal_history(
        user_uid=current_user["uid"],
        status=None if status == "all" else status,
        start_date=date_range.start_date,
        end_date=date_range.end_date,
        page=pagination.page,
        limit=pagination.limit,
        sort_by=pagination.sort_by,
        sort_order=pagination.sort_order
    )

    return PaginatedResponse(
        data=[WithdrawalResponse.from_orm(w) for w in withdrawals],
        page=pagination.page,
        limit=pagination.limit,
        total=total,
        has_next=has_next,
        has_previous=pagination.page > 1,
        total_pages=(total + pagination.limit - 1) // pagination.limit
    )


@router.post("/cancel", response_model=SuccessResponse)
async def cancel_withdrawal(
    withdrawal_id: str = Body(..., embed=True),
    current_user: dict = Depends(get_current_active_user)
):
    """
    Cancel a pending withdrawal
    """
    success = await withdrawal_service.cancel_withdrawal(
        withdrawal_id=withdrawal_id,
        user_uid=current_user["uid"]
    )

    if not success:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Withdrawal cannot be cancelled"
        )

    return SuccessResponse(message="Withdrawal cancelled successfully")


@router.get("/stats", response_model=WithdrawalStatsResponse)
async def get_withdrawal_stats(
    current_user: dict = Depends(get_current_active_user)
):
    """
    Get user withdrawal statistics
    """
    stats = await withdrawal_service.get_user_withdrawal_stats(
        user_uid=current_user["uid"]
    )

    return WithdrawalStatsResponse(**stats)


@router.get("/methods", response_model=dict)
async def get_withdrawal_methods(
    current_user: dict = Depends(get_current_active_user)
):
    """
    Get available withdrawal methods
    """
    methods = await withdrawal_service.get_available_withdrawal_methods(
        user_uid=current_user["uid"]
    )

    return {
        "available_methods": methods,
        "recommended_method": methods[0]["method"] if methods else None,
        "timestamp": datetime.utcnow().isoformat()
    }


@router.get("/limits", response_model=dict)
async def get_withdrawal_limits(
    current_user: dict = Depends(get_current_active_user)
):
    """
    Get withdrawal limits
    """
    limits = await withdrawal_service.get_withdrawal_limits(
        user_uid=current_user["uid"]
    )

    return limits


@router.get("/fees", response_model=dict)
async def get_withdrawal_fees(
    amount: float = Query(..., gt=0),
    method: str = Query(
        ...,
        regex="^(upi|bank_transfer|paytm|phonepe|google_pay)$"
    ),
    current_user: dict = Depends(get_current_active_user)
):
    """
    Calculate withdrawal fees
    """
    fees = await withdrawal_service.calculate_withdrawal_fees(
        amount=amount,
        method=method,
        user_uid=current_user["uid"]
    )

    return fees

# ==================== ADMIN ENDPOINTS ====================

@router.post("/{withdrawal_id}/approve", response_model=SuccessResponse)
@require_permission(["approve_withdrawals"])
async def approve_withdrawal(
    withdrawal_id: str,
    action_data: WithdrawalActionRequest,
    current_admin: dict = Depends(get_current_admin)
):
    """
    Admin approve withdrawal
    """
    await withdrawal_service.approve_withdrawal(
        withdrawal_id=withdrawal_id,
        admin_id=current_admin["admin_id"],
        notes=action_data.notes
    )

    return SuccessResponse(message="Withdrawal approved")


@router.post("/{withdrawal_id}/reject", response_model=SuccessResponse)
@require_permission(["reject_withdrawals"])
async def reject_withdrawal(
    withdrawal_id: str,
    action_data: WithdrawalActionRequest,
    current_admin: dict = Depends(get_current_admin)
):
    """
    Admin reject withdrawal
    """
    await withdrawal_service.reject_withdrawal(
        withdrawal_id=withdrawal_id,
        admin_id=current_admin["admin_id"],
        reason=action_data.notes
    )

    return SuccessResponse(message="Withdrawal rejected")
