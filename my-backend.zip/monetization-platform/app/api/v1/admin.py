from fastapi import APIRouter, Depends, HTTPException, status, Request, Query, Body
from typing import List, Optional, Dict, Any
from datetime import datetime, timedelta
import uuid
from app.config import settings

from app.schemas.request import (
    AdminLoginRequest,
    AdminCreateRequest,
    UserUpdateAdmin,
    WithdrawalActionRequest,
    PlatformSettingsUpdate
)
from app.schemas.response import (
    AdminAuthResponse,
    AdminDashboardResponse,
    UserProfileAdminResponse,
    WithdrawalAdminResponse,
    PlatformSettingsResponse,
    PaginatedResponse
)
from app.middleware.auth import get_current_admin, require_permission
from app.services import (
    admin_service,
    user_service,
    withdrawal_service,
    earnings_service,
    fraud_service,
    audit_service
)
from app.core.rate_limiter import rate_limiter

router = APIRouter(prefix="/api/v1/admin", tags=["Admin"])


# ==================== ADMIN AUTH ====================

@router.post("/auth/login", response_model=AdminAuthResponse)
async def admin_login(
    request: Request,
    login_data: AdminLoginRequest
):
    """
    Admin login with email/password
    """
    # Rate limiting
    await rate_limiter.check_ip_rate_limit(request.client.host, "admin_login")
    
    # Verify credentials
    admin_data = await admin_service.verify_admin_credentials(
        email=login_data.email,
        password=login_data.password
    )
    
    # Check IP whitelist
    if admin_data.get("ip_whitelist"):
        client_ip = request.client.host
        if client_ip not in admin_data["ip_whitelist"]:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="IP address not allowed"
            )
    
    # Create token
    token = await admin_service.create_admin_token(admin_data)
    
    # Create audit log
    await audit_service.create_audit_log(
        admin_id=admin_data["admin_id"],
        action="admin_login",
        resource="auth",
        details={
            "ip": request.client.host,
            "user_agent": request.headers.get("User-Agent"),
            "success": True
        }
    )
    
    return AdminAuthResponse(
        admin_id=admin_data["admin_id"],
        email=admin_data["email"],
        role=admin_data["role"],
        permissions=admin_data["permissions"],
        name=admin_data.get("name", ""),
        access_token=token,
        token_type="bearer",
        expires_in=settings.admin_token_expire_hours * 3600
    )


@router.post("/auth/refresh", response_model=AdminAuthResponse)
async def admin_refresh(
    request: Request,
    refresh_token: str = Body(..., embed=True),
    current_admin: dict = Depends(get_current_admin)
):
    """
    Refresh admin token
    """
    new_token = await admin_service.refresh_admin_token(
        current_admin["admin_id"],
        refresh_token
    )
    
    return AdminAuthResponse(
        admin_id=current_admin["admin_id"],
        email=current_admin["email"],
        role=current_admin["role"],
        permissions=current_admin["permissions"],
        name=current_admin.get("name", ""),
        access_token=new_token,
        token_type="bearer",
        expires_in=settings.admin_token_expire_hours * 3600
    )


@router.post("/auth/logout")
async def admin_logout(
    request: Request,
    current_admin: dict = Depends(get_current_admin)
):
    """
    Admin logout
    """
    auth_header = request.headers.get("Authorization")
    if auth_header and auth_header.startswith("Bearer "):
        token = auth_header.split(" ")[1]
        await admin_service.revoke_admin_token(token)
    
    await audit_service.create_audit_log(
        admin_id=current_admin["admin_id"],
        action="admin_logout",
        resource="auth",
        details={"ip": request.client.host}
    )
    
    return {"message": "Admin logged out successfully"}


# ==================== DASHBOARD ====================

@router.get("/dashboard/overview", response_model=AdminDashboardResponse)
@require_permission(["view_dashboard"])
async def dashboard_overview(
    request: Request,
    current_admin: dict = Depends(get_current_admin)
):
    """
    Get dashboard statistics
    """
    stats = await admin_service.get_dashboard_stats()
    
    return AdminDashboardResponse(
        total_users=stats["total_users"],
        active_users=stats["active_users"],
        new_users_today=stats["new_users_today"],
        total_links=stats["total_links"],
        active_links=stats["active_links"],
        total_clicks_today=stats["total_clicks_today"],
        page3_views_today=stats["page3_views_today"],
        earnings_today=stats["earnings_today"],
        pending_withdrawals=stats["pending_withdrawals"],
        total_withdrawn_today=stats["total_withdrawn_today"],
        conversion_rate=stats["conversion_rate"],
        fraud_attempts_today=stats["fraud_attempts_today"],
        platform_balance=stats["platform_balance"],
        active_sessions=stats["active_sessions"],
        system_health=stats["system_health"]
    )


@router.get("/earnings/summary")
@require_permission(["view_earnings"])
async def earnings_control_panel(
    period: str = Query("today", regex="^(today|yesterday|week|month|quarter|year|custom)$"),
    start_date: Optional[datetime] = None,
    end_date: Optional[datetime] = None,
    current_admin: dict = Depends(get_current_admin)
):
    """
    Get earnings summary for admin
    """
    earnings = await earnings_service.get_platform_earnings_summary(
        period=period,
        start_date=start_date,
        end_date=end_date
    )
    
    return earnings


@router.get("/traffic/health")
@require_permission(["view_traffic"])
async def traffic_health(
    hours: int = Query(24, ge=1, le=168),
    current_admin: dict = Depends(get_current_admin)
):
    """
    Monitor traffic health
    """
    health = await admin_service.get_traffic_health(hours=hours)
    
    return health


@router.get("/fraud/sessions")
@require_permission(["view_fraud"])
async def fraud_sessions_list(
    page: int = 1,
    limit: int = 100,
    status: str = Query("suspicious", regex="^(suspicious|confirmed|blocked|all)$"),
    current_admin: dict = Depends(get_current_admin)
):
    """
    List suspicious/fraudulent sessions
    """
    sessions, total, has_next = await fraud_service.get_fraud_sessions(
        status=status,
        page=page,
        limit=limit
    )
    
    return PaginatedResponse(
        data=sessions,
        page=page,
        limit=limit,
        total=total,
        has_next=has_next
    )


# ==================== WITHDRAWAL MANAGEMENT ====================

@router.get("/withdrawals/pending", response_model=List[WithdrawalAdminResponse])
@require_permission(["manage_withdrawals"])
async def pending_withdrawals(
    page: int = 1,
    limit: int = 50,
    current_admin: dict = Depends(get_current_admin)
):
    """
    Get pending withdrawal requests
    """
    withdrawals, total, has_next = await withdrawal_service.get_pending_withdrawals(
        page=page,
        limit=limit
    )
    
    return PaginatedResponse(
        data=[WithdrawalAdminResponse.from_orm(wd) for wd in withdrawals],
        page=page,
        limit=limit,
        total=total,
        has_next=has_next
    )


@router.post("/withdrawals/{withdrawal_id}/approve")
@require_permission(["approve_withdrawals"])
async def approve_withdrawal(
    withdrawal_id: str,
    action_data: WithdrawalActionRequest,
    current_admin: dict = Depends(get_current_admin)
):
    """
    Approve a withdrawal request
    """
    withdrawal = await withdrawal_service.approve_withdrawal(
        withdrawal_id=withdrawal_id,
        admin_id=current_admin["admin_id"],
        notes=action_data.notes
    )
    
    # Audit log
    await audit_service.create_audit_log(
        admin_id=current_admin["admin_id"],
        action="approve_withdrawal",
        resource=f"withdrawals/{withdrawal_id}",
        details={
            "withdrawal_id": withdrawal_id,
            "amount": withdrawal.amount,
            "user_uid": withdrawal.user_uid,
            "notes": action_data.notes
        }
    )
    
    return {"message": "Withdrawal approved successfully", "withdrawal": withdrawal}


@router.post("/withdrawals/{withdrawal_id}/reject")
@require_permission(["reject_withdrawals"])
async def reject_withdrawal(
    withdrawal_id: str,
    action_data: WithdrawalActionRequest,
    current_admin: dict = Depends(get_current_admin)
):
    """
    Reject a withdrawal request
    """
    withdrawal = await withdrawal_service.reject_withdrawal(
        withdrawal_id=withdrawal_id,
        admin_id=current_admin["admin_id"],
        reason=action_data.notes
    )
    
    # Audit log
    await audit_service.create_audit_log(
        admin_id=current_admin["admin_id"],
        action="reject_withdrawal",
        resource=f"withdrawals/{withdrawal_id}",
        details={
            "withdrawal_id": withdrawal_id,
            "amount": withdrawal.amount,
            "user_uid": withdrawal.user_uid,
            "reason": action_data.notes
        }
    )
    
    return {"message": "Withdrawal rejected successfully", "withdrawal": withdrawal}


@router.get("/withdrawals/export")
@require_permission(["export_withdrawals"])
async def export_withdrawals(
    start_date: datetime,
    end_date: datetime,
    format: str = Query("csv", regex="^(csv|excel|json)$"),
    current_admin: dict = Depends(get_current_admin)
):
    """
    Export withdrawals to CSV/Excel
    """
    export_data = await withdrawal_service.export_withdrawals(
        start_date=start_date,
        end_date=end_date,
        format=format
    )
    
    return export_data


# ==================== USER MANAGEMENT ====================

@router.get("/users/{uid}", response_model=UserProfileAdminResponse)
@require_permission(["view_users"])
async def get_user_full_profile(
    uid: str,
    current_admin: dict = Depends(get_current_admin)
):
    """
    Get full user profile for admin
    """
    user = await user_service.get_user_by_uid(uid)
    if not user:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="User not found"
        )
    
    earnings = await earnings_service.get_user_earnings_summary(uid)
    links = await user_service.get_user_links_summary(uid)
    withdrawals = await withdrawal_service.get_user_withdrawals_summary(uid)
    fraud_flags = await fraud_service.get_user_fraud_flags(uid)
    
    return UserProfileAdminResponse(
        user=user,
        earnings=earnings,
        links=links,
        withdrawals=withdrawals,
        fraud_flags=fraud_flags
    )


@router.post("/users/{uid}/suspend")
@require_permission(["suspend_users"])
async def suspend_user(
    uid: str,
    suspend_data: Dict[str, Any] = Body(...),
    current_admin: dict = Depends(get_current_admin)
):
    """
    Suspend a user account
    """
    result = await admin_service.suspend_user(
        user_uid=uid,
        admin_id=current_admin["admin_id"],
        reason=suspend_data.get("reason", "Violation of terms"),
        duration_days=suspend_data.get("duration_days", 7),
        disable_links=suspend_data.get("disable_links", True)
    )
    
    # Audit log
    await audit_service.create_audit_log(
        admin_id=current_admin["admin_id"],
        action="suspend_user",
        resource=f"users/{uid}",
        details={
            "user_uid": uid,
            "reason": suspend_data.get("reason"),
            "duration_days": suspend_data.get("duration_days"),
            "disable_links": suspend_data.get("disable_links")
        }
    )
    
    return result


@router.post("/users/{uid}/ban")
@require_permission(["ban_users"])
async def ban_user(
    uid: str,
    ban_data: Dict[str, Any] = Body(...),
    current_admin: dict = Depends(get_current_admin)
):
    """
    Permanently ban a user
    """
    result = await admin_service.ban_user(
        user_uid=uid,
        admin_id=current_admin["admin_id"],
        reason=ban_data.get("reason", "Serious violation"),
        refund_pending=ban_data.get("refund_pending", False)
    )
    
    # Audit log
    await audit_service.create_audit_log(
        admin_id=current_admin["admin_id"],
        action="ban_user",
        resource=f"users/{uid}",
        details={
            "user_uid": uid,
            "reason": ban_data.get("reason"),
            "refund_pending": ban_data.get("refund_pending")
        }
    )
    
    return result


@router.post("/users/{uid}/reinstate")
@require_permission(["reinstate_users"])
async def reinstate_user(
    uid: str,
    reinstate_data: Dict[str, Any] = Body(...),
    current_admin: dict = Depends(get_current_admin)
):
    """
    Reinstate a suspended/banned user
    """
    result = await admin_service.reinstate_user(
        user_uid=uid,
        admin_id=current_admin["admin_id"],
        reason=reinstate_data.get("reason", "Appeal approved")
    )
    
    # Audit log
    await audit_service.create_audit_log(
        admin_id=current_admin["admin_id"],
        action="reinstate_user",
        resource=f"users/{uid}",
        details={
            "user_uid": uid,
            "reason": reinstate_data.get("reason")
        }
    )
    
    return result


@router.post("/users/{uid}/adjust")
@require_permission(["adjust_earnings"])
async def adjust_user_earnings(
    uid: str,
    adjustment_data: Dict[str, Any] = Body(...),
    current_admin: dict = Depends(get_current_admin)
):
    """
    Adjust user earnings (rare, logged)
    """
    result = await admin_service.adjust_user_earnings(
        user_uid=uid,
        admin_id=current_admin["admin_id"],
        adjustment_type=adjustment_data["type"],  # add, deduct, set
        amount=adjustment_data["amount"],
        reason=adjustment_data.get("reason", "Manual adjustment"),
        notes=adjustment_data.get("notes")
    )
    
    # Audit log
    await audit_service.create_audit_log(
        admin_id=current_admin["admin_id"],
        action="adjust_user_earnings",
        resource=f"users/{uid}",
        details={
            "user_uid": uid,
            "type": adjustment_data["type"],
            "amount": adjustment_data["amount"],
            "reason": adjustment_data.get("reason"),
            "notes": adjustment_data.get("notes")
        }
    )
    
    return result


@router.get("/users/search")
@require_permission(["view_users"])
async def search_users(
    query: str = Query(..., min_length=2),
    field: str = Query("username", regex="^(username|email|phone|uid)$"),
    page: int = 1,
    limit: int = 20,
    current_admin: dict = Depends(get_current_admin)
):
    """
    Search users by username, email, phone, or UID
    """
    users, total, has_next = await user_service.search_users(
        query=query,
        field=field,
        page=page,
        limit=limit
    )
    
    return PaginatedResponse(
        data=users,
        page=page,
        limit=limit,
        total=total,
        has_next=has_next
    )


# ==================== SETTINGS ====================

@router.get("/settings", response_model=PlatformSettingsResponse)
@require_permission(["view_settings"])
async def get_platform_settings(
    current_admin: dict = Depends(get_current_admin)
):
    """
    Get platform settings
    """
    settings = await admin_service.get_platform_settings()
    
    return PlatformSettingsResponse(**settings)


@router.post("/settings")
@require_permission(["update_settings"])
async def update_settings(
    settings_data: PlatformSettingsUpdate,
    current_admin: dict = Depends(get_current_admin)
):
    """
    Update platform settings
    """
    updated = await admin_service.update_platform_settings(
        settings_data=settings_data.dict(exclude_unset=True),
        admin_id=current_admin["admin_id"]
    )
    
    # Audit log
    await audit_service.create_audit_log(
        admin_id=current_admin["admin_id"],
        action="update_settings",
        resource="platform/settings",
        details={
            "changes": settings_data.dict(exclude_unset=True),
            "admin_id": current_admin["admin_id"]
        }
    )
    
    return {"message": "Settings updated successfully", "settings": updated}


@router.post("/websites/add")
@require_permission(["manage_websites"])
async def add_website(
    website_data: Dict[str, Any] = Body(...),
    current_admin: dict = Depends(get_current_admin)
):
    """
    Add website to allowed pool
    """
    website = await admin_service.add_website(
        website_data=website_data,
        admin_id=current_admin["admin_id"]
    )
    
    # Audit log
    await audit_service.create_audit_log(
        admin_id=current_admin["admin_id"],
        action="add_website",
        resource="websites",
        details={
            "domain": website_data.get("domain"),
            "category": website_data.get("category")
        }
    )
    
    return {"message": "Website added successfully", "website": website}


@router.post("/websites/{website_id}/disable")
@require_permission(["manage_websites"])
async def disable_website(
    website_id: str,
    disable_data: Dict[str, Any] = Body(...),
    current_admin: dict = Depends(get_current_admin)
):
    """
    Disable a website
    """
    result = await admin_service.disable_website(
        website_id=website_id,
        admin_id=current_admin["admin_id"],
        reason=disable_data.get("reason", "Policy violation")
    )
    
    # Audit log
    await audit_service.create_audit_log(
        admin_id=current_admin["admin_id"],
        action="disable_website",
        resource=f"websites/{website_id}",
        details={
            "website_id": website_id,
            "reason": disable_data.get("reason")
        }
    )
    
    return result


# ==================== ADMIN MANAGEMENT ====================

@router.post("/admins/create")
@require_permission(["create_admins"])
async def create_admin(
    admin_data: AdminCreateRequest,
    current_admin: dict = Depends(get_current_admin)
):
    """
    Create new admin (super admin only)
    """
    new_admin = await admin_service.create_admin(
        admin_data=admin_data,
        created_by=current_admin["admin_id"]
    )
    
    # Audit log
    await audit_service.create_audit_log(
        admin_id=current_admin["admin_id"],
        action="create_admin",
        resource="admins",
        details={
            "new_admin_email": admin_data.email,
            "role": admin_data.role,
            "permissions": admin_data.permissions
        }
    )
    
    return {"message": "Admin created successfully", "admin": new_admin}


@router.get("/admins/list")
@require_permission(["view_admins"])
async def list_admins(
    page: int = 1,
    limit: int = 20,
    current_admin: dict = Depends(get_current_admin)
):
    """
    List all admins
    """
    admins, total, has_next = await admin_service.list_admins(
        page=page,
        limit=limit
    )
    
    return PaginatedResponse(
        data=admins,
        page=page,
        limit=limit,
        total=total,
        has_next=has_next
    )


@router.post("/admins/{admin_id}/deactivate")
@require_permission(["deactivate_admins"])
async def deactivate_admin(
    admin_id: str,
    deactivate_data: Dict[str, Any] = Body(...),
    current_admin: dict = Depends(get_current_admin)
):
    """
    Deactivate an admin account
    """
    result = await admin_service.deactivate_admin(
        admin_id=admin_id,
        deactivated_by=current_admin["admin_id"],
        reason=deactivate_data.get("reason", "Security concerns")
    )
    
    # Audit log
    await audit_service.create_audit_log(
        admin_id=current_admin["admin_id"],
        action="deactivate_admin",
        resource=f"admins/{admin_id}",
        details={
            "target_admin_id": admin_id,
            "reason": deactivate_data.get("reason")
        }
    )
    
    return result


# ==================== AUDIT LOGS ====================

@router.get("/audit/logs")
@require_permission(["view_audit_logs"])
async def get_audit_logs(
    admin_id: Optional[str] = None,
    action: Optional[str] = None,
    resource: Optional[str] = None,
    start_date: Optional[datetime] = None,
    end_date: Optional[datetime] = None,
    page: int = 1,
    limit: int = 50,
    current_admin: dict = Depends(get_current_admin)
):
    """
    Get audit logs with filtering
    """
    logs, total, has_next = await audit_service.get_audit_logs(
        admin_id=admin_id,
        action=action,
        resource=resource,
        start_date=start_date,
        end_date=end_date,
        page=page,
        limit=limit
    )
    
    return PaginatedResponse(
        data=logs,
        page=page,
        limit=limit,
        total=total,
        has_next=has_next
    )