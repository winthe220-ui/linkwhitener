"""
Earnings management endpoints
"""
from fastapi import APIRouter, Depends, HTTPException, status, Request, Query
from typing import Optional, List
from datetime import datetime, timedelta

from app.schemas.request import DateRangeParams, EarningsQueryParams, PaginationParams
from app.schemas.response import (
    EarningsSummaryResponse,
    EarningsTransactionResponse,
    EarningsByLinkResponse,
    PaginatedResponse,
    SuccessResponse,
    ErrorResponse
)
from app.middleware.auth import get_current_active_user
from app.services.earnings_service import earnings_service
from app.api.dependencies import get_pagination, get_date_range

router = APIRouter(prefix="/api/v1/earnings", tags=["Earnings"])


@router.get("/summary", response_model=EarningsSummaryResponse)
async def get_earnings_summary(
    current_user: dict = Depends(get_current_active_user)
):
    """
    Get comprehensive earnings summary
    
    - Total earnings
    - Available balance
    - Time-based earnings (today, week, month)
    - Projections
    - Platform limits
    """
    summary = await earnings_service.get_user_earnings_summary(
        user_uid=current_user["uid"]
    )
    
    return EarningsSummaryResponse(
        total_earned=summary["total_earned"],
        available_balance=summary["available_balance"],
        pending_withdrawal=summary["pending_withdrawal"],
        withdrawn_amount=summary["withdrawn_amount"],
        referral_earnings=summary["referral_earnings"],
        bonus_earnings=summary["bonus_earnings"],
        today_earnings=summary["today_earnings"],
        yesterday_earnings=summary["yesterday_earnings"],
        this_week_earnings=summary["this_week_earnings"],
        this_month_earnings=summary["this_month_earnings"],
        last_month_earnings=summary["last_month_earnings"],
        estimated_daily=summary["estimated_daily"],
        estimated_weekly=summary["estimated_weekly"],
        estimated_monthly=summary["estimated_monthly"],
        valid_page3_views=summary["valid_page3_views"],
        conversion_rate=summary["conversion_rate"],
        average_earnings_per_view=summary["average_earnings_per_view"],
        min_withdrawal_amount=summary["min_withdrawal_amount"],
        max_withdrawal_amount=summary["max_withdrawal_amount"],
        withdrawal_cooldown_hours=summary["withdrawal_cooldown_hours"],
        kyc_required_amount=summary["kyc_required_amount"]
    )


@router.get("/history", response_model=PaginatedResponse[EarningsTransactionResponse])
async def get_earnings_history(
    type: Optional[str] = Query(None, regex="^(page_view|referral|bonus|adjustment|all)$"),
    link_id: Optional[str] = Query(None),
    pagination: PaginationParams = Depends(get_pagination),
    date_range: DateRangeParams = Depends(get_date_range),
    current_user: dict = Depends(get_current_active_user)
):
    """
    Get paginated earnings transaction history
    
    - Filter by transaction type
    - Filter by link
    - Date range filtering
    - Paginated response
    """
    transactions, total, has_next = await earnings_service.get_earnings_history(
        user_uid=current_user["uid"],
        transaction_type=type if type != "all" else None,
        link_id=link_id,
        start_date=date_range.start_date,
        end_date=date_range.end_date,
        page=pagination.page,
        limit=pagination.limit,
        sort_by=pagination.sort_by,
        sort_order=pagination.sort_order
    )
    
    # Convert to response models
    transaction_responses = []
    for tx in transactions:
        transaction_responses.append(EarningsTransactionResponse(
            transaction_id=tx["transaction_id"],
            user_uid=tx["user_uid"],
            link_id=tx.get("link_id"),
            amount=tx["amount"],
            type=tx["type"],
            status=tx["status"],
            description=tx["description"],
            created_at=tx["created_at"],
            processed_at=tx.get("processed_at"),
            metadata=tx.get("metadata", {}),
            balance_before=tx.get("balance_before"),
            balance_after=tx.get("balance_after")
        ))
    
    return PaginatedResponse(
        data=transaction_responses,
        page=pagination.page,
        limit=pagination.limit,
        total=total,
        has_next=has_next,
        has_previous=pagination.page > 1,
        total_pages=(total + pagination.limit - 1) // pagination.limit
    )


@router.get("/by-link", response_model=List[EarningsByLinkResponse])
async def get_earnings_by_link(
    current_user: dict = Depends(get_current_active_user)
):
    """
    Get earnings breakdown by link
    
    - Earnings per link
    - Performance metrics
    - Conversion rates
    """
    earnings_by_link = await earnings_service.get_earnings_by_link(
        user_uid=current_user["uid"]
    )
    
    response = []
    for item in earnings_by_link:
        response.append(EarningsByLinkResponse(
            link_id=item["link_id"],
            title=item["title"],
            short_url=item["short_url"],
            total_clicks=item["total_clicks"],
            page3_views=item["page3_views"],
            earnings_total=item["earnings_total"],
            earnings_today=item["earnings_today"],
            earnings_this_week=item["earnings_this_week"],
            earnings_this_month=item["earnings_this_month"],
            conversion_rate=item["conversion_rate"],
            created_at=item["created_at"]
        ))
    
    return response


@router.get("/referral", response_model=dict)
async def get_referral_earnings(
    current_user: dict = Depends(get_current_active_user)
):
    """
    Get referral earnings information
    
    - Total referral earnings
    - Referral network
    - Commission rates
    """
    referral_info = await earnings_service.get_referral_earnings(
        user_uid=current_user["uid"]
    )
    
    return {
        "total_referral_earnings": referral_info["total_referral_earnings"],
        "pending_referral_earnings": referral_info["pending_referral_earnings"],
        "withdrawn_referral_earnings": referral_info["withdrawn_referral_earnings"],
        "referral_count": referral_info["referral_count"],
        "active_referrals": referral_info["active_referrals"],
        "referral_commission_rate": referral_info["referral_commission_rate"],
        "referral_transactions": referral_info.get("referral_transactions", []),
        "referral_stats": referral_info.get("referral_stats", {})
    }


@router.get("/daily", response_model=dict)
async def get_daily_earnings(
    days: int = Query(30, ge=1, le=365, description="Number of days"),
    current_user: dict = Depends(get_current_active_user)
):
    """
    Get daily earnings for the past N days
    
    - Time series data
    - Daily trends
    - Growth analysis
    """
    daily_earnings = await earnings_service.get_daily_earnings(
        user_uid=current_user["uid"],
        days=days
    )
    
    return {
        "user_uid": current_user["uid"],
        "period_days": days,
        "total_earnings_period": sum(day["earnings"] for day in daily_earnings),
        "average_daily_earnings": sum(day["earnings"] for day in daily_earnings) / len(daily_earnings) if daily_earnings else 0,
        "daily_earnings": daily_earnings,
        "trend": "up" if len(daily_earnings) > 1 and daily_earnings[-1]["earnings"] > daily_earnings[0]["earnings"] else "down",
        "growth_rate": calculate_growth_rate(daily_earnings) if len(daily_earnings) > 1 else 0
    }


@router.get("/monthly", response_model=dict)
async def get_monthly_earnings(
    months: int = Query(12, ge=1, le=24, description="Number of months"),
    current_user: dict = Depends(get_current_active_user)
):
    """
    Get monthly earnings for the past N months
    
    - Monthly trends
    - Seasonal patterns
    - Year-over-year comparison
    """
    monthly_earnings = await earnings_service.get_monthly_earnings(
        user_uid=current_user["uid"],
        months=months
    )
    
    return {
        "user_uid": current_user["uid"],
        "period_months": months,
        "total_earnings_period": sum(month["earnings"] for month in monthly_earnings),
        "average_monthly_earnings": sum(month["earnings"] for month in monthly_earnings) / len(monthly_earnings) if monthly_earnings else 0,
        "monthly_earnings": monthly_earnings,
        "best_month": max(monthly_earnings, key=lambda x: x["earnings"]) if monthly_earnings else None,
        "worst_month": min(monthly_earnings, key=lambda x: x["earnings"]) if monthly_earnings else None
    }


@router.get("/leaderboard", response_model=dict)
async def get_earnings_leaderboard(
    period: str = Query("month", regex="^(day|week|month|all)$"),
    limit: int = Query(10, ge=1, le=50),
    current_user: dict = Depends(get_current_active_user)
):
    """
    Get earnings leaderboard
    
    - Top earners in period
    - User's rank
    - Performance comparison
    """
    leaderboard = await earnings_service.get_earnings_leaderboard(
        user_uid=current_user["uid"],
        period=period,
        limit=limit
    )
    
    return {
        "period": period,
        "user_rank": leaderboard.get("user_rank"),
        "total_participants": leaderboard.get("total_participants"),
        "user_earnings": leaderboard.get("user_earnings"),
        "top_earners": leaderboard.get("top_earners", []),
        "average_earnings": leaderboard.get("average_earnings"),
        "median_earnings": leaderboard.get("median_earnings"),
        "timestamp": datetime.utcnow().isoformat()
    }


@router.get("/projections", response_model=dict)
async def get_earnings_projections(
    current_user: dict = Depends(get_current_active_user)
):
    """
    Get earnings projections
    
    - Future earnings estimate
    - Growth projections
    - Milestone predictions
    """
    projections = await earnings_service.get_earnings_projections(
        user_uid=current_user["uid"]
    )
    
    return {
        "user_uid": current_user["uid"],
        "current_daily_average": projections["current_daily_average"],
        "projected_daily": projections["projected_daily"],
        "projected_weekly": projections["projected_weekly"],
        "projected_monthly": projections["projected_monthly"],
        "projected_yearly": projections["projected_yearly"],
        "next_milestone": projections["next_milestone"],
        "days_to_milestone": projections["days_to_milestone"],
        "growth_rate": projections["growth_rate"],
        "confidence_score": projections["confidence_score"],
        "assumptions": projections["assumptions"]
    }


@router.get("/stats", response_model=dict)
async def get_earnings_statistics(
    current_user: dict = Depends(get_current_active_user)
):
    """
    Get detailed earnings statistics
    
    - Statistical analysis
    - Performance metrics
    - Comparative analysis
    """
    stats = await earnings_service.get_earnings_statistics(
        user_uid=current_user["uid"]
    )
    
    return {
        "user_uid": current_user["uid"],
        "basic_stats": stats["basic_stats"],
        "performance_metrics": stats["performance_metrics"],
        "trend_analysis": stats["trend_analysis"],
        "comparative_analysis": stats["comparative_analysis"],
        "predictive_metrics": stats["predictive_metrics"],
        "timestamp": datetime.utcnow().isoformat()
    }


@router.get("/export", response_model=dict)
async def export_earnings_data(
    format: str = Query("csv", regex="^(csv|json|excel)$"),
    start_date: Optional[datetime] = Query(None),
    end_date: Optional[datetime] = Query(None),
    current_user: dict = Depends(get_current_active_user)
):
    """
    Export earnings data
    
    - Multiple formats
    - Date range filtering
    - Downloadable file
    """
    export_data = await earnings_service.export_earnings_data(
        user_uid=current_user["uid"],
        format=format,
        start_date=start_date,
        end_date=end_date
    )
    
    return {
        "download_url": export_data["download_url"],
        "expires_at": export_data["expires_at"],
        "file_size_bytes": export_data["file_size_bytes"],
        "record_count": export_data["record_count"],
        "format": format,
        "timestamp": datetime.utcnow().isoformat()
    }


@router.post("/adjustment/request", response_model=SuccessResponse)
async def request_earnings_adjustment(
    reason: str,
    amount: float,
    description: str,
    current_user: dict = Depends(get_current_active_user)
):
    """
    Request earnings adjustment (for disputed transactions)
    
    - Manual review required
    - Audit trail
    - Admin approval needed
    """
    success = await earnings_service.request_earnings_adjustment(
        user_uid=current_user["uid"],
        amount=amount,
        reason=reason,
        description=description
    )
    
    if not success:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Failed to request adjustment"
        )
    
    return SuccessResponse(
        message="Earnings adjustment request submitted for review"
    )


# Helper functions
def calculate_growth_rate(daily_earnings: List[dict]) -> float:
    """Calculate earnings growth rate"""
    if len(daily_earnings) < 2:
        return 0.0
    
    first_day = daily_earnings[0]["earnings"]
    last_day = daily_earnings[-1]["earnings"]
    
    if first_day == 0:
        return 100.0 if last_day > 0 else 0.0
    
    return ((last_day - first_day) / first_day) * 100