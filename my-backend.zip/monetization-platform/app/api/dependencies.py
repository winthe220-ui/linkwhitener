"""
API dependencies for dependency injection
"""

from fastapi import Depends, HTTPException, status
from typing import Optional
from datetime import datetime, timedelta

from app.middleware.auth import (
    get_current_user,
    get_current_active_user,
    get_current_admin,
    get_current_active_admin,
)
from app.core.rate_limiter import rate_limiter
from app.schemas.request import PaginationParams, DateRangeParams

# ==================== AUTH DEPENDENCIES ====================

CurrentUser = Depends(get_current_user)
CurrentActiveUser = Depends(get_current_active_user)

CurrentAdmin = Depends(get_current_admin)
CurrentActiveAdmin = Depends(get_current_active_admin)

# ==================== RATE LIMITING ====================

async def rate_limit_user(
    user_uid: str,
    endpoint: str,
    limit: int = 60,
    period: int = 60
):
    await rate_limiter.check_user_rate_limit(
        user_uid, endpoint, limit, period
    )


async def rate_limit_ip(
    ip_address: str,
    endpoint: str,
    limit: int = 100,
    period: int = 60
):
    await rate_limiter.check_ip_rate_limit(
        ip_address, endpoint, limit, period
    )

# ==================== PAGINATION ====================

def get_pagination_params(
    page: int = 1,
    limit: int = 20,
    sort_by: Optional[str] = None,
    sort_order: Optional[str] = None
) -> PaginationParams:
    return PaginationParams(
        page=page,
        limit=limit,
        sort_by=sort_by,
        sort_order=sort_order
    )

# Alias for backward compatibility
get_pagination = get_pagination_params

# ==================== DATE RANGE ====================

def get_date_range_params(
    start_date: Optional[datetime] = None,
    end_date: Optional[datetime] = None,
    period: Optional[str] = None
) -> DateRangeParams:

    if period:
        now = datetime.utcnow()
        if period == "today":
            start_date = now.replace(hour=0, minute=0, second=0, microsecond=0)
            end_date = now
        elif period == "yesterday":
            start_date = (now - timedelta(days=1)).replace(hour=0, minute=0, second=0, microsecond=0)
            end_date = start_date + timedelta(days=1)
        elif period == "week":
            start_date = now - timedelta(days=7)
            end_date = now
        elif period == "month":
            start_date = now - timedelta(days=30)
            end_date = now
        elif period == "quarter":
            start_date = now - timedelta(days=90)
            end_date = now
        elif period == "year":
            start_date = now - timedelta(days=365)
            end_date = now

    return DateRangeParams(
        start_date=start_date,
        end_date=end_date,
        period=period
    )

# Alias for backward compatibility
get_date_range = get_date_range_params

__all__ = [
    "CurrentUser",
    "CurrentActiveUser",
    "CurrentAdmin",
    "CurrentActiveAdmin",
    "rate_limit_user",
    "rate_limit_ip",
    "get_pagination_params",
    "get_pagination",
    "get_date_range_params",
    "get_date_range",
]
